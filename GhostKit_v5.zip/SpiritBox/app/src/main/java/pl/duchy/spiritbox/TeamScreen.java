package pl.duchy.spiritbox;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Łączenie telefonów – dwa duże przyciski, reszta w "zaawansowanych". */
final class TeamScreen extends Screen {

    private final TextView stateBig, stateSmall, members;
    private final LinearLayout statusCard, found, advanced;
    private final Button hostBtn, joinBtn, leaveBtn, advBtn;
    private final EditText ipField;
    private String foundSig = "";
    private long joinSearchUntil = 0;

    TeamScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(14), dp(4), dp(14), dp(28));
        sv.addView(root);
        addView(sv);

        statusCard = Ui.col(a);
        statusCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        stateBig = Ui.head(a, "", 20, Ui.TEXT);
        stateSmall = Ui.text(a, "", 13, Ui.DIM, false);
        stateSmall.setPadding(0, dp(4), 0, 0);
        statusCard.addView(stateBig);
        statusCard.addView(stateSmall);
        root.addView(statusCard, Ui.matchWrap(a, 0));

        LinearLayout r = Ui.row(a);
        hostBtn = Ui.btn(a, "UTWÓRZ\nDRUŻYNĘ");
        hostBtn.setMinHeight(dp(72));
        hostBtn.setOnClickListener(v -> core.host());
        joinBtn = Ui.btn(a, "DOŁĄCZ\nDO DRUŻYNY");
        joinBtn.setMinHeight(dp(72));
        joinBtn.setOnClickListener(v -> startJoin());
        Ui.addWeighted(r, hostBtn);
        Ui.addWeighted(r, joinBtn);
        root.addView(r);
        leaveBtn = Ui.btn(a, "ROZŁĄCZ", Ui.CARD2, Ui.RED);
        leaveBtn.setOnClickListener(v -> core.leave());
        root.addView(leaveBtn, Ui.matchWrap(a, 4));

        root.addView(Ui.text(a, "Jedna osoba tworzy drużynę, reszta klika „Dołącz”. Telefony muszą być w tej samej " +
                "sieci Wi-Fi albo podłączone do hotspotu telefonu hosta (działa bez internetu).", 12, Ui.DIM, false));

        root.addView(Ui.section(a, "drużyny w pobliżu"));
        found = Ui.col(a);
        root.addView(found);

        root.addView(Ui.section(a, "członkowie"));
        members = Ui.text(a, "", 14, Ui.TEXT, false);
        members.setTypeface(Ui.HEAD);
        root.addView(members);

        advanced = Ui.col(a);
        advBtn = Ui.btn(a, "ZAAWANSOWANE ▾");
        advBtn.setOnClickListener(v -> {
            boolean show = advanced.getVisibility() != View.VISIBLE;
            advanced.setVisibility(show ? View.VISIBLE : View.GONE);
            advBtn.setText(show ? "ZAAWANSOWANE ▴" : "ZAAWANSOWANE ▾");
        });
        LinearLayout.LayoutParams alp = Ui.matchWrap(a, 4);
        alp.topMargin = dp(20);
        root.addView(advBtn, alp);

        advanced.setVisibility(View.GONE);
        root.addView(advanced);
        advanced.addView(Ui.section(a, "połącz po adresie ip"));
        LinearLayout ir = Ui.row(a);
        ipField = new EditText(a);
        ipField.setHint("np. 192.168.43.1 lub 100.x.x.x");
        ipField.setTextColor(Ui.TEXT);
        ipField.setHintTextColor(Ui.DIM);
        ipField.setSingleLine(true);
        ipField.setText(core.prefs.getString("last_ip", ""));
        Button conn = Ui.btn(a, "POŁĄCZ");
        conn.setOnClickListener(v -> {
            String ip = ipField.getText().toString().trim();
            if (!ip.isEmpty()) core.join(ip);
        });
        ir.addView(ipField, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        ir.addView(conn);
        advanced.addView(ir);
        advanced.addView(Ui.text(a,
                "Duża odległość (przez internet): zainstalujcie wszyscy darmową aplikację Tailscale i zalogujcie się " +
                "do tej samej sieci. Host tworzy drużynę, a reszta wpisuje tutaj jego adres 100.x.x.x z Tailscale.\n\n" +
                "Po zerwaniu połączenia aplikacja sama próbuje połączyć się ponownie przez 90 s.",
                12, Ui.DIM, false));
    }

    @Override
    String title() {
        return "Drużyna";
    }

    @Override
    void onShow() {
        core.net.startDiscovery();
        core.teamUi = this::refresh;
        foundSig = "";
        refresh();
    }

    @Override
    void onHide() {
        core.net.stopDiscovery();
        if (core.teamUi != null) core.teamUi = null;
    }

    private void startJoin() {
        if (core.net.isConnected()) return;
        joinSearchUntil = System.currentTimeMillis() + 5000;
        List<String> ips = hosts();
        if (ips.size() == 1) {
            core.join(ips.get(0));
            joinSearchUntil = 0;
        } else if (ips.size() > 1) {
            core.toast("Wybierz drużynę z listy poniżej");
            joinSearchUntil = 0;
        } else {
            core.toast("Szukam drużyny…");
        }
        refresh();
    }

    private List<String> hosts() {
        long now = System.currentTimeMillis();
        List<String> ips = new ArrayList<>();
        for (Map.Entry<String, Long> e : core.net.foundSeen.entrySet())
            if (now - e.getValue() < 5000) ips.add(e.getKey());
        return ips;
    }

    @Override
    void tick() {
        long now = System.currentTimeMillis();
        List<String> ips = hosts();
        if (joinSearchUntil > 0) {
            if (ips.size() == 1) {
                joinSearchUntil = 0;
                core.join(ips.get(0));
            } else if (ips.size() > 1) {
                joinSearchUntil = 0;
                core.toast("Znaleziono kilka drużyn – wybierz z listy");
            } else if (now > joinSearchUntil) {
                joinSearchUntil = 0;
                core.toast("Nie znaleziono drużyny. Sprawdź, czy jesteście w tej samej sieci Wi-Fi / hotspocie.");
            }
        }
        StringBuilder sig = new StringBuilder();
        for (String ip : ips) sig.append(ip).append(core.net.foundName.get(ip));
        if (!sig.toString().equals(foundSig)) {
            foundSig = sig.toString();
            found.removeAllViews();
            if (ips.isEmpty()) found.addView(Ui.text(act, "Brak – nikt w tej sieci nie utworzył drużyny.", 13, Ui.DIM, false));
            for (String ip : ips) {
                Button b = Ui.btn(act, "▸ " + core.net.foundName.get(ip) + "   " + ip);
                b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
                b.setOnClickListener(v -> core.join(ip));
                found.addView(b, Ui.matchWrap(act, 3));
            }
        }
        if (now % 1000 < 70) refresh();
    }

    private void refresh() {
        Net n = core.net;
        boolean on = n.isConnected();
        String big, small;
        if (n.role == Net.HOST) {
            big = "● JESTEŚ HOSTEM";
            StringBuilder sb = new StringBuilder("Inni mogą dołączyć. Twój adres: ");
            List<String> ips = Net.localIps();
            for (int i = 0; i < ips.size(); i++) sb.append(i > 0 ? ", " : "").append(ips.get(i).split(" ")[0]);
            small = sb.toString();
        } else if (n.connecting || core.reconnecting()) {
            big = "◌ ŁĄCZENIE…";
            small = core.reconnecting() ? "Ponowne łączenie z hostem" : "Chwileczkę";
        } else if (on) {
            big = "● POŁĄCZONO";
            small = "Host: " + n.hostIp;
        } else {
            big = "○ SOLO";
            small = "Nie jesteś w drużynie";
        }
        stateBig.setText(big);
        stateBig.setTextColor(on ? Ui.ACCENT : Ui.TEXT);
        stateSmall.setText(small);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        g.setColor(on ? Ui.accent(0x1A) : Ui.CARD);
        g.setStroke(dp(on ? 2 : 1), on ? Ui.ACCENT : Ui.STROKE);
        statusCard.setBackground(g);

        hostBtn.setVisibility(on || n.connecting ? View.GONE : View.VISIBLE);
        joinBtn.setVisibility(on || n.connecting ? View.GONE : View.VISIBLE);
        leaveBtn.setVisibility(on || n.connecting || core.reconnecting() ? View.VISIBLE : View.GONE);

        StringBuilder m = new StringBuilder();
        m.append("● ").append(core.myName).append(" (ty) — ").append(toolName(core.tool)).append('\n');
        for (Core.Member mb : core.members.values()) {
            m.append("● ").append(mb.name).append(" — ").append(toolName(mb.tool));
            if (mb.cam) m.append(" · kamera");
            m.append('\n');
        }
        members.setText(m.toString().trim());
    }

    static String toolName(String t) {
        if (t == null) return "?";
        switch (t) {
            case "box": return "Spirit Box";
            case "emf": return "Miernik EMF";
            case "thermo": return "Termometr";
            case "cam": return "Kamera";
            case "view": return "Podgląd";
            case "motion": return "Czujnik ruchu";
            case "music": return "Pozytywka";
            case "book": return "Dziennik";
            case "team": return "Drużyna";
            case "settings": return "Ustawienia";
            default: return "menu";
        }
    }

    @SuppressWarnings("unused")
    private static String lower(String s) {
        return s.toLowerCase(Locale.getDefault());
    }
}
