package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Kontrolki panelu kamery: okrągłe przełączniki z ikoną, migawka, gesty zoomu i przesuwania. */
final class Controls {

    /** Okrągły przełącznik z narysowaną ikoną. */
    static final class Round extends View {
        final String type;
        boolean on;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        Round(Context c, String type) {
            super(c);
            this.type = type;
        }

        void set(boolean v) {
            on = v;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight()), cx = getWidth() / 2f, cy = getHeight() / 2f, r = s / 2f - 2;
            float u = s / 24f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(on ? Ui.accent(0x33) : 0xFF1E2024);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(on ? 2.2f * u / 1.3f : u / 1.6f);
            p.setColor(on ? Ui.ACCENT : Ui.STROKE);
            c.drawCircle(cx, cy, r, p);
            p.setStrokeWidth(1.6f * u);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(on ? Ui.ACCENT : Ui.TEXT);
            c.save();
            c.translate(cx - 12 * u, cy - 12 * u);
            switch (type) {
                case "flash":
                    path.reset();
                    path.moveTo(13 * u, 5 * u);
                    path.lineTo(8 * u, 13 * u);
                    path.lineTo(12 * u, 13 * u);
                    path.lineTo(11 * u, 19 * u);
                    path.lineTo(16 * u, 11 * u);
                    path.lineTo(12 * u, 11 * u);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case "nv":
                    c.drawCircle(12 * u, 12 * u, 6 * u, p);
                    c.drawCircle(12 * u, 12 * u, 2.5f * u, p);
                    c.drawLine(4 * u, 12 * u, 6 * u, 12 * u, p);
                    c.drawLine(18 * u, 12 * u, 20 * u, 12 * u, p);
                    break;
                case "motion":
                    c.drawArc(new RectF(5 * u, 5 * u, 19 * u, 19 * u), 200, 140, false, p);
                    c.drawArc(new RectF(8.5f * u, 8.5f * u, 15.5f * u, 15.5f * u), 200, 140, false, p);
                    c.drawCircle(12 * u, 14 * u, 0.8f * u, p);
                    break;
                case "mic":
                    c.drawRoundRect(new RectF(9.5f * u, 4 * u, 14.5f * u, 14 * u), 2.5f * u, 2.5f * u, p);
                    c.drawArc(new RectF(7 * u, 8 * u, 17 * u, 17 * u), 0, 180, false, p);
                    c.drawLine(12 * u, 17 * u, 12 * u, 20 * u, p);
                    if (!on) c.drawLine(6 * u, 5 * u, 18 * u, 19 * u, p);
                    break;
                case "flip":
                    c.drawArc(new RectF(6 * u, 6 * u, 18 * u, 18 * u), 30, 280, false, p);
                    path.reset();
                    path.moveTo(17.5f * u, 4.5f * u);
                    path.lineTo(17.5f * u, 9 * u);
                    path.lineTo(13 * u, 9 * u);
                    c.drawPath(path, p);
                    break;
            }
            c.restore();
        }
    }

    /** Duży przycisk: migawka (photo) albo nagrywanie (rec). */
    static final class Shutter extends View {
        final boolean recBtn;
        boolean recording;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Shutter(Context c, boolean recBtn) {
            super(c);
            this.recBtn = recBtn;
        }

        void set(boolean r) {
            recording = r;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight()), cx = getWidth() / 2f, cy = getHeight() / 2f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s * 0.06f);
            p.setColor(Ui.TEXT);
            c.drawCircle(cx, cy, s / 2f - s * 0.05f, p);
            p.setStyle(Paint.Style.FILL);
            if (!recBtn) {
                p.setColor(Ui.TEXT);
                c.drawCircle(cx, cy, s * 0.34f, p);
            } else if (recording) {
                p.setColor(0xFFFF3B30);
                float h = s * 0.18f;
                c.drawRoundRect(new RectF(cx - h, cy - h, cx + h, cy + h), s * 0.05f, s * 0.05f, p);
            } else {
                p.setColor(0xFFFF3B30);
                c.drawCircle(cx, cy, s * 0.32f, p);
            }
        }
    }

    /** Kolumna: kontrolka + podpis pod nią. */
    static LinearLayout labeled(Context c, View control, String label, int sizeDp, View.OnClickListener click) {
        LinearLayout l = Ui.col(c);
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.addView(control, new LinearLayout.LayoutParams(Ui.dp(c, sizeDp), Ui.dp(c, sizeDp)));
        TextView t = Ui.head(c, label, 9, Ui.DIM);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(c, 4), 0, 0);
        l.addView(t);
        control.setOnClickListener(click);
        return l;
    }

    /** Gesty na podglądzie: przeciąganie = kierunek, szczypanie = zoom. */
    static final class PanZoom implements View.OnTouchListener {
        interface Listener { void onView(float z, float u, float v, boolean done); }

        float z = 1f, u = 0.5f, v = 0.5f;
        private final ScaleGestureDetector sgd;
        private final Listener l;
        private float lx, ly;
        private boolean skip = false;
        private View view;

        PanZoom(Context c, Listener l) {
            this.l = l;
            sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    set(z * d.getScaleFactor(), u, v);
                    PanZoom.this.l.onView(z, u, v, false);
                    return true;
                }
            });
        }

        void set(float nz, float nu, float nv) {
            z = Math.max(1f, Math.min(4f, nz));
            float m = 0.5f / z;
            u = Math.max(m, Math.min(1 - m, nu));
            v = Math.max(m, Math.min(1 - m, nv));
        }

        @Override
        public boolean onTouch(View vw, MotionEvent e) {
            view = vw;
            sgd.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lx = e.getX();
                    ly = e.getY();
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                case MotionEvent.ACTION_POINTER_UP:
                    skip = true;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (skip) {
                        skip = false;
                        lx = e.getX();
                        ly = e.getY();
                        return true;
                    }
                    if (e.getPointerCount() == 1 && !sgd.isInProgress() && z > 1.01f) {
                        float dx = e.getX() - lx, dy = e.getY() - ly;
                        set(z, u - dx / (view.getWidth() * z), v - dy / (view.getHeight() * z));
                        l.onView(z, u, v, false);
                    }
                    lx = e.getX();
                    ly = e.getY();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    l.onView(z, u, v, true);
                    return true;
            }
            return true;
        }
    }
}
