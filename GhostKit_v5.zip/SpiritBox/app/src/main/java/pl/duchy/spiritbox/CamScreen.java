package pl.duchy.spiritbox;

import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Gravity;
import android.view.TextureView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Kamera tego telefonu.
 * - Podgląd na żywo idzie prosto na ekran (TextureView) – bez opóźnienia i bez obciążania procesora.
 * - Klatki są przetwarzane tylko gdy trzeba: noktowizja, ktoś z drużyny ogląda, nagrywanie, zdjęcie.
 * - Noktowizja: dłuższe naświetlanie + automatyczne wzmocnienie jasności i odszumianie.
 * - Zoom cyfrowy 1–4× z przesuwaniem kadru (palcem tutaj albo zdalnie z innego telefonu).
 */
@SuppressWarnings("deprecation")
final class CamScreen extends Screen implements Camera.PreviewCallback, Core.CmdSink, TextureView.SurfaceTextureListener {

    private final TextureView tex;
    private final FeedView feed;
    private final FrameLayout box;
    private final Controls.Round flashB, nvB, motionB, micB;
    private final Controls.Shutter recB;
    private final TextView[] chips = new TextView[4];
    private final TextView hint;
    private final Controls.PanZoom pz;
    private final Paint nvPaint = new Paint();

    private Camera cam;
    private SurfaceTexture surface;
    private int camId = 0, pw, ph, rotation = 90;
    private boolean front = false;
    private volatile boolean flash = false, nv = false, motionOn = true, micOn = true;
    private int[] normalFps, darkFps;
    private VideoRecorder recorder;
    private int recW, recH;
    private HandlerThread worker;
    private Handler wh;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private volatile boolean photoRequested = false;
    private long lastProc = 0, lastSend = 0, lastMotionCheck = 0, lastMotion = 0, ignoreMotionUntil = 0;
    private byte[] prevY;
    private int[] acc;
    private Rect accRect;
    private int[] argb;

    private volatile boolean audioRun = false;
    private Thread audioThread;

    CamScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        sv.addView(root);
        addView(sv);

        // --- podgląd ---
        box = new FrameLayout(a);
        tex = new TextureView(a);
        tex.setSurfaceTextureListener(this);
        feed = new FeedView(a);
        feed.overlayOnly = true;
        box.addView(tex, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        box.addView(feed, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        root.addView(box, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        pz = new Controls.PanZoom(a, (z, u, v, done) -> applyView());
        feed.setOnTouchListener(pz);

        // --- panel ---
        LinearLayout panel = Ui.col(a);
        panel.setPadding(dp(12), dp(12), dp(12), dp(16));
        panel.setBackgroundColor(Ui.CARD);
        root.addView(panel);

        LinearLayout zr = Ui.row(a);
        zr.setGravity(Gravity.CENTER);
        for (int i = 0; i < 4; i++) {
            final int z = i + 1;
            chips[i] = Ui.head(a, z + "×", 13, Ui.TEXT);
            chips[i].setGravity(Gravity.CENTER);
            chips[i].setOnClickListener(v -> { pz.set(z, pz.u, pz.v); applyView(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(52), dp(34));
            lp.setMargins(dp(4), 0, dp(4), 0);
            zr.addView(chips[i], lp);
        }
        panel.addView(zr);
        hint = Ui.text(a, "przeciągnij palcem, by zmienić kierunek · szczypnij, by przybliżyć", 11, Ui.DIM, false);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(6), 0, dp(10));
        panel.addView(hint);

        LinearLayout tr = Ui.row(a);
        tr.setGravity(Gravity.CENTER);
        flashB = new Controls.Round(a, "flash");
        nvB = new Controls.Round(a, "nv");
        motionB = new Controls.Round(a, "motion");
        micB = new Controls.Round(a, "mic");
        Controls.Round flipB = new Controls.Round(a, "flip");
        Ui.addWeighted(tr, Controls.labeled(a, flashB, "LAMPA", 50, v -> { flash = !flash; applyParams(); }));
        Ui.addWeighted(tr, Controls.labeled(a, nvB, "NOKTOWIZJA", 50, v -> { nv = !nv; applyParams(); }));
        Ui.addWeighted(tr, Controls.labeled(a, motionB, "RUCH", 50, v -> { motionOn = !motionOn; applyParams(); }));
        Ui.addWeighted(tr, Controls.labeled(a, micB, "DŹWIĘK", 50, v -> { micOn = !micOn; refreshControls(); }));
        Ui.addWeighted(tr, Controls.labeled(a, flipB, "OBRÓĆ", 50, v -> switchCam()));
        panel.addView(tr);

        LinearLayout sr = Ui.row(a);
        sr.setGravity(Gravity.CENTER);
        sr.setPadding(0, dp(14), 0, 0);
        Controls.Shutter photoB = new Controls.Shutter(a, false);
        recB = new Controls.Shutter(a, true);
        Ui.addWeighted(sr, Controls.labeled(a, photoB, "ZDJĘCIE", 70, v -> photoRequested = true));
        Ui.addWeighted(sr, Controls.labeled(a, recB, "NAGRYWANIE", 70, v -> toggleRec()));
        panel.addView(sr);

        TextView info = Ui.text(a, "Noktowizja wydłuża naświetlanie i automatycznie rozjaśnia oraz odszumia obraz. " +
                "Telefon nie ma oświetlacza podczerwieni – w całkowitej ciemności włącz lampę. " +
                "Drużyna widzi ten obraz w „Podglądzie”, słyszy dźwięk i może sterować kamerą.", 11, Ui.DIM, false);
        info.setPadding(dp(4), dp(14), dp(4), 0);
        panel.addView(info);
        refreshControls();
    }

    @Override
    String title() {
        return "Kamera";
    }

    @Override
    void onShow() {
        core.camActive = true;
        core.cmdSink = this;
        if (worker == null) {
            worker = new HandlerThread("cam-worker");
            worker.start();
            wh = new Handler(worker.getLooper());
        }
        act.withPermission(Manifest.permission.CAMERA, () -> {
            openCam();
            act.withPermission(Manifest.permission.RECORD_AUDIO, this::startAudio);
        });
    }

    @Override
    void onHide() {
        core.camActive = false;
        if (core.cmdSink == this) core.cmdSink = null;
        if (recorder != null) toggleRec();
        stopAudio();
        closeCam();
        if (worker != null) {
            worker.quitSafely();
            worker = null;
            wh = null;
        }
    }

    // ================= TextureView =================

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
        surface = st;
        if (cam != null) {
            try {
                cam.setPreviewTexture(st);
                cam.startPreview();
            } catch (Exception ignored) { }
        } else if (core.camActive && act.has(Manifest.permission.CAMERA)) openCam();
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
        applyView();
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        surface = null;
        closeCam();
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture st) { }

    // ================= kamera =================

    private void openCam() {
        if (cam != null || !core.camActive || surface == null) return;
        try {
            boolean hq = core.prefs.getBoolean("cam_hq", false);
            int tw = hq ? 960 : 640, th = hq ? 720 : 480;
            cam = Camera.open(camId);
            Camera.Parameters p = cam.getParameters();
            Camera.Size best = null;
            for (Camera.Size s : p.getSupportedPreviewSizes()) {
                if (s.width > tw * 1.25f || s.width * 3 != s.height * 4) continue;
                if (best == null || Math.abs(s.width - tw) < Math.abs(best.width - tw)) best = s;
            }
            if (best == null) for (Camera.Size s : p.getSupportedPreviewSizes())
                if (best == null || Math.abs(s.width * s.height - tw * th) < Math.abs(best.width * best.height - tw * th)) best = s;
            if (best != null) p.setPreviewSize(best.width, best.height);
            p.setPreviewFormat(ImageFormat.NV21);
            List<String> fm = p.getSupportedFocusModes();
            if (fm != null && fm.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO))
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            // tryb normalny: ~15–20 kl./s oszczędza baterię; noktowizja: najniższy zakres = najdłuższe naświetlanie
            normalFps = null;
            darkFps = null;
            for (int[] r : p.getSupportedPreviewFpsRange()) {
                if (r[1] <= 20000 && (normalFps == null || r[1] > normalFps[1])) normalFps = r;
                if (darkFps == null || r[0] < darkFps[0] || (r[0] == darkFps[0] && r[1] > darkFps[1])) darkFps = r;
            }
            cam.setParameters(p);
            Camera.Size s = cam.getParameters().getPreviewSize();
            pw = s.width;
            ph = s.height;
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(camId, info);
            front = info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT;
            rotation = info.orientation;
            cam.setDisplayOrientation(front ? (360 - info.orientation) % 360 : info.orientation);
            cam.setPreviewTexture(surface);
            int size = pw * ph * ImageFormat.getBitsPerPixel(ImageFormat.NV21) / 8;
            for (int i = 0; i < 2; i++) cam.addCallbackBuffer(new byte[size]);
            cam.setPreviewCallbackWithBuffer(this);
            cam.startPreview();
            feed.rot = rotation;
            feed.mirror = front;
            feed.label = core.myName + " · CAM " + (camId + 1);
            prevY = null;
            acc = null;
            applyParams();
        } catch (Exception e) {
            closeCam();
            core.toast("Nie udało się uruchomić kamery");
        }
    }

    private void closeCam() {
        if (cam != null) {
            try {
                cam.setPreviewCallbackWithBuffer(null);
                cam.stopPreview();
            } catch (Exception ignored) { }
            cam.release();
            cam = null;
        }
    }

    private void switchCam() {
        int n = Camera.getNumberOfCameras();
        if (n < 2) return;
        if (recorder != null) toggleRec();
        closeCam();
        camId = (camId + 1) % n;
        flash = false;
        pz.set(1, 0.5f, 0.5f);
        openCam();
    }

    private void applyParams() {
        if (cam != null) {
            try {
                Camera.Parameters p = cam.getParameters();
                List<String> fl = p.getSupportedFlashModes();
                if (fl != null && fl.contains(Camera.Parameters.FLASH_MODE_TORCH))
                    p.setFlashMode(flash ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
                p.setExposureCompensation(nv ? p.getMaxExposureCompensation() : 0);
                cam.setParameters(p);
            } catch (Exception ignored) { }
            try {
                Camera.Parameters p = cam.getParameters();
                int[] f = nv ? darkFps : normalFps;
                if (f != null) p.setPreviewFpsRange(f[0], f[1]);
                cam.setParameters(p);
            } catch (Exception ignored) { }
            try {
                Camera.Parameters p = cam.getParameters();
                List<String> sm = p.getSupportedSceneModes();
                if (sm != null && sm.contains(Camera.Parameters.SCENE_MODE_NIGHT))
                    p.setSceneMode(nv ? Camera.Parameters.SCENE_MODE_NIGHT : Camera.Parameters.SCENE_MODE_AUTO);
                cam.setParameters(p);
            } catch (Exception ignored) { }
            try { // najwyższe ISO, jeśli telefon je udostępnia
                Camera.Parameters p = cam.getParameters();
                String iso = p.get("iso-values");
                if (iso != null) {
                    String bestIso = "auto";
                    int best = 0;
                    for (String v : iso.split(",")) {
                        String d = v.replaceAll("[^0-9]", "");
                        if (!d.isEmpty() && Integer.parseInt(d) > best) { best = Integer.parseInt(d); bestIso = v.trim(); }
                    }
                    p.set("iso", nv ? bestIso : "auto");
                    cam.setParameters(p);
                }
            } catch (Exception ignored) { }
        }
        feed.nv = nv;
        feed.flash = flash;
        feed.motionOn = motionOn;
        feed.overlayOnly = !nv;
        if (!nv) feed.frame = null;
        acc = null;
        ignoreMotionUntil = System.currentTimeMillis() + 2500;
        refreshControls();
        feed.invalidate();
    }

    /** Zoom/kierunek: podgląd na żywo przez transformację, klatki dla drużyny przez wycinanie. */
    private void applyView() {
        int W = tex.getWidth(), H = tex.getHeight();
        if (W > 0 && H > 0) {
            Matrix m = new Matrix();
            m.setScale(pz.z, pz.z);
            m.postTranslate(W / 2f - pz.u * W * pz.z, H / 2f - pz.v * H * pz.z);
            tex.setTransform(m);
        }
        feed.zoomText = pz.z > 1.05f ? String.format(Locale.US, "%.1f×", pz.z) : "";
        acc = null;
        refreshControls();
        feed.invalidate();
    }

    private void refreshControls() {
        flashB.set(flash);
        nvB.set(nv);
        motionB.set(motionOn);
        micB.set(micOn && audioRun);
        recB.set(recorder != null);
        feed.mic = micOn && audioRun;
        for (int i = 0; i < 4; i++) {
            boolean on = Math.round(pz.z) == i + 1 && Math.abs(pz.z - (i + 1)) < 0.25f;
            chips[i].setTextColor(on ? Ui.BG : Ui.TEXT);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(dp(17));
            g.setColor(on ? Ui.ACCENT : Ui.CARD2);
            chips[i].setBackground(g);
        }
        // NV: przyciemnione zielone tło podglądu (zanim przyjdzie przetworzona klatka)
        if (nv) {
            nvPaint.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(new float[]{
                    0.15f, 0.3f, 0.05f, 0, 0, 0.6f, 1.2f, 0.25f, 0, 20, 0.15f, 0.3f, 0.05f, 0, 0, 0, 0, 0, 1, 0})));
            tex.setLayerPaint(nvPaint);
        } else {
            tex.setLayerPaint(null);
        }
    }

    /** Polecenia z innego telefonu. */
    @Override
    public void onCmd(JSONObject j) {
        String c = j.optString("c"), from = j.optString("name");
        String what = null;
        switch (c) {
            case "flash": flash = j.optBoolean("v"); what = flash ? "włączył lampę" : "wyłączył lampę"; break;
            case "nv": nv = j.optBoolean("v"); what = nv ? "włączył noktowizję" : "wyłączył noktowizję"; break;
            case "motion": motionOn = j.optBoolean("v"); what = motionOn ? "włączył wykrywanie ruchu" : "wyłączył wykrywanie ruchu"; break;
            case "view":
                pz.set((float) j.optDouble("z", 1), (float) j.optDouble("u", 0.5), (float) j.optDouble("v", 0.5));
                applyView();
                return;
            default: return;
        }
        applyParams();
        core.toast(from + " " + what);
    }

    // ================= klatki =================

    @Override
    public void onPreviewFrame(byte[] data, Camera c) {
        long now = System.currentTimeMillis();
        if (motionOn && now - lastMotionCheck > 200) {
            lastMotionCheck = now;
            detectMotion(data, pw, ph, now);
        }
        boolean watched = core.net.isConnected() && now - core.lastWatched < 6000;
        boolean need = nv || watched || recorder != null || photoRequested;
        long interval = (nv || recorder != null) ? 85 : 120;
        Handler h = wh;
        if (need && h != null && now - lastProc >= interval && busy.compareAndSet(false, true)) {
            lastProc = now;
            final byte[] copy = data.clone();
            final int w = pw, hh = ph;
            final Rect crop = cropRect(w, hh);
            final boolean send = watched;
            h.post(() -> process(copy, w, hh, crop, send));
        }
        c.addCallbackBuffer(data);
    }

    /** Wycinek klatki (w układzie sensora) odpowiadający zoomowi i kierunkowi z ekranu. */
    private Rect cropRect(int w, int h) {
        float z = pz.z, u = pz.u, v = pz.v;
        if (front) u = 1 - u;
        float sx, sy;
        switch (rotation) {
            case 90: sx = v; sy = 1 - u; break;
            case 270: sx = 1 - v; sy = u; break;
            case 180: sx = 1 - u; sy = 1 - v; break;
            default: sx = u; sy = v;
        }
        int cw = ((int) (w / z)) & ~1, ch = ((int) (h / z)) & ~1;
        int l = Math.max(0, Math.min(w - cw, (int) (sx * w - cw / 2f))) & ~1;
        int t = Math.max(0, Math.min(h - ch, (int) (sy * h - ch / 2f))) & ~1;
        return new Rect(l, t, l + cw, t + ch);
    }

    private void process(byte[] d, int w, int h, Rect r, boolean send) {
        try {
            long now = System.currentTimeMillis();
            if (nv) enhance(d, w, h, r);
            byte[] jpg = null;
            if (send || (!nv && (recorder != null || photoRequested))) {
                YuvImage yi = new YuvImage(d, ImageFormat.NV21, w, h, null);
                ByteArrayOutputStream bo = new ByteArrayOutputStream(65536);
                yi.compressToJpeg(r, 62, bo);
                jpg = bo.toByteArray();
            }
            if (send && jpg != null && now - lastSend > 110) {
                lastSend = now;
                core.net.send(frameMsg(jpg, now));
            }
            Bitmap bm;
            if (nv) {
                bm = grayBitmap(d, w, r);
                feed.setFrame(bm, now);
            } else {
                bm = (recorder != null || photoRequested) && jpg != null ? BitmapFactory.decodeByteArray(jpg, 0, jpg.length) : null;
            }
            if (bm != null) {
                VideoRecorder rec = recorder;
                if (rec != null) rec.addFrame(feed.compose(bm, recW, recH));
                if (photoRequested) {
                    photoRequested = false;
                    final Bitmap shot = bm;
                    boolean swap = rotation % 180 != 0;
                    final int pw2 = swap ? 720 : 960, ph2 = swap ? 960 : 720;
                    core.main.post(() -> Gallery.photoFromBitmap(core, act, feed, shot, pw2, ph2,
                            "Zdjęcie z kamery (" + core.myName + ")"));
                }
            }
        } catch (Exception ignored) {
        } finally {
            busy.set(false);
        }
    }

    /**
     * Noktowizja: automatyczna krzywa jasności (im ciemniej, tym mocniej rozjaśnia)
     * + odszumianie przez uśrednianie kolejnych klatek. Kolor usuwany (obraz monochromatyczny).
     */
    private void enhance(byte[] d, int w, int h, Rect r) {
        long sum = 0;
        int cnt = 0;
        for (int y = r.top; y < r.bottom; y += 8)
            for (int x = r.left; x < r.right; x += 8) { sum += d[y * w + x] & 255; cnt++; }
        double mean = Math.max(1.5, sum / (double) Math.max(1, cnt));
        double gamma = Math.log(125 / 255.0) / Math.log(mean / 255.0);
        gamma = Math.max(0.18, Math.min(1.0, gamma));
        byte[] lut = new byte[4096];
        for (int i = 0; i < 4096; i++) {
            double v = Math.pow(i / 4095.0, gamma) * 255.0 * 1.08;
            lut[i] = (byte) Math.max(0, Math.min(255, (int) v));
        }
        int cw = r.width(), ch = r.height();
        if (acc == null || accRect == null || !accRect.equals(r)) {
            acc = new int[cw * ch];
            accRect = new Rect(r);
            for (int y = 0; y < ch; y++)
                for (int x = 0; x < cw; x++) acc[y * cw + x] = (d[(y + r.top) * w + x + r.left] & 255) << 4;
        }
        int[] a = acc;
        for (int y = 0; y < ch; y++) {
            int row = (y + r.top) * w + r.left, ar = y * cw;
            for (int x = 0; x < cw; x++) {
                int v = (a[ar + x] * 3 + ((d[row + x] & 255) << 4)) >> 2;
                a[ar + x] = v;
                d[row + x] = lut[Math.min(4095, v)];
            }
        }
        int uvStart = w * h;
        for (int y = r.top / 2; y < r.bottom / 2; y++) {
            int row = uvStart + y * w;
            for (int x = r.left; x < r.right; x++) d[row + x] = (byte) 128;
        }
    }

    private Bitmap grayBitmap(byte[] d, int w, Rect r) {
        int cw = r.width(), ch = r.height();
        if (argb == null || argb.length != cw * ch) argb = new int[cw * ch];
        int[] px = argb;
        for (int y = 0; y < ch; y++) {
            int row = (y + r.top) * w + r.left, o = y * cw;
            for (int x = 0; x < cw; x++) {
                int g = d[row + x] & 255;
                px[o + x] = 0xFF000000 | (g << 16) | (g << 8) | g;
            }
        }
        Bitmap b = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888);
        b.setPixels(px, 0, cw, 0, 0, cw, ch);
        return b;
    }

    private Net.Msg frameMsg(byte[] jpg, long now) {
        JSONObject o = Net.Msg.obj("frame");
        try {
            o.put("from", core.myId);
            o.put("name", core.myName);
            o.put("ts", now);
            o.put("rot", rotation);
            o.put("mirror", front);
            o.put("nv", nv);
            o.put("flash", flash);
            o.put("motion", motionOn);
            o.put("alert", now < feed.motionUntil);
            o.put("z", (double) pz.z);
            o.put("u", (double) pz.u);
            o.put("v", (double) pz.v);
            o.put("mic", micOn && audioRun);
        } catch (JSONException ignored) { }
        return new Net.Msg(o, jpg);
    }

    private void detectMotion(byte[] d, int w, int h, long now) {
        int step = 16, cols = w / step, rows = h / step;
        byte[] cur = new byte[cols * rows];
        for (int y = 0; y < rows; y++)
            for (int x = 0; x < cols; x++) cur[y * cols + x] = d[(y * step) * w + x * step];
        byte[] prev = prevY;
        prevY = cur;
        if (prev == null || prev.length != cur.length) return;
        long diff = 0;
        for (int i = 0; i < cur.length; i++) diff += Math.abs((cur[i] & 255) - (prev[i] & 255));
        float mean = diff / (float) cur.length;
        if (mean > 12f && now > ignoreMotionUntil && now - lastMotion > 5000) {
            lastMotion = now;
            feed.motionUntil = now + 2000;
            feed.invalidate();
            core.alert("Kamera (" + core.myName + "): wykryto ruch");
        }
    }

    // ================= dźwięk =================

    private void startAudio() {
        if (audioRun || !core.camActive) return;
        audioRun = true;
        audioThread = new Thread(this::audioLoop, "cam-audio");
        audioThread.start();
        refreshControls();
    }

    private void stopAudio() {
        audioRun = false;
        if (audioThread != null) {
            try { audioThread.join(600); } catch (InterruptedException ignored) { }
            audioThread = null;
        }
    }

    private void audioLoop() {
        final int sr = VideoRecorder.AUDIO_RATE;
        AudioRecord rec = null;
        try {
            int minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            rec = new AudioRecord(MediaRecorder.AudioSource.CAMCORDER, sr, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, sr));
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                rec.release();
                rec = new AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, sr));
            }
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) return;
            rec.startRecording();
            short[] buf = new short[sr / 10];
            while (audioRun) {
                int r = rec.read(buf, 0, buf.length);
                if (r <= 0 || !micOn) continue;
                long pts = System.nanoTime() / 1000 - r * 1_000_000L / sr;
                VideoRecorder vr = recorder;
                if (vr != null) vr.addAudio(buf, r, pts);
                if (core.net.isConnected() && System.currentTimeMillis() - core.lastWatched < 6000) {
                    ByteBuffer bb = ByteBuffer.allocate(r * 2).order(ByteOrder.LITTLE_ENDIAN);
                    bb.asShortBuffer().put(buf, 0, r);
                    JSONObject o = Net.Msg.obj("audio");
                    try { o.put("from", core.myId); } catch (JSONException ignored) { }
                    core.net.send(new Net.Msg(o, bb.array()));
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (rec != null) {
                try { rec.stop(); } catch (Exception ignored) { }
                rec.release();
            }
            audioRun = false;
        }
    }

    // ================= nagrywanie =================

    private void toggleRec() {
        if (recorder != null) {
            final VideoRecorder r = recorder;
            recorder = null;
            feed.rec = false;
            r.stop(ok -> Gallery.finishVideo(core, act, r.file, ok, "Nagranie z kamery (" + core.myName + ")"));
        } else {
            if (cam == null) {
                core.toast("Kamera nie działa");
                return;
            }
            boolean swap = rotation % 180 != 0;
            boolean hq = pw >= 900;
            recW = swap ? (hq ? 720 : 480) : (hq ? 960 : 640);
            recH = swap ? (hq ? 960 : 640) : (hq ? 720 : 480);
            File f = new File(act.getCacheDir(), "Cam_" + Ui.fileStamp() + ".mp4");
            recorder = new VideoRecorder(f, recW, recH, audioRun && micOn);
            feed.rec = true;
        }
        refreshControls();
        feed.invalidate();
    }
}
