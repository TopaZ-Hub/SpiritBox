package pl.duchy.spiritbox;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Ustawienia: motyw, nazwa, jakość kamery, dźwięki. */
final class SettingsScreen extends Screen {

    private final Button camQ, emfSnd, words;

    SettingsScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(14), dp(4), dp(14), dp(28));
        sv.addView(root);
        addView(sv);

        // --- motyw ---
        root.addView(Ui.section(a, "kolor motywu"));
        LinearLayout sw = Ui.row(a);
        for (int i = 0; i < Ui.ACCENTS.length; i++) {
            final int col = Ui.ACCENTS[i];
            TextView t = new TextView(a);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(col);
            if (col == Ui.ACCENT) g.setStroke(dp(3), Ui.TEXT);
            t.setBackground(g);
            t.setOnClickListener(v -> {
                core.prefs.edit().putInt("accent", col).apply();
                Ui.load(core.prefs);
                act.rebuild("settings");
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(38), dp(38));
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            sw.addView(t, lp);
        }
        root.addView(sw);
        String name = "";
        for (int i = 0; i < Ui.ACCENTS.length; i++) if (Ui.ACCENTS[i] == Ui.ACCENT) name = Ui.ACCENT_NAMES[i];
        root.addView(Ui.text(a, "Wybrany: " + name, 13, Ui.DIM, false));

        // --- nazwa ---
        root.addView(Ui.section(a, "twoja nazwa w drużynie"));
        LinearLayout nr = Ui.row(a);
        nr.setGravity(Gravity.CENTER_VERTICAL);
        EditText et = new EditText(a);
        et.setText(core.myName);
        et.setTextColor(Ui.TEXT);
        et.setSingleLine(true);
        Button save = Ui.btn(a, "ZAPISZ");
        save.setOnClickListener(v -> {
            core.setName(et.getText().toString());
            core.toast("Nazwa: " + core.myName);
        });
        nr.addView(et, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        nr.addView(save);
        root.addView(nr);

        // --- kamera ---
        root.addView(Ui.section(a, "kamera"));
        camQ = Ui.btn(a, "");
        camQ.setOnClickListener(v -> {
            core.prefs.edit().putBoolean("cam_hq", !core.prefs.getBoolean("cam_hq", false)).apply();
            refresh();
        });
        root.addView(camQ, Ui.matchWrap(a, 2));
        root.addView(Ui.text(a, "Oszczędna (640×480) mniej grzeje telefon i mniej zużywa baterię. " +
                "Wysoka (960×720) daje ostrzejszy zoom.", 12, Ui.DIM, false));

        // --- dźwięki ---
        root.addView(Ui.section(a, "dźwięk i nasłuch"));
        emfSnd = Ui.btn(a, "");
        emfSnd.setOnClickListener(v -> {
            core.prefs.edit().putBoolean("emf_sound", !core.prefs.getBoolean("emf_sound", true)).apply();
            refresh();
        });
        root.addView(emfSnd, Ui.matchWrap(a, 2));
        words = Ui.btn(a, "");
        words.setOnClickListener(v -> {
            core.prefs.edit().putBoolean("words_auto", !core.prefs.getBoolean("words_auto", true)).apply();
            refresh();
        });
        root.addView(words, Ui.matchWrap(a, 2));
        root.addView(Ui.text(a, "Nasłuch słów: gdy Spirit Box skanuje, telefon rozpoznaje mowę i wpisuje wykryte " +
                "słowa do dziennika razem z nagraniem. Wymaga rozpoznawania mowy Google (zwykle wbudowane). " +
                "Działa najlepiej bez słuchawek, z głośnikiem telefonu.", 12, Ui.DIM, false));

        root.addView(Ui.section(a, "o aplikacji"));
        root.addView(Ui.text(a, "Ghost Kit 5.0", 13, Ui.DIM, false));
        refresh();
    }

    private void refresh() {
        boolean hq = core.prefs.getBoolean("cam_hq", false);
        camQ.setText("JAKOŚĆ: " + (hq ? "WYSOKA" : "OSZCZĘDNA"));
        boolean es = core.prefs.getBoolean("emf_sound", true);
        emfSnd.setText("PISK MIERNIKA EMF: " + (es ? "WŁ" : "WYŁ"));
        Ui.active(emfSnd, es);
        boolean w = core.prefs.getBoolean("words_auto", true);
        words.setText("NASŁUCH SŁÓW W SPIRIT BOXIE: " + (w ? "WŁ" : "WYŁ"));
        Ui.active(words, w);
    }

    @Override
    String title() {
        return "USTAWIENIA";
    }
}
