package pl.duchy.spiritbox;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Gravity;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Podgląd kamery innego telefonu: obraz + dźwięk, zdalny zoom/kierunek/lampa/noktowizja, zapis u siebie. */
final class ViewerScreen extends Screen implements Core.FrameSink, Core.AudioSink {

    private final FeedView feed;
    private final LinearLayout camList;
    private final TextView hint;
    private final Controls.Round flashB, nvB, motionB, soundB;
    private final Controls.Shutter recB;
    private final TextView[] chips = new TextView[4];
    private final Controls.PanZoom pz;
    private String selected = null, selName = "";
    private volatile boolean rFlash, rNv, rMotion = true;
    private boolean sound = true, touching = false;
    private VideoRecorder recorder;
    private int recW = 480, recH = 640;
    private HandlerThread worker, audioWorker;
    private Handler wh, ah;
    private AudioTrack track;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private String listSig = "";
    private long lastSub = 0, lastCmd = 0, lastViewSend = 0;

    ViewerScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        sv.addView(root);
        addView(sv);

        HorizontalScrollView hs = new HorizontalScrollView(a);
        camList = Ui.row(a);
        camList.setPadding(dp(8), dp(4), dp(8), dp(6));
        hs.addView(camList);
        root.addView(hs);

        feed = new FeedView(a);
        root.addView(feed);
        pz = new Controls.PanZoom(a, (z, u, v, done) -> onLocalView(done));
        feed.setOnTouchListener(pz);

        LinearLayout panel = Ui.col(a);
        panel.setPadding(dp(12), dp(12), dp(12), dp(16));
        panel.setBackgroundColor(Ui.CARD);
        root.addView(panel);

        LinearLayout zr = Ui.row(a);
        zr.setGravity(Gravity.CENTER);
        for (int i = 0; i < 4; i++) {
            final int z = i + 1;
            chips[i] = Ui.head(a, z + "×", 13, Ui.TEXT);
            chips[i].setGravity(Gravity.CENTER);
            chips[i].setOnClickListener(v -> { pz.set(z, pz.u, pz.v); onLocalView(true); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(52), dp(34));
            lp.setMargins(dp(4), 0, dp(4), 0);
            zr.addView(chips[i], lp);
        }
        panel.addView(zr);
        TextView g = Ui.text(a, "przeciągnij obraz, by obrócić kamerę · szczypnij, by przybliżyć", 11, Ui.DIM, false);
        g.setGravity(Gravity.CENTER);
        g.setPadding(0, dp(6), 0, dp(10));
        panel.addView(g);

        LinearLayout tr = Ui.row(a);
        flashB = new Controls.Round(a, "flash");
        nvB = new Controls.Round(a, "nv");
        motionB = new Controls.Round(a, "motion");
        soundB = new Controls.Round(a, "mic");
        Ui.addWeighted(tr, Controls.labeled(a, flashB, "LAMPA", 50, v -> cmd("flash", !rFlash)));
        Ui.addWeighted(tr, Controls.labeled(a, nvB, "NOKTOWIZJA", 50, v -> cmd("nv", !rNv)));
        Ui.addWeighted(tr, Controls.labeled(a, motionB, "RUCH", 50, v -> cmd("motion", !rMotion)));
        Ui.addWeighted(tr, Controls.labeled(a, soundB, "DŹWIĘK", 50, v -> { sound = !sound; refreshControls(); }));
        panel.addView(tr);

        LinearLayout sr = Ui.row(a);
        sr.setPadding(0, dp(14), 0, 0);
        Controls.Shutter photoB = new Controls.Shutter(a, false);
        recB = new Controls.Shutter(a, true);
        Ui.addWeighted(sr, Controls.labeled(a, photoB, "ZDJĘCIE", 70, v -> {
            if (selected != null) Gallery.photo(core, act, feed, "Zdjęcie z kamery: " + selName + " (zapisał " + core.myName + ")");
        }));
        Ui.addWeighted(sr, Controls.labeled(a, recB, "NAGRYWANIE", 70, v -> toggleRec()));
        panel.addView(sr);

        hint = Ui.text(a, "", 11, Ui.DIM, false);
        hint.setPadding(dp(4), dp(14), dp(4), 0);
        panel.addView(hint);
        refreshControls();
    }

    @Override
    String title() {
        return "Podgląd";
    }

    @Override
    void onShow() {
        core.frameSink = this;
        core.audioSink = this;
        if (worker == null) {
            worker = new HandlerThread("view-worker");
            worker.start();
            wh = new Handler(worker.getLooper());
        }
        if (audioWorker == null) {
            audioWorker = new HandlerThread("view-audio");
            audioWorker.start();
            ah = new Handler(audioWorker.getLooper());
            ah.post(this::openTrack);
        }
        if (selected != null) core.net.subscribe(selected, true);
        listSig = "";
    }

    @Override
    void onHide() {
        if (core.frameSink == this) core.frameSink = null;
        if (core.audioSink == this) core.audioSink = null;
        if (selected != null) core.net.subscribe(selected, false);
        if (recorder != null) toggleRec();
        if (worker != null) {
            worker.quitSafely();
            worker = null;
            wh = null;
        }
        if (audioWorker != null) {
            final AudioTrack t = track;
            track = null;
            ah.post(() -> {
                if (t != null) {
                    try { t.stop(); } catch (Exception ignored) { }
                    t.release();
                }
            });
            audioWorker.quitSafely();
            audioWorker = null;
            ah = null;
        }
    }

    private void openTrack() {
        try {
            int sr = VideoRecorder.AUDIO_RATE;
            int minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(sr)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(minBuf * 3, sr / 2))
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
            track.play();
        } catch (Exception e) {
            track = null;
        }
    }

    @Override
    void tick() {
        long now = System.currentTimeMillis();
        if (selected != null && now - lastSub > 2000) {
            lastSub = now;
            core.net.subscribe(selected, true);
        }
        List<Core.Member> cams = core.cameras();
        StringBuilder sig = new StringBuilder();
        for (Core.Member m : cams) sig.append(m.id).append(m.name).append(';');
        String s = sig.toString() + core.net.isConnected() + selected;
        if (!s.equals(listSig)) {
            listSig = s;
            camList.removeAllViews();
            for (Core.Member m : cams) {
                TextView b = Ui.head(act, "● " + m.name.toUpperCase(Locale.getDefault()), 12,
                        m.id.equals(selected) ? Ui.BG : Ui.TEXT);
                b.setPadding(dp(14), dp(8), dp(14), dp(8));
                GradientDrawable gd = new GradientDrawable();
                gd.setCornerRadius(dp(16));
                gd.setColor(m.id.equals(selected) ? Ui.ACCENT : Ui.CARD2);
                gd.setStroke(dp(1), Ui.STROKE);
                b.setBackground(gd);
                b.setOnClickListener(v -> select(m.id, m.name));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, dp(8), 0);
                camList.addView(b, lp);
            }
            String h;
            if (!core.net.isConnected()) h = "Nie jesteś w drużynie – wejdź w „Drużyna” i połącz telefony.";
            else if (cams.isEmpty()) h = "Nikt nie ma włączonej kamery. Na innym telefonie otwórz „Kamera”.";
            else if (selected == null) h = "Wybierz kamerę z listy u góry.";
            else h = "Zdjęcia i nagrania (z dźwiękiem) zapisują się u ciebie, w galerii i we wspólnym dzienniku.";
            hint.setText(h);
            if (selected != null && core.members.get(selected) == null) {
                feed.frame = null;
                feed.invalidate();
            }
        }
        refreshControls();
    }

    private void select(String id, String name) {
        if (id.equals(selected)) return;
        if (recorder != null) toggleRec();
        if (selected != null) core.net.subscribe(selected, false);
        selected = id;
        selName = name;
        feed.frame = null;
        feed.label = name;
        feed.invalidate();
        pz.set(1, 0.5f, 0.5f);
        core.net.subscribe(id, true);
        lastSub = System.currentTimeMillis();
        listSig = "";
    }

    private void onLocalView(boolean done) {
        if (selected == null) return;
        touching = !done;
        long now = System.currentTimeMillis();
        if (done || now - lastViewSend > 80) {
            lastViewSend = now;
            lastCmd = now;
            core.sendView(selected, pz.z, pz.u, pz.v);
        }
        refreshControls();
    }

    private void cmd(String c, boolean v) {
        if (selected == null) {
            core.toast("Najpierw wybierz kamerę");
            return;
        }
        core.sendCmd(selected, c, v);
        lastCmd = System.currentTimeMillis();
        switch (c) {
            case "flash": rFlash = v; break;
            case "nv": rNv = v; break;
            case "motion": rMotion = v; break;
        }
        refreshControls();
    }

    private void refreshControls() {
        if (flashB.on != rFlash) flashB.set(rFlash);
        if (nvB.on != rNv) nvB.set(rNv);
        if (motionB.on != rMotion) motionB.set(rMotion);
        if (soundB.on != sound) soundB.set(sound);
        if (recB.recording != (recorder != null)) recB.set(recorder != null);
        for (int i = 0; i < 4; i++) {
            boolean on = Math.abs(pz.z - (i + 1)) < 0.25f;
            int fg = on ? Ui.BG : Ui.TEXT;
            if (chips[i].getCurrentTextColor() != fg) {
                chips[i].setTextColor(fg);
                GradientDrawable g = new GradientDrawable();
                g.setCornerRadius(dp(17));
                g.setColor(on ? Ui.ACCENT : Ui.CARD2);
                chips[i].setBackground(g);
            }
        }
    }

    // ================= dane z sieci =================

    @Override
    public void onFrame(Net.Msg m) {
        if (selected == null || !selected.equals(m.j.optString("from")) || m.bin == null) return;
        Handler h = wh;
        if (h == null || !busy.compareAndSet(false, true)) return;
        h.post(() -> {
            try {
                Bitmap b = BitmapFactory.decodeByteArray(m.bin, 0, m.bin.length);
                if (b == null) return;
                boolean fresh = System.currentTimeMillis() - lastCmd > 1500;
                if (fresh) {
                    rFlash = m.j.optBoolean("flash");
                    rNv = m.j.optBoolean("nv");
                    rMotion = m.j.optBoolean("motion", true);
                }
                if (fresh && !touching)
                    pz.set((float) m.j.optDouble("z", 1), (float) m.j.optDouble("u", 0.5), (float) m.j.optDouble("v", 0.5));
                float z = (float) m.j.optDouble("z", 1);
                feed.rot = m.j.optInt("rot", 90);
                feed.mirror = m.j.optBoolean("mirror");
                feed.nv = m.j.optBoolean("nv");
                feed.flash = m.j.optBoolean("flash");
                feed.motionOn = m.j.optBoolean("motion", true);
                feed.mic = m.j.optBoolean("mic");
                feed.zoomText = z > 1.05f ? String.format(Locale.US, "%.1f×", z) : "";
                feed.label = m.j.optString("name", selName);
                if (m.j.optBoolean("alert")) feed.motionUntil = System.currentTimeMillis() + 1500;
                feed.setFrame(b, m.j.optLong("ts", System.currentTimeMillis()));
                VideoRecorder r = recorder;
                if (r != null) r.addFrame(feed.compose(b, recW, recH));
            } catch (Exception ignored) {
            } finally {
                busy.set(false);
            }
        });
    }

    @Override
    public void onAudio(Net.Msg m) {
        if (selected == null || !selected.equals(m.j.optString("from")) || m.bin == null) return;
        Handler h = ah;
        if (h == null) return;
        final byte[] data = m.bin;
        h.post(() -> {
            int n = data.length / 2;
            short[] pcm = new short[n];
            ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(pcm);
            VideoRecorder r = recorder;
            if (r != null) r.addAudio(pcm, n, System.nanoTime() / 1000 - n * 1_000_000L / VideoRecorder.AUDIO_RATE);
            AudioTrack t = track;
            if (sound && t != null) t.write(pcm, 0, n);
        });
    }

    private void toggleRec() {
        if (recorder != null) {
            final VideoRecorder r = recorder;
            recorder = null;
            feed.rec = false;
            r.stop(ok -> Gallery.finishVideo(core, act, r.file, ok,
                    "Nagranie z kamery: " + selName + " (zapisał " + core.myName + ")"));
        } else {
            if (selected == null || feed.frame == null) {
                core.toast("Brak obrazu");
                return;
            }
            boolean swap = feed.rot % 180 != 0;
            recW = swap ? 480 : 640;
            recH = swap ? 640 : 480;
            File f = new File(act.getCacheDir(), "View_" + Ui.fileStamp() + ".mp4");
            recorder = new VideoRecorder(f, recW, recH, true);
            feed.rec = true;
        }
        refreshControls();
        feed.invalidate();
    }
}
