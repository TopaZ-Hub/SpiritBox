package pl.duchy.spiritbox;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.Surface;

import java.io.File;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicInteger;

/** Nagrywa kolejne klatki (Bitmap) do pliku MP4 (H.264) sprzętowym koderem telefonu. */
final class VideoRecorder {

    interface Done { void onDone(boolean ok); }

    final File file;
    private final int vw, vh;
    private final HandlerThread th = new HandlerThread("video-rec");
    private final Handler h;
    private final AtomicInteger pending = new AtomicInteger();
    private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
    private MediaCodec codec;
    private MediaMuxer mux;
    private Surface surface;
    private int track = -1;
    private boolean muxing = false;
    private volatile boolean failed = false;
    private int frames = 0;

    VideoRecorder(File f, int w, int h) {
        file = f;
        vw = w;
        vh = h;
        th.start();
        this.h = new Handler(th.getLooper());
        this.h.post(this::init);
    }

    private void init() {
        try {
            MediaFormat fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, vw, vh);
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 2_500_000);
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE, 15);
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            surface = codec.createInputSurface();
            codec.start();
            mux = new MediaMuxer(file.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        } catch (Exception e) {
            failed = true;
        }
    }

    boolean isFailed() {
        return failed;
    }

    void addFrame(Bitmap b) {
        if (failed || pending.get() > 3) return; // koder nie nadąża – pomijamy klatkę
        pending.incrementAndGet();
        h.post(() -> {
            pending.decrementAndGet();
            if (failed || surface == null) return;
            try {
                Canvas c = surface.lockHardwareCanvas();
                c.drawColor(Color.BLACK);
                c.drawBitmap(b, null, new Rect(0, 0, vw, vh), null);
                surface.unlockCanvasAndPost(c);
                frames++;
                drain(false);
            } catch (Exception e) {
                failed = true;
            }
        });
    }

    void stop(Done done) {
        h.post(() -> {
            boolean ok = false;
            try {
                if (codec != null && !failed) {
                    codec.signalEndOfInputStream();
                    drain(true);
                }
            } catch (Exception e) {
                failed = true;
            }
            try { if (codec != null) codec.stop(); } catch (Exception ignored) { }
            try { if (codec != null) codec.release(); } catch (Exception ignored) { }
            if (surface != null) surface.release();
            try {
                if (muxing) {
                    mux.stop();
                    ok = !failed && frames > 0;
                }
            } catch (Exception e) {
                ok = false;
            }
            try { if (mux != null) mux.release(); } catch (Exception ignored) { }
            final boolean result = ok;
            new Handler(Looper.getMainLooper()).post(() -> done.onDone(result));
            th.quitSafely();
        });
    }

    private void drain(boolean end) {
        int tries = 0;
        while (true) {
            int idx = codec.dequeueOutputBuffer(info, end ? 10000 : 0);
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end || ++tries > 100) break;
            } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = mux.addTrack(codec.getOutputFormat());
                mux.start();
                muxing = true;
            } else if (idx >= 0) {
                ByteBuffer bb = codec.getOutputBuffer(idx);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                if (info.size > 0 && muxing && bb != null) {
                    bb.position(info.offset);
                    bb.limit(info.offset + info.size);
                    mux.writeSampleData(track, bb, info);
                }
                codec.releaseOutputBuffer(idx, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
    }
}
