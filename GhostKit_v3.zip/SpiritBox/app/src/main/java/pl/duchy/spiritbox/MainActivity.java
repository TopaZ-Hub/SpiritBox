package pl.duchy.spiritbox;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

/** Jedna aktywność, w której przełączamy "ekrany" narzędzi. */
public class MainActivity extends Activity {

    static final int REQ_PICK_AUDIO = 900;

    private Core core;
    private FrameLayout content;
    private TextView titleView, backView, teamView;
    private Screen current;
    private final Map<String, Screen> screens = new HashMap<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean resumed = false;

    private final Map<Integer, Runnable> permCallbacks = new HashMap<>();
    private int nextReq = 100;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (current != null) current.tick();
            updateTeam();
            h.postDelayed(this, 66);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        core = Core.get(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        LinearLayout root = Ui.col(this);
        root.setBackgroundColor(Ui.BG);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(ins.getSystemWindowInsetLeft(), ins.getSystemWindowInsetTop(),
                    ins.getSystemWindowInsetRight(), ins.getSystemWindowInsetBottom());
            return ins.consumeSystemWindowInsets();
        });

        LinearLayout bar = Ui.row(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
        bar.setBackgroundColor(0xFF0E0E0E);
        backView = Ui.text(this, "◀ SPRZĘT", 14, Ui.ACCENT, true);
        backView.setPadding(0, Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
        backView.setOnClickListener(v -> open("menu"));
        titleView = Ui.text(this, "", 16, Ui.TEXT, true);
        teamView = Ui.text(this, "", 13, Ui.DIM, true);
        teamView.setOnClickListener(v -> open("team"));
        bar.addView(backView);
        bar.addView(titleView, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(teamView);
        root.addView(bar);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        open("menu");
    }

    private Screen create(String key) {
        switch (key) {
            case "box": return new SpiritBoxScreen(this);
            case "emf": return new EmfScreen(this);
            case "thermo": return new ThermoScreen(this);
            case "cam": return new CamScreen(this);
            case "view": return new ViewerScreen(this);
            case "motion": return new MotionScreen(this);
            case "cross": return new CrossScreen(this);
            case "music": return new MusicScreen(this);
            case "book": return new BookScreen(this);
            case "team": return new TeamScreen(this);
            default: return new MenuScreen(this);
        }
    }

    void open(String key) {
        Screen s = screens.get(key);
        if (s == null) {
            s = create(key);
            screens.put(key, s);
        }
        if (current == s) return;
        if (current != null && resumed) current.onHide();
        content.removeAllViews();
        content.addView(s, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        current = s;
        core.tool = key;
        titleView.setText(s.title());
        backView.setVisibility(key.equals("menu") ? android.view.View.GONE : android.view.View.VISIBLE);
        if (resumed) s.onShow();
    }

    private void updateTeam() {
        Net n = core.net;
        String t;
        if (n.role == Net.HOST) t = "● HOST · " + (core.members.size() + 1);
        else if (n.connecting) t = "… łączenie";
        else if (n.isConnected()) t = "● DRUŻYNA · " + (core.members.size() + 1);
        else t = "○ SOLO";
        if (!t.contentEquals(teamView.getText())) {
            teamView.setText(t);
            teamView.setTextColor(n.isConnected() ? Ui.GREEN : Ui.DIM);
        }
    }

    // ================= uprawnienia =================

    void withPermission(String perm, Runnable granted) {
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) {
            granted.run();
            return;
        }
        int req = nextReq++;
        permCallbacks.put(req, granted);
        requestPermissions(new String[]{perm}, req);
    }

    boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        Runnable r = permCallbacks.remove(code);
        if (r != null && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) r.run();
        else if (r != null) core.toast("Brak uprawnienia – ta funkcja nie zadziała");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK_AUDIO && res == RESULT_OK && data != null && data.getData() != null) {
            Screen s = screens.get("music");
            if (s instanceof MusicScreen) ((MusicScreen) s).onPicked(data.getData());
        }
    }

    // ================= cykl życia =================

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        core.sensors.start();
        if (current != null) current.onShow();
        h.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        h.removeCallbacks(ticker);
        if (current != null) current.onHide();
        core.sensors.stop();
    }

    @Override
    public void onBackPressed() {
        if (current != null && !"menu".equals(core.tool)) open("menu");
        else super.onBackPressed();
    }
}
