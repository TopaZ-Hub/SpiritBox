package pl.duchy.spiritbox;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Walizka ze sprzętem – wybór narzędzia. */
final class MenuScreen extends Screen {

    private static final String[][] TOOLS = {
            {"box", "📻", "Spirit Box", "skaner głosów"},
            {"emf", "📶", "EMF-5", "detektor pola"},
            {"thermo", "🌡️", "Termometr", "zimne miejsca"},
            {"cam", "📹", "Ghost Cam", "ta kamera"},
            {"view", "🖥️", "Podgląd kamer", "kamery drużyny"},
            {"motion", "🚨", "Czujnik ruchu", "alarm"},
            {"cross", "✝️", "Krucyfiks", "ochrona"},
            {"music", "🎵", "Pozytywka", "przywołanie"},
            {"book", "📖", "Dziennik", "dowody i nagrania"},
            {"team", "👥", "Drużyna", "połącz telefony"},
    };

    private final TextView status;

    MenuScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(12), dp(12), dp(12), dp(24));
        sv.addView(root);
        addView(sv);

        TextView h = Ui.text(a, "ZESTAW ŁOWCY DUCHÓW", 22, Ui.ACCENT, true);
        h.setGravity(Gravity.CENTER);
        h.setLetterSpacing(0.08f);
        root.addView(h);
        status = Ui.text(a, "", 13, Ui.DIM, false);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(4), 0, dp(12));
        root.addView(status);

        LinearLayout row = null;
        for (int i = 0; i < TOOLS.length; i++) {
            if (i % 2 == 0) {
                row = Ui.row(a);
                root.addView(row);
            }
            String[] t = TOOLS[i];
            LinearLayout tile = Ui.col(a);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(dp(8), dp(16), dp(8), dp(16));
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0xFF1E1E1E, 0xFF101010});
            g.setCornerRadius(dp(14));
            g.setStroke(dp(1), 0xFF2E2E2E);
            tile.setBackground(g);
            TextView icon = Ui.text(a, t[1], 34, Ui.TEXT, false);
            icon.setGravity(Gravity.CENTER);
            TextView name = Ui.text(a, t[2], 16, Ui.TEXT, true);
            name.setGravity(Gravity.CENTER);
            TextView sub = Ui.text(a, t[3], 12, Ui.DIM, false);
            sub.setGravity(Gravity.CENTER);
            tile.addView(icon);
            tile.addView(name);
            tile.addView(sub);
            final String key = t[0];
            tile.setOnClickListener(v -> act.open(key));
            Ui.addWeighted(row, tile);
        }

        TextView info = Ui.text(a, "Aplikacja rozrywkowa. Odczyty pochodzą z prawdziwych czujników telefonu " +
                "(magnetometr, akcelerometr, mikrofon, kamera), ale nie istnieje potwierdzony sposób wykrywania duchów.",
                11, 0xFF555555, false);
        info.setPadding(dp(6), dp(16), dp(6), 0);
        root.addView(info);
    }

    @Override
    String title() {
        return "Sprzęt";
    }

    @Override
    void tick() {
        String s;
        if (core.net.isConnected()) s = "Drużyna: " + (core.members.size() + 1) + " os. · ty: " + core.myName;
        else s = "Grasz solo · " + core.myName + " · dotknij „Drużyna”, by połączyć telefony";
        if (core.engine.isRunning()) s += "\n📻 Spirit Box działa w tle";
        if (!s.contentEquals(status.getText())) status.setText(s);
    }
}
