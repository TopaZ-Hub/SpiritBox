package pl.duchy.spiritbox;

import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.os.Handler;
import android.os.HandlerThread;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Ghost Cam – kamera tego telefonu. Obraz idzie też do drużyny, która może sterować latarką i noktowizją. */
@SuppressWarnings("deprecation")
final class CamScreen extends Screen implements Camera.PreviewCallback, Core.CmdSink {

    private final FeedView feed;
    private final Button flashBtn, nvBtn, motionBtn, recBtn;
    private Camera cam;
    private SurfaceTexture st;
    private int camId = 0, pw, ph;
    private boolean flash = false, nv = false, motionOn = true;
    private VideoRecorder recorder;
    private HandlerThread worker;
    private Handler wh;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private long lastSend = 0, lastMotion = 0, ignoreMotionUntil = 0;
    private byte[] prevY;

    CamScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(4), dp(4), dp(4), dp(20));
        sv.addView(root);
        addView(sv);

        feed = new FeedView(a);
        root.addView(feed);

        LinearLayout r1 = Ui.row(a);
        flashBtn = Ui.btn(a, "");
        flashBtn.setOnClickListener(v -> { flash = !flash; applyParams(); });
        nvBtn = Ui.btn(a, "");
        nvBtn.setOnClickListener(v -> { nv = !nv; applyParams(); });
        Button sw = Ui.btn(a, "🔄 Przód/Tył");
        sw.setOnClickListener(v -> switchCam());
        Ui.addWeighted(r1, flashBtn);
        Ui.addWeighted(r1, nvBtn);
        Ui.addWeighted(r1, sw);
        root.addView(r1);

        LinearLayout r2 = Ui.row(a);
        Button photo = Ui.btn(a, "📸 Zdjęcie");
        photo.setOnClickListener(v -> Gallery.photo(core, act, feed, "Zdjęcie z Ghost Cam (" + core.myName + ")"));
        recBtn = Ui.btn(a, "");
        recBtn.setOnClickListener(v -> toggleRec());
        motionBtn = Ui.btn(a, "");
        motionBtn.setOnClickListener(v -> { motionOn = !motionOn; applyParams(); });
        Ui.addWeighted(r2, photo);
        Ui.addWeighted(r2, recBtn);
        Ui.addWeighted(r2, motionBtn);
        root.addView(r2);

        TextView info = Ui.text(a, "Gdy telefony są połączone w drużynę, inni widzą tę kamerę w „Podglądzie kamer” " +
                "i mogą zdalnie włączać latarkę, noktowizję i wykrywanie ruchu oraz robić zdjęcia i nagrania u siebie. " +
                "Zostaw ten ekran otwarty – kamera działa tylko, gdy jest widoczny.", 12, Ui.DIM, false);
        info.setPadding(dp(8), dp(8), dp(8), 0);
        root.addView(info);
        refreshButtons();
    }

    @Override
    String title() {
        return "Ghost Cam";
    }

    @Override
    void onShow() {
        core.camActive = true;
        core.cmdSink = this;
        if (worker == null) {
            worker = new HandlerThread("cam-worker");
            worker.start();
            wh = new Handler(worker.getLooper());
        }
        act.withPermission(Manifest.permission.CAMERA, this::openCam);
    }

    @Override
    void onHide() {
        core.camActive = false;
        if (core.cmdSink == this) core.cmdSink = null;
        if (recorder != null) toggleRec();
        closeCam();
        if (worker != null) {
            worker.quitSafely();
            worker = null;
            wh = null;
        }
    }

    // ================= kamera =================

    private void openCam() {
        if (cam != null || !core.camActive) return;
        try {
            cam = Camera.open(camId);
            Camera.Parameters p = cam.getParameters();
            Camera.Size best = null;
            for (Camera.Size s : p.getSupportedPreviewSizes()) {
                if (s.width > 800) continue;
                if (best == null || Math.abs(s.width * s.height - 640 * 480) < Math.abs(best.width * best.height - 640 * 480))
                    best = s;
            }
            if (best != null) p.setPreviewSize(best.width, best.height);
            p.setPreviewFormat(ImageFormat.NV21);
            List<String> fm = p.getSupportedFocusModes();
            if (fm != null && fm.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO))
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            cam.setParameters(p);
            Camera.Size s = cam.getParameters().getPreviewSize();
            pw = s.width;
            ph = s.height;
            st = new SurfaceTexture(10);
            cam.setPreviewTexture(st);
            int size = pw * ph * ImageFormat.getBitsPerPixel(ImageFormat.NV21) / 8;
            for (int i = 0; i < 3; i++) cam.addCallbackBuffer(new byte[size]);
            cam.setPreviewCallbackWithBuffer(this);
            cam.startPreview();
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(camId, info);
            feed.rot = info.orientation;
            feed.mirror = info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT;
            feed.label = core.myName + " · CAM " + (camId + 1);
            prevY = null;
            applyParams();
        } catch (Exception e) {
            closeCam();
            core.toast("Nie udało się uruchomić kamery");
        }
    }

    private void closeCam() {
        if (cam != null) {
            try {
                cam.setPreviewCallbackWithBuffer(null);
                cam.stopPreview();
            } catch (Exception ignored) { }
            cam.release();
            cam = null;
        }
        if (st != null) {
            st.release();
            st = null;
        }
    }

    private void switchCam() {
        int n = Camera.getNumberOfCameras();
        if (n < 2) return;
        if (recorder != null) toggleRec();
        closeCam();
        camId = (camId + 1) % n;
        flash = false;
        openCam();
    }

    private void applyParams() {
        if (cam != null) {
            try {
                Camera.Parameters p = cam.getParameters();
                List<String> fl = p.getSupportedFlashModes();
                if (fl != null && fl.contains(Camera.Parameters.FLASH_MODE_TORCH))
                    p.setFlashMode(flash ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
                p.setExposureCompensation(nv ? p.getMaxExposureCompensation() : 0);
                cam.setParameters(p);
            } catch (Exception ignored) { }
        }
        feed.nv = nv;
        feed.flash = flash;
        feed.motionOn = motionOn;
        ignoreMotionUntil = System.currentTimeMillis() + 2500;
        refreshButtons();
    }

    private void refreshButtons() {
        flashBtn.setText(flash ? "🔦 Latarka: WŁ" : "🔦 Latarka");
        Ui.color(flashBtn, flash ? 0xFF6A5A14 : 0xFF262626);
        nvBtn.setText(nv ? "🌙 NV: WŁ" : "🌙 Noktowizja");
        Ui.color(nvBtn, nv ? 0xFF1E5A2A : 0xFF262626);
        motionBtn.setText(motionOn ? "👁 Ruch: WŁ" : "👁 Ruch: WYŁ");
        Ui.color(motionBtn, motionOn ? 0xFF1E3A5A : 0xFF262626);
        recBtn.setText(recorder != null ? "■ Stop" : "⏺ Nagrywaj");
        Ui.color(recBtn, recorder != null ? 0xFF7A1A14 : 0xFF262626);
    }

    @Override
    public void onCmd(String c, boolean v, String fromName) {
        String what;
        switch (c) {
            case "flash": flash = v; what = v ? "włączył latarkę" : "wyłączył latarkę"; break;
            case "nv": nv = v; what = v ? "włączył noktowizję" : "wyłączył noktowizję"; break;
            case "motion": motionOn = v; what = v ? "włączył wykrywanie ruchu" : "wyłączył wykrywanie ruchu"; break;
            default: return;
        }
        applyParams();
        core.toast(fromName + " " + what);
    }

    // ================= klatki =================

    @Override
    public void onPreviewFrame(byte[] data, Camera c) {
        Handler h = wh;
        if (h != null && busy.compareAndSet(false, true)) {
            final byte[] copy = data.clone();
            final int w = pw, hh = ph;
            h.post(() -> process(copy, w, hh));
        }
        c.addCallbackBuffer(data);
    }

    private void process(byte[] d, int w, int h) {
        try {
            long now = System.currentTimeMillis();
            if (motionOn) detectMotion(d, w, h, now);
            YuvImage yi = new YuvImage(d, ImageFormat.NV21, w, h, null);
            ByteArrayOutputStream bo = new ByteArrayOutputStream(65536);
            yi.compressToJpeg(new Rect(0, 0, w, h), 60, bo);
            byte[] jpg = bo.toByteArray();
            if (core.net.isConnected() && now - core.lastWatched < 6000 && now - lastSend > 110) {
                lastSend = now;
                core.net.send(frameMsg(jpg, now));
            }
            Bitmap bm = BitmapFactory.decodeByteArray(jpg, 0, jpg.length);
            if (bm != null) {
                feed.setFrame(bm, now);
                VideoRecorder r = recorder;
                if (r != null) r.addFrame(feed.compose(feed.outW(), feed.outH()));
            }
        } catch (Exception ignored) {
        } finally {
            busy.set(false);
        }
    }

    private Net.Msg frameMsg(byte[] jpg, long now) {
        JSONObject o = Net.Msg.obj("frame");
        try {
            o.put("from", core.myId);
            o.put("name", core.myName);
            o.put("ts", now);
            o.put("rot", feed.rot);
            o.put("mirror", feed.mirror);
            o.put("nv", nv);
            o.put("flash", flash);
            o.put("motion", motionOn);
            o.put("alert", now < feed.motionUntil);
        } catch (JSONException ignored) { }
        return new Net.Msg(o, jpg);
    }

    private void detectMotion(byte[] d, int w, int h, long now) {
        int step = 16, cols = w / step, rows = h / step;
        byte[] cur = new byte[cols * rows];
        for (int y = 0; y < rows; y++)
            for (int x = 0; x < cols; x++) cur[y * cols + x] = d[(y * step) * w + x * step];
        byte[] prev = prevY;
        prevY = cur;
        if (prev == null || prev.length != cur.length) return;
        long diff = 0;
        for (int i = 0; i < cur.length; i++) diff += Math.abs((cur[i] & 255) - (prev[i] & 255));
        float mean = diff / (float) cur.length;
        if (mean > 14f && now > ignoreMotionUntil && now - lastMotion > 5000) {
            lastMotion = now;
            feed.motionUntil = now + 2000;
            core.main.post(() -> core.alert("Ghost Cam (" + core.myName + "): wykryto ruch"));
        }
    }

    private void toggleRec() {
        if (recorder != null) {
            final VideoRecorder r = recorder;
            recorder = null;
            feed.rec = false;
            r.stop(ok -> Gallery.finishVideo(core, act, r.file, ok, "Nagranie z Ghost Cam (" + core.myName + ")"));
        } else {
            if (feed.frame == null) {
                core.toast("Brak obrazu z kamery");
                return;
            }
            File f = new File(act.getCacheDir(), "GhostCam_" + Ui.fileStamp() + ".mp4");
            recorder = new VideoRecorder(f, feed.outW(), feed.outH());
            feed.rec = true;
        }
        refreshButtons();
    }
}
