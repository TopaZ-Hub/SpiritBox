package pl.duchy.spiritbox;

import android.Manifest;
import android.app.AlertDialog;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.Locale;

final class SpiritBoxScreen extends Screen implements RadioView.Listener {

    private static final int[] RATES = {50, 100, 150, 200, 250, 300, 400, 500};
    private static final float[] LEVELS = {1.5f, 4f, 10f, 25f, 50f};

    private final RadioView radio;
    private final Button autoBtn;
    private final TextView info;
    private final SweepEngine engine;
    private ToneGenerator tone;

    private int rateIdx = 2;
    private int fmTenths = 875, amKhz = 530;
    private boolean fwd = true, beep = true, auto = true;
    private long lastBeep = 0, lastVoice = 0;

    SpiritBoxScreen(MainActivity a) {
        super(a);
        engine = core.engine;
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 60); } catch (RuntimeException ignored) { }

        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(6), dp(6), dp(6), dp(20));
        sv.addView(root);
        addView(sv);

        radio = new RadioView(a);
        radio.setListener(this);
        radio.hasEmf = core.sensors.mag != null;
        radio.sweepMs = RATES[rateIdx];
        radio.freq = fmText();
        root.addView(radio);

        LinearLayout row = Ui.row(a);
        Button save = Ui.btn(a, "📖 ZAPISZ ODPOWIEDŹ", 0xFF5A1E12, Ui.TEXT);
        save.setOnClickListener(v -> askAndSave());
        autoBtn = Ui.btn(a, "");
        autoBtn.setOnClickListener(v -> { auto = !auto; refreshAuto(); });
        Ui.addWeighted(row, save);
        Ui.addWeighted(row, autoBtn);
        root.addView(row);
        refreshAuto();

        info = Ui.text(a, "", 12, Ui.DIM, false);
        info.setPadding(dp(8), dp(8), dp(8), dp(8));
        info.setText("POWER – start/stop · SWEEP RATE – szybkość · AM/FM – rodzaj szumu · " +
                "EMF CAL – kalibracja (przytrzymaj: pikanie) · REC – nagrywanie całej sesji.\n" +
                "Auto-zapis działa z włączonym MIC: gdy w pokoju pojawi się wyraźny dźwięk, ostatnie sekundy " +
                "skanu trafiają do dziennika jako „głos”. Używaj słuchawek.");
        root.addView(info);

        engine.setListener(type -> core.main.post(this::advanceFreq));
        engine.setVoiceListener(strength -> core.main.post(() -> onVoice(strength)));
    }

    private void refreshAuto() {
        autoBtn.setText(auto ? "AUTO-ZAPIS: WŁ" : "AUTO-ZAPIS: WYŁ");
        Ui.color(autoBtn, auto ? 0xFF1E4A30 : 0xFF262626);
    }

    @Override
    String title() {
        return "Spirit Box";
    }

    @Override
    void onShow() {
        radio.running = engine.isRunning();
        radio.mic = engine.isMic();
    }

    @Override
    void tick() {
        float d = core.sensors.emfDelta;
        int level = Sensors.level(d, LEVELS);
        radio.emfDelta = d;
        radio.emfLevel = level;
        radio.battery = core.sensors.battery;
        long now = System.currentTimeMillis();
        if (level >= 3 && beep && tone != null && now - lastBeep > 250) {
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 60 + level * 20);
            lastBeep = now;
        }
        radio.invalidate();
    }

    // ================= przyciski radia =================

    @Override
    public void onButton(int id, boolean longPress) {
        switch (id) {
            case RadioView.B_POWER:
                if (engine.isRunning()) {
                    if (engine.isRecording()) toggleRec();
                    engine.stop();
                } else {
                    engine.setUseMic(radio.mic && act.has(Manifest.permission.RECORD_AUDIO));
                    engine.start();
                }
                radio.running = engine.isRunning();
                break;
            case RadioView.B_RATE:
                rateIdx = (rateIdx + 1) % RATES.length;
                engine.setSweepMs(RATES[rateIdx]);
                radio.sweepMs = RATES[rateIdx];
                break;
            case RadioView.B_FWD:
                fwd = true;
                radio.fwd = true;
                break;
            case RadioView.B_REV:
                fwd = false;
                radio.fwd = false;
                break;
            case RadioView.B_VOLUP:
            case RadioView.B_VOLDN: {
                AudioManager am = (AudioManager) act.getSystemService(android.content.Context.AUDIO_SERVICE);
                if (am != null) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                            id == RadioView.B_VOLUP ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, 0);
                    radio.volText = String.valueOf(am.getStreamVolume(AudioManager.STREAM_MUSIC));
                    radio.volUntil = System.currentTimeMillis() + 1500;
                }
                break;
            }
            case RadioView.B_BAND:
                engine.setAmBand(!engine.isAm());
                radio.amBand = engine.isAm();
                radio.freq = radio.amBand ? amText() : fmText();
                break;
            case RadioView.B_LIGHT:
                radio.backlight = (radio.backlight + 1) % 3;
                break;
            case RadioView.B_MIC:
                if (radio.mic) {
                    radio.mic = false;
                    engine.setUseMic(false);
                } else {
                    act.withPermission(Manifest.permission.RECORD_AUDIO, () -> {
                        radio.mic = true;
                        engine.setUseMic(true);
                        core.toast("Użyj słuchawek – inaczej głośnik wraca do mikrofonu");
                        radio.invalidate();
                    });
                }
                break;
            case RadioView.B_REC:
                toggleRec();
                break;
            case RadioView.B_ECHO:
                engine.setEcho(!engine.isEcho());
                radio.echo = engine.isEcho();
                break;
            case RadioView.B_CAL:
                if (longPress) {
                    beep = !beep;
                    radio.beep = beep;
                    core.toast(beep ? "Pikanie EMF włączone" : "Pikanie EMF wyłączone");
                } else {
                    core.sensors.calibrate();
                    core.toast("Skalibrowano tło EMF");
                }
                break;
        }
        radio.invalidate();
    }

    private void advanceFreq() {
        if (engine.isAm()) {
            amKhz += fwd ? 10 : -10;
            if (amKhz > 1710) amKhz = 530;
            if (amKhz < 530) amKhz = 1710;
            radio.freq = amText();
        } else {
            fmTenths += fwd ? 1 : -1;
            if (fmTenths > 1080) fmTenths = 875;
            if (fmTenths < 875) fmTenths = 1080;
            radio.freq = fmText();
        }
        radio.invalidate();
    }

    private String fmText() {
        String s = (fmTenths / 10) + "." + (fmTenths % 10);
        return s.length() < 5 ? " " + s : s;
    }

    private String amText() {
        String s = String.valueOf(amKhz);
        return s.length() < 4 ? " " + s : s;
    }

    private String freqLabel() {
        return engine.isAm() ? amKhz + " kHz AM" : String.format(Locale.US, "%.1f MHz FM", fmTenths / 10f);
    }

    // ================= dziennik =================

    private void onVoice(float strength) {
        if (!auto || !engine.isRunning()) return;
        long now = System.currentTimeMillis();
        if (now - lastVoice < 8000) return;
        lastVoice = now;
        final String f = freqLabel();
        // poczekaj chwilę, żeby nagranie objęło też to, co po dźwięku
        core.main.postDelayed(() -> {
            short[] s = engine.lastOutput(SweepEngine.SR * 4);
            core.book.addBytes("voice", "Głos ze Spirit Boxa (auto) · " + f,
                    WavWriter.encode(s, SweepEngine.SR), "wav");
            core.toast("📖 Zapisano głos w dzienniku");
        }, 1500);
    }

    private void askAndSave() {
        if (!engine.isRunning()) {
            core.toast("Najpierw włącz POWER");
            return;
        }
        final short[] s = engine.lastOutput(SweepEngine.SR * 6);
        final String f = freqLabel();
        EditText et = new EditText(act);
        et.setHint("Co usłyszałeś? (np. „tutaj”)");
        new AlertDialog.Builder(act)
                .setTitle("Zapisz odpowiedź (ostatnie 6 s)")
                .setView(et)
                .setPositiveButton("Zapisz", (d, w) -> {
                    String heard = et.getText().toString().trim();
                    String text = heard.isEmpty() ? "Odpowiedź ze Spirit Boxa · " + f
                            : "„" + heard + "” – Spirit Box · " + f;
                    core.book.addBytes("voice", text, WavWriter.encode(s, SweepEngine.SR), "wav");
                    if (!heard.isEmpty()) core.book.setEvidence("voice", true, true);
                    core.toast("📖 Zapisano w dzienniku");
                })
                .setNegativeButton("Anuluj", null)
                .show();
    }

    private void toggleRec() {
        if (engine.isRecording()) {
            File f = engine.stopRecording();
            radio.rec = false;
            if (f != null) {
                core.book.addFile("voice", "Nagranie sesji Spirit Boxa", f, "wav");
                core.toast("Nagranie sesji zapisane w dzienniku");
            }
            return;
        }
        if (!engine.isRunning()) {
            core.toast("Najpierw włącz POWER");
            return;
        }
        try {
            File f = new File(act.getCacheDir(), "session_" + Ui.fileStamp() + ".wav");
            engine.startRecording(f);
            radio.rec = true;
        } catch (Exception e) {
            core.toast("Nie udało się nagrywać");
        }
    }
}
