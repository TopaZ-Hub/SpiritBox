package pl.duchy.spiritbox;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.ThumbnailUtils;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.VideoView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Wspólny dziennik drużyny w stylu starej księgi. */
final class BookScreen extends Screen {

    private static final int PAPER = 0xFFE9DDBE, INK = 0xFF3A2A18, INK_DIM = 0xFF7A6448, LEATHER = 0xFF4A1E14;

    private final LinearLayout content;
    private final Button[] tabs = new Button[3];
    private int tab = 0;
    private MediaPlayer player;
    private final Map<String, Bitmap> thumbs = new HashMap<>();

    BookScreen(MainActivity a) {
        super(a);
        setBackgroundColor(LEATHER);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        addView(root);

        LinearLayout tabRow = Ui.row(a);
        String[] names = {"Wpisy", "Dowody", "Zdjęcia i nagrania"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            tabs[i] = Ui.btn(a, names[i]);
            tabs[i].setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            tabs[i].setOnClickListener(v -> { tab = k; rebuild(); });
            Ui.addWeighted(tabRow, tabs[i]);
        }
        root.addView(tabRow);

        ScrollView sv = new ScrollView(a);
        content = Ui.col(a);
        content.setPadding(dp(16), dp(16), dp(16), dp(24));
        GradientDrawable paper = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFFEFE4C8, PAPER, 0xFFD9C9A0});
        paper.setCornerRadius(dp(6));
        sv.setBackground(paper);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    @Override
    String title() {
        return "Dziennik";
    }

    @Override
    void onShow() {
        core.book.onChange = this::rebuild;
        rebuild();
    }

    @Override
    void onHide() {
        if (core.book.onChange != null) core.book.onChange = null;
        stopPlayer();
    }

    private TextView ink(String s, float sp, int color, int style) {
        TextView t = Ui.text(act, s, sp, color, false);
        t.setTypeface(Typeface.create(Typeface.SERIF, style));
        return t;
    }

    private void rebuild() {
        for (int i = 0; i < 3; i++) Ui.color(tabs[i], i == tab ? 0xFF8A5A2A : 0xFF2A1A10);
        content.removeAllViews();
        if (tab == 0) buildEntries();
        else if (tab == 1) buildEvidence();
        else buildMedia();
    }

    // ================= wpisy =================

    private void buildEntries() {
        TextView h = ink("Dziennik śledztwa", 24, INK, Typeface.BOLD_ITALIC);
        h.setGravity(Gravity.CENTER);
        content.addView(h);
        TextView sub = ink(core.net.isConnected() ? "wspólny dla całej drużyny" : "tylko na tym telefonie (brak drużyny)",
                13, INK_DIM, Typeface.ITALIC);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(12));
        content.addView(sub);

        LinearLayout add = Ui.row(act);
        EditText et = new EditText(act);
        et.setHint("Dopisz notatkę…");
        et.setTextColor(INK);
        et.setHintTextColor(INK_DIM);
        et.setTypeface(Typeface.SERIF);
        Button save = Ui.btn(act, "✒", 0xFF8A5A2A, Color.WHITE);
        save.setOnClickListener(v -> {
            String t = et.getText().toString().trim();
            if (t.isEmpty()) return;
            core.book.addText("note", t);
        });
        add.addView(et, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        add.addView(save);
        content.addView(add);

        List<Book.Entry> list = new ArrayList<>(core.book.entries);
        if (list.isEmpty()) {
            TextView e = ink("Strony są jeszcze puste…", 16, INK_DIM, Typeface.ITALIC);
            e.setPadding(0, dp(24), 0, 0);
            content.addView(e);
        }
        for (int i = list.size() - 1; i >= 0; i--) content.addView(entryView(list.get(i)));

        Button clear = Ui.btn(act, "🗑 WYCZYŚĆ DZIENNIK", 0xFF6A1A14, Color.WHITE);
        clear.setOnClickListener(v -> new AlertDialog.Builder(act)
                .setTitle("Wyczyścić dziennik?")
                .setMessage(core.net.isConnected() ? "Wpisy, dowody, zdjęcia i nagrania zostaną usunięte na WSZYSTKICH telefonach w drużynie."
                        : "Wszystkie wpisy, zdjęcia i nagrania zostaną usunięte.")
                .setPositiveButton("Wyczyść", (d, w) -> core.book.clear(true))
                .setNegativeButton("Anuluj", null)
                .show());
        content.addView(clear, Ui.matchWrap(act, 12));
    }

    private View entryView(Book.Entry e) {
        LinearLayout l = Ui.col(act);
        l.setPadding(0, dp(10), 0, dp(10));
        String icon;
        switch (e.kind) {
            case "voice": icon = "🔊 "; break;
            case "photo": icon = "📷 "; break;
            case "video": icon = "🎬 "; break;
            case "event": icon = "⚠ "; break;
            default: icon = "✒ ";
        }
        l.addView(ink(Ui.stamp(e.ts) + " · " + e.author, 12, INK_DIM, Typeface.ITALIC));
        l.addView(ink(icon + e.text, 16, e.kind.equals("event") ? 0xFF7A1A10 : INK, Typeface.NORMAL));
        File f = core.book.fileOf(e);
        if (f != null && f.exists()) {
            if (e.kind.equals("voice")) {
                Button b = Ui.btn(act, "▶ Odtwórz", 0xFF8A5A2A, Color.WHITE);
                b.setOnClickListener(v -> play(f));
                l.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            } else if (e.kind.equals("photo") || e.kind.equals("video")) {
                ImageView iv = thumbView(e, f, dp(140));
                l.addView(iv);
            }
        }
        View line = new View(act);
        line.setBackgroundColor(0x33000000);
        l.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        return l;
    }

    // ================= dowody =================

    private void buildEvidence() {
        TextView h = ink("Dowody", 24, INK, Typeface.BOLD_ITALIC);
        h.setGravity(Gravity.CENTER);
        h.setPadding(0, 0, 0, dp(12));
        content.addView(h);
        for (String[] ev : Book.EVIDENCE) {
            CheckBox cb = new CheckBox(act);
            cb.setText(ev[1]);
            cb.setTextSize(18);
            cb.setTextColor(INK);
            cb.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));
            Boolean v = core.book.evidence.get(ev[0]);
            cb.setChecked(v != null && v);
            final String key = ev[0];
            cb.setOnCheckedChangeListener((b, on) -> core.book.setEvidence(key, on, true));
            content.addView(cb);
        }
        TextView n = ink("Niektóre dowody zaznaczają się same (EMF 5, krucyfiks, pozytywka, ruch, głos z opisem). " +
                "Zaznaczenia widzi cała drużyna.", 13, INK_DIM, Typeface.ITALIC);
        n.setPadding(0, dp(16), 0, 0);
        content.addView(n);
    }

    // ================= media =================

    private void buildMedia() {
        TextView h = ink("Zdjęcia i nagrania", 24, INK, Typeface.BOLD_ITALIC);
        h.setGravity(Gravity.CENTER);
        h.setPadding(0, 0, 0, dp(12));
        content.addView(h);
        List<Book.Entry> media = new ArrayList<>();
        for (Book.Entry e : core.book.entries) {
            File f = core.book.fileOf(e);
            if (f != null && f.exists() && (e.kind.equals("photo") || e.kind.equals("video") || e.kind.equals("voice")))
                media.add(e);
        }
        if (media.isEmpty()) content.addView(ink("Brak zdjęć i nagrań.", 16, INK_DIM, Typeface.ITALIC));
        LinearLayout row = null;
        int col = 0;
        for (int i = media.size() - 1; i >= 0; i--) {
            Book.Entry e = media.get(i);
            File f = core.book.fileOf(e);
            if (e.kind.equals("voice")) {
                Button b = Ui.btn(act, "🔊 " + Ui.time(e.ts) + " · " + e.text, 0xFF8A5A2A, Color.WHITE);
                b.setOnClickListener(v -> play(f));
                content.addView(b, Ui.matchWrap(act, 4));
                continue;
            }
            if (col == 0) {
                row = Ui.row(act);
                content.addView(row);
            }
            LinearLayout cell = Ui.col(act);
            cell.addView(thumbView(e, f, dp(150)));
            cell.addView(ink(Ui.time(e.ts) + " · " + e.author, 11, INK_DIM, Typeface.ITALIC));
            Ui.addWeighted(row, cell);
            col = (col + 1) % 2;
        }
        if (col == 1 && row != null) Ui.addWeighted(row, new View(act));
    }

    private ImageView thumbView(Book.Entry e, File f, int h) {
        ImageView iv = new ImageView(act);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackgroundColor(0xFF000000);
        Bitmap b = thumbs.get(e.id);
        if (b == null) {
            try {
                if (e.kind.equals("photo")) {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inSampleSize = 4;
                    b = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                } else {
                    //noinspection deprecation
                    b = ThumbnailUtils.createVideoThumbnail(f.getAbsolutePath(), MediaStore.Images.Thumbnails.MINI_KIND);
                }
            } catch (Exception ignored) { }
            if (b != null) thumbs.put(e.id, b);
        }
        if (b != null) iv.setImageBitmap(b);
        iv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h));
        iv.setOnClickListener(v -> open(e, f));
        if (e.kind.equals("video")) iv.setForeground(act.getDrawable(android.R.drawable.ic_media_play));
        return iv;
    }

    private void open(Book.Entry e, File f) {
        Dialog d = new Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        FrameLayout fl = new FrameLayout(act);
        fl.setBackgroundColor(Color.BLACK);
        if (e.kind.equals("photo")) {
            ImageView iv = new ImageView(act);
            iv.setImageBitmap(BitmapFactory.decodeFile(f.getAbsolutePath()));
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setOnClickListener(v -> d.dismiss());
            fl.addView(iv);
        } else {
            VideoView vv = new VideoView(act);
            vv.setVideoPath(f.getAbsolutePath());
            MediaController mc = new MediaController(act);
            mc.setAnchorView(vv);
            vv.setMediaController(mc);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
            fl.addView(vv, lp);
            vv.start();
        }
        TextView cap = Ui.text(act, e.text + "\n" + Ui.stamp(e.ts) + " · " + e.author + "   (dotknij, by zamknąć)", 13, Color.WHITE, false);
        cap.setPadding(dp(12), dp(12), dp(12), dp(12));
        cap.setOnClickListener(v -> d.dismiss());
        fl.addView(cap, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));
        d.setContentView(fl);
        d.show();
    }

    private void play(File f) {
        stopPlayer();
        try {
            player = new MediaPlayer();
            player.setDataSource(f.getAbsolutePath());
            player.prepare();
            player.start();
        } catch (Exception ex) {
            core.toast("Nie można odtworzyć");
            stopPlayer();
        }
    }

    private void stopPlayer() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) { }
            player.release();
            player = null;
        }
    }
}
