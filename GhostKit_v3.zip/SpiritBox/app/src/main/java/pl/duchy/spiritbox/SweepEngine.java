package pl.duchy.spiritbox;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;

import java.io.File;
import java.io.IOException;
import java.util.Random;

/**
 * Silnik "spirit boxa".
 *
 * Prawdziwy spirit box skanuje radio i co kilkadziesiąt ms przeskakuje na kolejną częstotliwość.
 * Telefony nie dają aplikacjom dostępu do tunera, więc każdy krok skanu to losowo:
 *  - szum eteru (FM: jasne "szszsz", AM: przytłumiony szum z trzaskami),
 *  - "niedostrojona stacja" – przytłumiony szum o rytmie przypominającym sylaby,
 *  - strzępek dźwięku z otoczenia z mikrofonu (opcjonalnie, czasem odwrócony),
 * a pomiędzy krokami krótkie wyciszenie z cichym kliknięciem, jak przy przeskoku stacji.
 * Żadnych tonów, gwizdów ani bazy słów.
 */
final class SweepEngine {

    static final int SR = 44100;

    static final int STEP_STATIC = 0;
    static final int STEP_MUFFLED = 1;
    static final int STEP_MIC = 2;

    interface Listener {
        void onStep(int type);
    }

    /** Wywoływane, gdy w strzępku z mikrofonu pojawił się wyraźny dźwięk (głośniejszy niż tło). */
    interface VoiceListener {
        void onVoice(float strength);
    }

    private volatile boolean running = false;
    private volatile int sweepMs = 150;
    private volatile boolean useMic = false;
    private volatile boolean useEcho = false;
    private volatile boolean amBand = false;
    private volatile Listener listener;
    private volatile VoiceListener voiceListener;
    private float micFloor = -1f;

    // ostatnie 8 s tego, co wyszło z głośnika (do zapisu odpowiedzi w dzienniku)
    private final short[] outRing = new short[SR * 8];
    private int outPos = 0;
    private final Object outLock = new Object();

    private Thread playThread;
    private Thread micThread;

    private final short[] ring = new short[SR * 8];
    private int ringPos = 0;
    private int ringFilled = 0;
    private final Object ringLock = new Object();

    private final Object wavLock = new Object();
    private WavWriter wav;

    private final Random rnd = new Random();

    private final Biquad lp1 = new Biquad(), lp2 = new Biquad();
    private final Biquad bpM = new Biquad(), lpM = new Biquad();
    private final Biquad voice = new Biquad(), voiceLp = new Biquad();
    private float crack = 0f;

    void setListener(Listener l) { listener = l; }

    void setVoiceListener(VoiceListener l) { voiceListener = l; }

    boolean isAm() { return amBand; }

    boolean isEcho() { return useEcho; }

    boolean isMic() { return useMic; }

    int getSweepMs() { return sweepMs; }

    /** Ostatnie {@code samples} próbek dźwięku wyjściowego. */
    short[] lastOutput(int samples) {
        synchronized (outLock) {
            int len = outRing.length;
            samples = Math.min(samples, len);
            short[] r = new short[samples];
            int start = ((outPos - samples) % len + len) % len;
            for (int i = 0; i < samples; i++) r[i] = outRing[(start + i) % len];
            return r;
        }
    }

    void setSweepMs(int ms) { sweepMs = Math.max(30, Math.min(1000, ms)); }

    void setEcho(boolean on) { useEcho = on; }

    void setAmBand(boolean am) { amBand = am; }

    boolean isRunning() { return running; }

    /** Dorzuca szum z czujnika do generatora losowego. */
    void addEntropy(float v) {
        long bits = Float.floatToIntBits(v) & 0xFFFFL;
        rnd.setSeed(rnd.nextLong() ^ (bits << 17) ^ System.nanoTime());
    }

    synchronized void setUseMic(boolean on) {
        useMic = on;
        if (on && running && (micThread == null || !micThread.isAlive())) startMic();
    }

    synchronized void start() {
        if (running) return;
        running = true;
        playThread = new Thread(this::playLoop, "spiritbox-play");
        playThread.setPriority(Thread.MAX_PRIORITY);
        playThread.start();
        if (useMic) startMic();
    }

    synchronized void stop() {
        running = false;
        try {
            if (playThread != null) playThread.join(800);
            if (micThread != null) micThread.join(800);
        } catch (InterruptedException ignored) { }
        playThread = null;
        micThread = null;
    }

    // ---------- Nagrywanie ----------

    void startRecording(File f) throws IOException {
        synchronized (wavLock) {
            if (wav != null) wav.close();
            wav = new WavWriter(f, SR);
        }
    }

    File stopRecording() {
        synchronized (wavLock) {
            if (wav == null) return null;
            File f = wav.getFile();
            try { wav.close(); } catch (IOException ignored) { }
            wav = null;
            return f;
        }
    }

    boolean isRecording() {
        synchronized (wavLock) { return wav != null; }
    }

    // ---------- Mikrofon ----------

    private void startMic() {
        micThread = new Thread(this::micLoop, "spiritbox-mic");
        micThread.start();
    }

    private void micLoop() {
        AudioRecord rec = null;
        try {
            int minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT);
            rec = new AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, SR));
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) return;
            rec.startRecording();
            short[] tmp = new short[1024];
            while (running && useMic) {
                int r = rec.read(tmp, 0, tmp.length);
                if (r <= 0) continue;
                synchronized (ringLock) {
                    for (int i = 0; i < r; i++) {
                        ring[ringPos] = tmp[i];
                        ringPos = (ringPos + 1) % ring.length;
                        if (ringFilled < ring.length) ringFilled++;
                    }
                }
            }
        } catch (SecurityException | IllegalStateException | IllegalArgumentException ignored) {
        } finally {
            if (rec != null) {
                try { rec.stop(); } catch (Exception ignored) { }
                rec.release();
            }
        }
    }

    private boolean randomMicFragment(float[] out, int n) {
        synchronized (ringLock) {
            int minBack = n + SR / 2;
            if (ringFilled < minBack + SR / 4) return false;
            int back = minBack + rnd.nextInt(ringFilled - minBack);
            int start = ((ringPos - back) % ring.length + ring.length) % ring.length;
            for (int i = 0; i < n; i++) out[i] = ring[(start + i) % ring.length] / 32768f;
        }
        return true;
    }

    // ---------- Generator ----------

    private void playLoop() {
        int minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack track;
        try {
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(SR)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build())
                    .setBufferSizeInBytes(Math.max(minBuf * 2, 8192))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
        } catch (Exception e) {
            running = false;
            return;
        }
        track.play();

        float[] echo = new float[(int) (SR * 0.21f)];
        int echoPos = 0;
        float[] buf = new float[SR * 2];
        short[] pcm = new short[SR * 2];

        while (running) {
            int n = SR * sweepMs / 1000;
            int jitter = n / 6;
            if (jitter > 0) n += rnd.nextInt(jitter * 2) - jitter;
            int gap = SR * (6 + rnd.nextInt(14)) / 1000;
            if (n + gap > buf.length) n = buf.length - gap;

            int type = chooseType();
            if (type == STEP_MIC && !randomMicFragment(buf, n)) type = STEP_STATIC;
            if (type == STEP_MIC) checkVoice(buf, n);

            switch (type) {
                case STEP_STATIC: genStatic(buf, n); break;
                case STEP_MUFFLED: genMuffled(buf, n); break;
                default: shapeVoice(buf, n); break;
            }

            // wygładzenie brzegów (3 ms)
            int fade = Math.min(SR * 3 / 1000, n / 4);
            for (int i = 0; i < fade; i++) {
                float g = i / (float) fade;
                buf[i] *= g;
                buf[n - 1 - i] *= g;
            }

            // wyciszenie przy przeskoku + delikatny klik
            for (int i = 0; i < gap; i++) buf[n + i] = (rnd.nextFloat() * 2 - 1) * 0.004f;
            if (gap > 6) {
                float k = 0.10f;
                for (int i = 0; i < 6; i++) { buf[n + 2 + i] += (i % 2 == 0 ? k : -k); k *= 0.6f; }
            }

            int total = n + gap;
            for (int i = 0; i < total; i++) {
                float x = buf[i];
                if (useEcho) {
                    float d = echo[echoPos];
                    echo[echoPos] = x + d * 0.35f;
                    echoPos = (echoPos + 1) % echo.length;
                    x = x + d * 0.38f;
                }
                x = (float) Math.tanh(x * 1.2f);
                pcm[i] = (short) (x * 30000f);
            }

            synchronized (outLock) {
                for (int i = 0; i < total; i++) {
                    outRing[outPos] = pcm[i];
                    outPos = (outPos + 1) % outRing.length;
                }
            }

            Listener l = listener;
            if (l != null) l.onStep(type);

            track.write(pcm, 0, total);

            synchronized (wavLock) {
                if (wav != null) {
                    try { wav.write(pcm, total); } catch (IOException ignored) { }
                }
            }
        }

        try { track.stop(); } catch (Exception ignored) { }
        track.release();
    }

    private void checkVoice(float[] b, int n) {
        double sum = 0;
        for (int i = 0; i < n; i++) sum += b[i] * b[i];
        float rms = (float) Math.sqrt(sum / Math.max(1, n));
        if (micFloor < 0) { micFloor = rms; return; }
        boolean voiced = rms > micFloor * 3.5f && rms > 0.004f;
        micFloor += (rms - micFloor) * (rms < micFloor ? 0.2f : 0.02f);
        VoiceListener v = voiceListener;
        if (voiced && v != null) v.onVoice(rms / Math.max(micFloor, 1e-5f));
    }

    private int chooseType() {
        float r = rnd.nextFloat();
        if (useMic) {
            if (r < 0.40f) return STEP_MIC;
            if (r < 0.80f) return STEP_STATIC;
            return STEP_MUFFLED;
        }
        return r < 0.68f ? STEP_STATIC : STEP_MUFFLED;
    }

    private float white() { return rnd.nextFloat() * 2f - 1f; }

    /** Trzaski AM: losowe impulsy z szybkim zanikiem. */
    private float crackle() {
        if (rnd.nextFloat() < 0.00025f) crack = (0.25f + rnd.nextFloat() * 0.55f) * (rnd.nextBoolean() ? 1 : -1);
        float c = crack;
        crack *= 0.82f;
        return c;
    }

    /** Szum eteru między stacjami. */
    private void genStatic(float[] b, int n) {
        boolean am = amBand;
        float cut = am ? 2600f + rnd.nextFloat() * 1800f : 5500f + rnd.nextFloat() * 4500f;
        lp1.lowpass(cut, 0.707f, SR);
        lp2.lowpass(cut, 0.707f, SR);
        float amp = am ? 0.55f + rnd.nextFloat() * 0.35f : 0.40f + rnd.nextFloat() * 0.35f;
        // czasem lekkie "falowanie" sygnału (jak przy słabym odbiorze)
        float flut = rnd.nextFloat() < 0.3f ? 8f + rnd.nextFloat() * 25f : 0f;
        for (int i = 0; i < n; i++) {
            float y = lp2.process(lp1.process(white())) * amp * 1.9f;
            if (flut > 0) y *= 0.75f + 0.25f * (float) Math.sin(2 * Math.PI * flut * i / SR);
            if (am) y += crackle();
            b[i] = y;
        }
    }

    /** Niedostrojona stacja: przytłumiony szum z rytmem jak sylaby. */
    private void genMuffled(float[] b, int n) {
        boolean am = amBand;
        bpM.bandpass(500f + rnd.nextFloat() * 900f, 0.8f, SR);
        lpM.lowpass(am ? 1500f : 2600f, 0.707f, SR);
        float s1 = 3f + rnd.nextFloat() * 4f, s2 = 5f + rnd.nextFloat() * 6f;
        float ph1 = rnd.nextFloat() * 6.28f, ph2 = rnd.nextFloat() * 6.28f;
        float amp = 1.6f + rnd.nextFloat() * 1.2f;
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            float e1 = (float) Math.max(0, Math.sin(2 * Math.PI * s1 * t + ph1));
            float e2 = (float) Math.max(0, Math.sin(2 * Math.PI * s2 * t + ph2));
            float env = 0.25f + 0.75f * Math.max(e1, e2 * 0.7f);
            float y = lpM.process(bpM.process(white())) * amp * env;
            y += white() * 0.05f;
            if (am) y += crackle();
            b[i] = y;
        }
    }

    /** Fragment z mikrofonu: pasmo "radiowe", automatyczne wzmocnienie, szum. */
    private void shapeVoice(float[] b, int n) {
        if (rnd.nextFloat() < 0.3f) {
            for (int i = 0, j = n - 1; i < j; i++, j--) { float t = b[i]; b[i] = b[j]; b[j] = t; }
        }
        voice.reset();
        voiceLp.reset();
        voice.bandpass(1100f, 0.55f, SR);
        voiceLp.lowpass(amBand ? 2200f : 3800f, 0.707f, SR);
        double sum = 0;
        for (int i = 0; i < n; i++) {
            b[i] = voiceLp.process(voice.process(b[i]));
            sum += b[i] * b[i];
        }
        float rms = (float) Math.sqrt(sum / Math.max(1, n));
        float gain = rms > 1e-5f ? Math.min(0.30f / rms, 45f) : 1f;
        for (int i = 0; i < n; i++) {
            float y = b[i] * gain + white() * 0.08f;
            if (amBand) y += crackle();
            b[i] = y;
        }
    }
}
