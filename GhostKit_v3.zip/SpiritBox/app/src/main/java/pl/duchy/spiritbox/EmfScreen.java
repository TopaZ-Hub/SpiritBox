package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/** Detektor EMF z pięcioma diodami. */
final class EmfScreen extends Screen {

    static final float[] LEVELS = {1f, 3f, 8f, 20f, 40f}; // ΔµT
    static final int[] COLORS = {0xFF2EE66B, 0xFFA8E62E, 0xFFFFE12B, 0xFFFF9A1F, 0xFFFF2E2E};

    private final Meter meter;
    private final TextView info;
    private ToneGenerator tone;
    private long lastChirp = 0, lastEvent = 0;

    EmfScreen(MainActivity a) {
        super(a);
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 80); } catch (RuntimeException ignored) { }
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(8), dp(8), dp(8), dp(20));
        sv.addView(root);
        addView(sv);
        meter = new Meter(a);
        root.addView(meter);
        info = Ui.text(a, "", 12, Ui.DIM, false);
        info.setPadding(dp(8), dp(10), dp(8), 0);
        root.addView(info);
    }

    @Override
    String title() {
        return "EMF-5";
    }

    @Override
    void tick() {
        Sensors s = core.sensors;
        meter.value = s.emfDelta;
        meter.level = meter.on ? Sensors.level(s.emfDelta, LEVELS) : 0;
        meter.invalidate();
        long now = System.currentTimeMillis();
        if (meter.on && meter.level > 0 && tone != null) {
            long interval = new long[]{0, 700, 450, 280, 160, 90}[meter.level];
            if (now - lastChirp > interval) {
                tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 40);
                lastChirp = now;
            }
        }
        if (meter.on && meter.level >= 5 && now - lastEvent > 10000) {
            lastEvent = now;
            core.alert(String.format(Locale.US, "EMF poziom 5 (Δ%.1f µT)", s.emfDelta));
            core.book.setEvidence("emf", true, true);
        }
        String t = s.mag == null ? "Ten telefon nie ma magnetometru." :
                String.format(Locale.US, "Pole: %.1f µT · tło: %.1f µT · progi diod: 1 / 3 / 8 / 20 / 40 µT.\n" +
                        "Dotknij ON, by włączyć. CAL – kalibracja tła z dala od metalu. Poziom 5 trafia do dziennika.",
                        s.emfTotal, s.emfBaseline);
        if (!t.contentEquals(info.getText())) info.setText(t);
    }

    // ================= rysunek urządzenia =================

    final class Meter extends View {
        boolean on = false;
        int level = 0;
        float value = 0f;
        private boolean pressed = false, calPressed = false;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF r = new RectF();
        private final Seg7 seg = new Seg7();
        private float btnX, btnY, btnR, calX, calY, calR;

        Meter(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w);
            setMeasuredDimension(W, (int) (W * 1.55f));
        }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), H = getHeight(), u = W / 100f;
            float x0 = 18 * u, x1 = 82 * u, top = 3 * u, bot = H - 3 * u;
            float neckY = top + 78 * u;

            // obudowa: szeroka głowa, zwężający się uchwyt
            path.reset();
            path.moveTo(x0 + 10 * u, top);
            path.lineTo(x1 - 10 * u, top);
            path.quadTo(x1, top, x1, top + 10 * u);
            path.lineTo(x1, neckY);
            path.quadTo(x1, neckY + 12 * u, x1 - 8 * u, neckY + 22 * u);
            path.lineTo(x1 - 8 * u, bot - 10 * u);
            path.quadTo(x1 - 8 * u, bot, x1 - 18 * u, bot);
            path.lineTo(x0 + 18 * u, bot);
            path.quadTo(x0 + 8 * u, bot, x0 + 8 * u, bot - 10 * u);
            path.lineTo(x0 + 8 * u, neckY + 22 * u);
            path.quadTo(x0, neckY + 12 * u, x0, neckY);
            path.lineTo(x0, top + 10 * u);
            path.quadTo(x0, top, x0 + 10 * u, top);
            path.close();
            p.setShader(new LinearGradient(x0, 0, x1, 0,
                    new int[]{0xFF0C0C0C, 0xFF2A2A2A, 0xFF0C0C0C}, null, Shader.TileMode.CLAMP));
            c.drawPath(path, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.5f * u);
            p.setColor(0xFF3A3A3A);
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);

            // diody
            float ledY = top + 8 * u, ledStep = (x1 - x0 - 16 * u) / 4f;
            for (int i = 0; i < 5; i++) {
                float lx = x0 + 8 * u + i * ledStep;
                boolean lit = i < level;
                if (lit) {
                    p.setShader(new RadialGradient(lx, ledY, 7 * u, (COLORS[i] & 0x00FFFFFF) | 0x99000000,
                            COLORS[i] & 0x00FFFFFF, Shader.TileMode.CLAMP));
                    c.drawCircle(lx, ledY, 7 * u, p);
                    p.setShader(null);
                }
                p.setColor(0xFF050505);
                c.drawCircle(lx, ledY, 3.4f * u, p);
                p.setShader(new RadialGradient(lx - u, ledY - u, 3 * u,
                        lit ? 0xFFFFFFFF : dim(COLORS[i], 0.45f), lit ? COLORS[i] : dim(COLORS[i], 0.22f),
                        Shader.TileMode.CLAMP));
                c.drawCircle(lx, ledY, 2.8f * u, p);
                p.setShader(null);
            }

            // płytka ze skalą
            r.set(x0 + 4 * u, top + 15 * u, x1 - 4 * u, top + 38 * u);
            p.setColor(0xFFEDEDED);
            c.drawRoundRect(r, 1.5f * u, 1.5f * u, p);
            float bw = (r.width() - 6 * u) / 5f;
            String[] lbl = {"1", "3", "8", "20", "40+"};
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(3.2f * u);
            for (int i = 0; i < 5; i++) {
                float bx = r.left + 3 * u + i * bw;
                float bh = (r.height() - 11 * u) * (0.35f + 0.16f * i);
                p.setColor(COLORS[i]);
                c.drawRect(bx + 0.5f * u, r.bottom - 7.5f * u - bh, bx + bw - 0.5f * u, r.bottom - 7.5f * u, p);
                p.setColor(0xFF222222);
                c.drawText(lbl[i], bx + bw / 2, r.bottom - 4 * u, p);
            }
            p.setTextSize(2.6f * u);
            c.drawText("Δ µT  ·  ELECTROMAGNETIC FIELD", r.centerX(), r.bottom - 1.2f * u, p);

            // mały LCD
            r.set(x0 + 10 * u, top + 42 * u, x1 - 10 * u, top + 56 * u);
            p.setColor(0xFF1A1A1A);
            c.drawRoundRect(r, u, u, p);
            r.inset(u, u);
            p.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                    on ? 0xFF9FD49A : 0xFF5E6B5A, on ? 0xFF7DB878 : 0xFF505B4D, Shader.TileMode.CLAMP));
            c.drawRect(r, p);
            p.setShader(null);
            int segOn = 0xFF0E1A0C, ghost = 0x1A0E1A0C;
            String v = !on ? " OFF" : value < 100 ? String.format(Locale.US, "%4.1f", value) : String.format(Locale.US, "%4.0f", Math.min(value, 9999f));
            float sh = r.height() * 0.7f;
            float sx = seg.draw(c, v, r.left + 3 * u, r.top + r.height() * 0.15f, sh, on ? segOn : 0x330E1A0C, ghost);
            p.setColor(on ? segOn : 0x330E1A0C);
            p.setTextAlign(Paint.Align.LEFT);
            p.setTextSize(3.4f * u);
            c.drawText("µT", sx + u, r.bottom - 1.5f * u, p);

            // przycisk ON
            btnX = W / 2f;
            btnY = top + 68 * u;
            btnR = 8 * u;
            p.setColor(0xFF050505);
            c.drawCircle(btnX, btnY + 0.6f * u, btnR + 1.2f * u, p);
            p.setShader(new RadialGradient(btnX - 2 * u, btnY - 2 * u, btnR * 1.4f,
                    pressed ? 0xFF3A3A3A : 0xFF5A5A5A, 0xFF151515, Shader.TileMode.CLAMP));
            c.drawCircle(btnX, btnY + (pressed ? 0.5f * u : 0), btnR, p);
            p.setShader(null);
            p.setColor(on ? 0xFF56E39F : 0xFFB0B0B0);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(3.6f * u);
            c.drawText(on ? "ON" : "OFF", btnX, btnY + 1.3f * u, p);

            // przycisk CAL
            calX = x1 - 13 * u;
            calY = btnY;
            calR = 4 * u;
            p.setColor(calPressed ? 0xFF2A2A2A : 0xFF3C3C3C);
            c.drawCircle(calX, calY, calR, p);
            p.setColor(0xFFB0B0B0);
            p.setTextSize(2.4f * u);
            c.drawText("CAL", calX, calY + 0.9f * u, p);

            // dioda zasilania
            p.setColor(on ? 0xFFFF3B30 : 0xFF3A1010);
            c.drawCircle(x0 + 13 * u, btnY, 1.3f * u, p);

            // żeberka uchwytu
            p.setColor(0xFF1E1E1E);
            for (float y = neckY + 30 * u; y < bot - 16 * u; y += 3.2f * u) {
                c.drawRoundRect(new RectF(x0 + 16 * u, y, x1 - 16 * u, y + 1.4f * u), u, u, p);
            }
            p.setColor(0xFF6A6A6A);
            p.setTextSize(3.6f * u);
            c.drawText("EMF-5", W / 2f, bot - 7 * u, p);
        }

        private int dim(int col, float f) {
            int r0 = (int) (((col >> 16) & 255) * f), g0 = (int) (((col >> 8) & 255) * f), b0 = (int) ((col & 255) * f);
            return 0xFF000000 | (r0 << 16) | (g0 << 8) | b0;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float dx = e.getX() - btnX, dy = e.getY() - btnY;
            float cx = e.getX() - calX, cy = e.getY() - calY;
            boolean inBtn = dx * dx + dy * dy < btnR * btnR * 2;
            boolean inCal = cx * cx + cy * cy < calR * calR * 3;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (!inBtn && !inCal) return false;
                    pressed = inBtn;
                    calPressed = inCal;
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                    if (pressed) on = !on;
                    if (calPressed) {
                        core.sensors.calibrate();
                        core.toast("Skalibrowano tło EMF");
                    }
                    pressed = calPressed = false;
                    invalidate();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    pressed = calPressed = false;
                    invalidate();
                    return true;
            }
            return true;
        }
    }
}
