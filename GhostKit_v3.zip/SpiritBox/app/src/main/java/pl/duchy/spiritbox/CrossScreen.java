package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Random;

/** Krucyfiks: postaw telefon w pokoju. Gdy pole EMF gwałtownie skoczy, krucyfiks "płonie" i zużywa ładunek. */
final class CrossScreen extends Screen {

    private final CrossView view;
    private final Button armBtn;
    private ToneGenerator tone;
    private boolean active = false;
    private int charges = 2;
    private long burnUntil = 0, cooldown = 0;

    CrossScreen(MainActivity a) {
        super(a);
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 90); } catch (RuntimeException ignored) { }
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(8), dp(8), dp(8), dp(20));
        sv.addView(root);
        addView(sv);
        view = new CrossView(a);
        root.addView(view);
        LinearLayout row = Ui.row(a);
        armBtn = Ui.btn(a, "");
        armBtn.setOnClickListener(v -> { active = !active; refresh(); });
        Button reset = Ui.btn(a, "↺ Nowy krucyfiks");
        reset.setOnClickListener(v -> { charges = 2; refresh(); });
        Ui.addWeighted(row, armBtn);
        Ui.addWeighted(row, reset);
        root.addView(row);
        TextView info = Ui.text(a, "Postaw aktywny krucyfiks w pokoju. Gdy magnetometr wykryje silny skok pola " +
                "(poziom 4 lub 5 EMF), krucyfiks płonie i zużywa jeden z 2 ładunków. Każde użycie trafia do dziennika.",
                12, Ui.DIM, false);
        info.setPadding(dp(8), dp(8), dp(8), 0);
        root.addView(info);
        refresh();
    }

    private void refresh() {
        armBtn.setText(active ? "✝ AKTYWNY" : "✝ UAKTYWNIJ");
        Ui.color(armBtn, active ? 0xFF6A5A14 : 0xFF262626);
    }

    @Override
    String title() {
        return "Krucyfiks";
    }

    @Override
    void tick() {
        long now = System.currentTimeMillis();
        int lvl = Sensors.level(core.sensors.emfDelta, EmfScreen.LEVELS);
        if (active && charges > 0 && lvl >= 4 && now > cooldown) {
            charges--;
            burnUntil = now + 3500;
            cooldown = now + 8000;
            if (tone != null) tone.startTone(ToneGenerator.TONE_SUP_ERROR, 900);
            core.vibrate(700);
            core.alert("Krucyfiks zadziałał! Zostało ładunków: " + charges);
            core.book.setEvidence("cross", true, true);
        }
        view.burning = now < burnUntil;
        view.charges = charges;
        view.active = active;
        view.invalidate();
    }

    static final class CrossView extends View {
        boolean burning, active;
        int charges = 2;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random rnd = new Random();

        CrossView(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w);
            setMeasuredDimension(W, (int) (W * 1.3f));
        }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), H = getHeight(), u = W / 100f;
            float cx = 50 * u, armY = 40 * u;

            if (burning) {
                float fl = 0.8f + rnd.nextFloat() * 0.4f;
                p.setShader(new RadialGradient(cx, armY, 60 * u * fl, 0xCCFF5A10, 0x00FF2000, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, W, H, p);
                p.setShader(null);
            } else if (active && charges > 0) {
                p.setShader(new RadialGradient(cx, armY, 50 * u, 0x33FFE08A, 0x00FFE08A, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, W, H, p);
                p.setShader(null);
            }

            int[] gold = charges == 0 ? new int[]{0xFF1A1410, 0xFF3A2E22, 0xFF120E0A}
                    : burning ? new int[]{0xFF7A2A08, 0xFFFFB050, 0xFF7A2A08}
                    : new int[]{0xFF5E4A1E, 0xFFE8D088, 0xFF7A6230, 0xFFC8AE60, 0xFF4E3C18};
            Shader sh = new LinearGradient(20 * u, 0, 80 * u, H, gold, null, Shader.TileMode.MIRROR);

            // belki
            RectF vert = new RectF(cx - 6 * u, 6 * u, cx + 6 * u, H - 8 * u);
            RectF hor = new RectF(12 * u, armY - 6 * u, 88 * u, armY + 6 * u);
            p.setShader(sh);
            c.drawRoundRect(vert, 2 * u, 2 * u, p);
            c.drawRoundRect(hor, 2 * u, 2 * u, p);

            // ozdobne zakończenia (trójliście)
            trefoil(c, cx, 6 * u, 0, -1, u);
            trefoil(c, cx, H - 8 * u, 0, 1, u);
            trefoil(c, 12 * u, armY, -1, 0, u);
            trefoil(c, 88 * u, armY, 1, 0, u);

            // środek
            c.drawCircle(cx, armY, 11 * u, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.8f * u);
            p.setColor(0x66000000);
            c.drawCircle(cx, armY, 11 * u, p);
            c.drawCircle(cx, armY, 7.5f * u, p);
            vert.inset(2.2f * u, 2.2f * u);
            hor.inset(2.2f * u, 2.2f * u);
            c.drawRoundRect(vert, u, u, p);
            c.drawRoundRect(hor, u, u, p);
            // promienie
            for (int i = 0; i < 8; i++) {
                double a = Math.PI * 2 * i / 8 + Math.PI / 8;
                c.drawLine(cx + (float) Math.cos(a) * 12 * u, armY + (float) Math.sin(a) * 12 * u,
                        cx + (float) Math.cos(a) * 17 * u, armY + (float) Math.sin(a) * 17 * u, p);
            }
            p.setStyle(Paint.Style.FILL);

            // dym, gdy płonie
            if (burning) {
                p.setColor(0x44222222);
                for (int i = 0; i < 25; i++)
                    c.drawCircle(cx + (rnd.nextFloat() - 0.5f) * 30 * u, armY - rnd.nextFloat() * 35 * u, (2 + rnd.nextFloat() * 4) * u, p);
            }

            p.setColor(0xFFB0A080);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(4 * u);
            String st = charges == 0 ? "ZUŻYTY" : burning ? "PŁONIE!" : active ? "AKTYWNY · ładunki: " + charges : "nieaktywny · ładunki: " + charges;
            c.drawText(st, cx, H - 1.5f * u, p);
        }

        private void trefoil(Canvas c, float x, float y, int dx, int dy, float u) {
            float r = 4.5f * u;
            float ox = dx * 4 * u, oy = dy * 4 * u;
            c.drawCircle(x + ox, y + oy, r, p);
            float px = dy != 0 ? 5 * u : 0, py = dx != 0 ? 5 * u : 0;
            c.drawCircle(x - px, y - py, r * 0.85f, p);
            c.drawCircle(x + px, y + py, r * 0.85f, p);
        }
    }
}
