package pl.duchy.spiritbox;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.HandlerThread;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Podgląd kamery innego członka drużyny + zdalne sterowanie i zapis u siebie. */
final class ViewerScreen extends Screen implements Core.FrameSink {

    private final FeedView feed;
    private final LinearLayout camList;
    private final TextView hint;
    private final Button flashBtn, nvBtn, motionBtn, recBtn;
    private String selected = null, selName = "";
    private volatile boolean rFlash, rNv, rMotion = true;
    private VideoRecorder recorder;
    private HandlerThread worker;
    private Handler wh;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private String listSig = "";
    private long lastSub = 0;

    ViewerScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(4), dp(4), dp(4), dp(20));
        sv.addView(root);
        addView(sv);

        HorizontalScrollView hs = new HorizontalScrollView(a);
        camList = Ui.row(a);
        hs.addView(camList);
        root.addView(hs);

        feed = new FeedView(a);
        root.addView(feed);

        LinearLayout r1 = Ui.row(a);
        flashBtn = Ui.btn(a, "");
        flashBtn.setOnClickListener(v -> cmd("flash", !rFlash));
        nvBtn = Ui.btn(a, "");
        nvBtn.setOnClickListener(v -> cmd("nv", !rNv));
        motionBtn = Ui.btn(a, "");
        motionBtn.setOnClickListener(v -> cmd("motion", !rMotion));
        Ui.addWeighted(r1, flashBtn);
        Ui.addWeighted(r1, nvBtn);
        Ui.addWeighted(r1, motionBtn);
        root.addView(r1);

        LinearLayout r2 = Ui.row(a);
        Button photo = Ui.btn(a, "📸 Zdjęcie u mnie");
        photo.setOnClickListener(v -> {
            if (selected == null) return;
            Gallery.photo(core, act, feed, "Zdjęcie z kamery: " + selName + " (zapisał " + core.myName + ")");
        });
        recBtn = Ui.btn(a, "");
        recBtn.setOnClickListener(v -> toggleRec());
        Ui.addWeighted(r2, photo);
        Ui.addWeighted(r2, recBtn);
        root.addView(r2);

        hint = Ui.text(a, "", 12, Ui.DIM, false);
        hint.setPadding(dp(8), dp(8), dp(8), 0);
        root.addView(hint);
        refreshButtons();
    }

    @Override
    String title() {
        return "Podgląd kamer";
    }

    @Override
    void onShow() {
        core.frameSink = this;
        if (worker == null) {
            worker = new HandlerThread("view-worker");
            worker.start();
            wh = new Handler(worker.getLooper());
        }
        if (selected != null) core.net.subscribe(selected, true);
        listSig = "";
    }

    @Override
    void onHide() {
        if (core.frameSink == this) core.frameSink = null;
        if (selected != null) core.net.subscribe(selected, false);
        if (recorder != null) toggleRec();
        if (worker != null) {
            worker.quitSafely();
            worker = null;
            wh = null;
        }
    }

    @Override
    void tick() {
        long now = System.currentTimeMillis();
        if (selected != null && now - lastSub > 2000) {
            lastSub = now;
            core.net.subscribe(selected, true);
        }
        List<Core.Member> cams = core.cameras();
        StringBuilder sig = new StringBuilder();
        for (Core.Member m : cams) sig.append(m.id).append(m.name).append(';');
        String s = sig.toString() + core.net.isConnected();
        if (!s.equals(listSig)) {
            listSig = s;
            camList.removeAllViews();
            for (Core.Member m : cams) {
                Button b = Ui.btn(act, "📹 " + m.name, m.id.equals(selected) ? 0xFF5A1E12 : 0xFF262626, Ui.TEXT);
                b.setOnClickListener(v -> select(m.id, m.name));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(dp(4), dp(4), dp(4), dp(4));
                camList.addView(b, lp);
            }
            String h;
            if (!core.net.isConnected()) h = "Nie jesteś w drużynie. Wejdź w „Drużyna” i połącz telefony.";
            else if (cams.isEmpty()) h = "Nikt nie ma włączonej kamery. Na innym telefonie otwórz „Ghost Cam”.";
            else h = "Wybierz kamerę powyżej. Latarka, noktowizja i ruch sterują kamerą zdalnie; " +
                        "zdjęcia i nagrania zapisują się u ciebie, w galerii i we wspólnym dzienniku.";
            hint.setText(h);
            if (selected != null && core.members.get(selected) == null) {
                feed.frame = null;
                feed.invalidate();
            }
        }
        refreshButtons();
    }

    private void select(String id, String name) {
        if (id.equals(selected)) return;
        if (recorder != null) toggleRec();
        if (selected != null) core.net.subscribe(selected, false);
        selected = id;
        selName = name;
        feed.frame = null;
        feed.label = name;
        feed.invalidate();
        core.net.subscribe(id, true);
        listSig = "";
    }

    private void cmd(String c, boolean v) {
        if (selected == null) {
            core.toast("Najpierw wybierz kamerę");
            return;
        }
        core.sendCmd(selected, c, v);
        switch (c) {
            case "flash": rFlash = v; break;
            case "nv": rNv = v; break;
            case "motion": rMotion = v; break;
        }
        refreshButtons();
    }

    private void refreshButtons() {
        String f = rFlash ? "🔦 Latarka: WŁ" : "🔦 Latarka";
        if (!f.contentEquals(flashBtn.getText())) {
            flashBtn.setText(f);
            Ui.color(flashBtn, rFlash ? 0xFF6A5A14 : 0xFF262626);
        }
        String n = rNv ? "🌙 NV: WŁ" : "🌙 Noktowizja";
        if (!n.contentEquals(nvBtn.getText())) {
            nvBtn.setText(n);
            Ui.color(nvBtn, rNv ? 0xFF1E5A2A : 0xFF262626);
        }
        String m = rMotion ? "👁 Ruch: WŁ" : "👁 Ruch: WYŁ";
        if (!m.contentEquals(motionBtn.getText())) {
            motionBtn.setText(m);
            Ui.color(motionBtn, rMotion ? 0xFF1E3A5A : 0xFF262626);
        }
        String r = recorder != null ? "■ Stop nagrywania" : "⏺ Nagrywaj u mnie";
        if (!r.contentEquals(recBtn.getText())) {
            recBtn.setText(r);
            Ui.color(recBtn, recorder != null ? 0xFF7A1A14 : 0xFF262626);
        }
    }

    @Override
    public void onFrame(Net.Msg m) {
        if (selected == null || !selected.equals(m.j.optString("from")) || m.bin == null) return;
        Handler h = wh;
        if (h == null || !busy.compareAndSet(false, true)) return;
        h.post(() -> {
            try {
                Bitmap b = BitmapFactory.decodeByteArray(m.bin, 0, m.bin.length);
                if (b == null) return;
                rFlash = m.j.optBoolean("flash");
                rNv = m.j.optBoolean("nv");
                rMotion = m.j.optBoolean("motion", true);
                feed.rot = m.j.optInt("rot", 90);
                feed.mirror = m.j.optBoolean("mirror");
                feed.nv = rNv;
                feed.flash = rFlash;
                feed.motionOn = rMotion;
                feed.label = m.j.optString("name", selName);
                if (m.j.optBoolean("alert")) feed.motionUntil = System.currentTimeMillis() + 1500;
                feed.setFrame(b, m.j.optLong("ts", System.currentTimeMillis()));
                VideoRecorder r = recorder;
                if (r != null) r.addFrame(feed.compose(feed.outW(), feed.outH()));
            } catch (Exception ignored) {
            } finally {
                busy.set(false);
            }
        });
    }

    private void toggleRec() {
        if (recorder != null) {
            final VideoRecorder r = recorder;
            recorder = null;
            feed.rec = false;
            r.stop(ok -> Gallery.finishVideo(core, act, r.file, ok,
                    "Nagranie z kamery: " + selName + " (zapisał " + core.myName + ")"));
        } else {
            if (selected == null || feed.frame == null) {
                core.toast("Brak obrazu");
                return;
            }
            File f = new File(act.getCacheDir(), "GhostView_" + Ui.fileStamp() + ".mp4");
            recorder = new VideoRecorder(f, feed.outW(), feed.outH());
            feed.rec = true;
        }
        refreshButtons();
    }
}
