# Ghost Kit (Android 6.0+)

Zestaw łowcy duchów w jednej aplikacji, bez zewnętrznych bibliotek.

## Narzędzia
- **Spirit Box** – skaner szumu (FM/AM), opcjonalnie strzępki dźwięku z mikrofonu. Głosy zapisują się w dzienniku (automatycznie albo przyciskiem).
- **EMF-5** – 5 diod, odczyt z magnetometru, poziom 5 trafia do dziennika.
- **Termometr** – czujnik temperatury otoczenia (jeśli telefon go ma), w przeciwnym razie temperatura baterii.
- **Ghost Cam** – kamera z nakładką (REC, data i godzina, NV), latarka, noktowizja, wykrywanie ruchu, zdjęcia i nagrania MP4.
- **Podgląd kamer** – oglądanie kamery innego telefonu, zdalna latarka/NV/ruch, zdjęcia i nagrania u siebie.
- **Czujnik ruchu** – akcelerometr + czujnik zbliżeniowy, alarm na wszystkich telefonach.
- **Krucyfiks** – płonie przy silnym skoku EMF (2 ładunki).
- **Pozytywka** – własna melodia albo wybrany plik audio; rozstraja się przy skoku EMF.
- **Dziennik** – wspólny dla drużyny: wpisy, dowody, głosy, zdjęcia, nagrania; przycisk czyszczenia.
- **Drużyna** – łączenie telefonów: Wi-Fi, hotspot, Tailscale (internet).

## Budowanie
GitHub Actions: w repozytorium dokładnie jeden plik .zip z projektem + workflow `.github/workflows/build.yml`.
Albo Android Studio: File → Open → Build → Build APK(s).
