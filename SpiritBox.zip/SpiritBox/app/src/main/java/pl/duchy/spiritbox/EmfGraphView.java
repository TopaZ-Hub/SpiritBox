package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Przewijany wykres odchylenia pola magnetycznego (ΔµT). */
public class EmfGraphView extends View {
    private final float[] data = new float[240];
    private int pos = 0;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint();
    private final Path path = new Path();

    public EmfGraphView(Context c) {
        super(c);
        line.setColor(Color.parseColor("#7CFFB2"));
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(3f);
        grid.setColor(Color.parseColor("#1E3A2A"));
        grid.setStrokeWidth(1f);
        setBackgroundColor(Color.parseColor("#06100A"));
    }

    public void add(float v) {
        data[pos] = v;
        pos = (pos + 1) % data.length;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        for (int i = 1; i < 4; i++) c.drawLine(0, h * i / 4f, w, h * i / 4f, grid);

        float max = 10f; // skala min. 10 µT
        for (float v : data) if (v > max) max = v;
        max *= 1.15f;

        path.reset();
        for (int i = 0; i < data.length; i++) {
            float v = data[(pos + i) % data.length];
            float x = w * i / (float) (data.length - 1);
            float y = h - (v / max) * h;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        c.drawPath(path, line);
    }
}
