package pl.duchy.spiritbox;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;

import java.io.File;
import java.io.IOException;
import java.util.Random;

/**
 * Silnik "spirit boxa".
 *
 * Prawdziwy spirit box skanuje radio FM i co kilkadziesiąt ms przeskakuje na kolejną stację,
 * a z poszarpanych strzępków dźwięku słuchacz wyłapuje "słowa". Telefony (w tym Samsung A56)
 * nie dają aplikacjom dostępu do tunera FM, więc tutaj każdy krok skanu to losowo:
 *  - szum eteru (filtrowany biały szum w losowym paśmie),
 *  - "nośna" (gwizd/zawodzenie jak między stacjami),
 *  - strzępek dźwięku z otoczenia nagrany mikrofonem (opcjonalnie, czasem odwrócony),
 * po czym następuje krótka cisza jak przy przełączaniu stacji. ZERO bazy słów –
 * nic nie jest syntezowane jako mowa.
 */
final class SweepEngine {

    static final int SR = 44100;

    static final int STEP_STATIC = 0;
    static final int STEP_CARRIER = 1;
    static final int STEP_MIC = 2;

    interface Listener {
        void onStep(int type);
    }

    private volatile boolean running = false;
    private volatile int sweepMs = 150;
    private volatile boolean useMic = false;
    private volatile boolean useEcho = true;
    private volatile Listener listener;

    private Thread playThread;
    private Thread micThread;

    // Bufor pierścieniowy z mikrofonu (8 s)
    private final short[] ring = new short[SR * 8];
    private int ringPos = 0;
    private int ringFilled = 0;
    private final Object ringLock = new Object();

    private final Object wavLock = new Object();
    private WavWriter wav;

    private final Random rnd = new Random();

    void setListener(Listener l) { listener = l; }

    void setSweepMs(int ms) { sweepMs = Math.max(30, Math.min(1000, ms)); }

    void setEcho(boolean on) { useEcho = on; }

    boolean isRunning() { return running; }

    /** Dorzuca szum z czujnika (najmłodsze bity pomiaru) do generatora losowego. */
    void addEntropy(float v) {
        long bits = Float.floatToIntBits(v) & 0xFFFFL;
        rnd.setSeed(rnd.nextLong() ^ (bits << 17) ^ System.nanoTime());
    }

    synchronized void setUseMic(boolean on) {
        useMic = on;
        if (on && running && (micThread == null || !micThread.isAlive())) startMic();
    }

    synchronized void start() {
        if (running) return;
        running = true;
        playThread = new Thread(this::playLoop, "spiritbox-play");
        playThread.setPriority(Thread.MAX_PRIORITY);
        playThread.start();
        if (useMic) startMic();
    }

    synchronized void stop() {
        running = false;
        try {
            if (playThread != null) playThread.join(800);
            if (micThread != null) micThread.join(800);
        } catch (InterruptedException ignored) { }
        playThread = null;
        micThread = null;
    }

    // ---------- Nagrywanie sesji ----------

    void startRecording(File f) throws IOException {
        synchronized (wavLock) {
            if (wav != null) wav.close();
            wav = new WavWriter(f, SR);
        }
    }

    /** @return zapisany plik albo null */
    File stopRecording() {
        synchronized (wavLock) {
            if (wav == null) return null;
            File f = wav.getFile();
            try { wav.close(); } catch (IOException ignored) { }
            wav = null;
            return f;
        }
    }

    boolean isRecording() {
        synchronized (wavLock) { return wav != null; }
    }

    // ---------- Mikrofon ----------

    private void startMic() {
        micThread = new Thread(this::micLoop, "spiritbox-mic");
        micThread.start();
    }

    private void micLoop() {
        AudioRecord rec = null;
        try {
            int minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT);
            rec = new AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, SR));
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) return;
            rec.startRecording();
            short[] tmp = new short[1024];
            while (running && useMic) {
                int r = rec.read(tmp, 0, tmp.length);
                if (r <= 0) continue;
                synchronized (ringLock) {
                    for (int i = 0; i < r; i++) {
                        ring[ringPos] = tmp[i];
                        ringPos = (ringPos + 1) % ring.length;
                        if (ringFilled < ring.length) ringFilled++;
                    }
                }
            }
        } catch (SecurityException | IllegalStateException | IllegalArgumentException ignored) {
        } finally {
            if (rec != null) {
                try { rec.stop(); } catch (Exception ignored) { }
                rec.release();
            }
        }
    }

    /** Kopiuje losowy, nie najświeższy fragment z bufora mikrofonu. */
    private boolean randomMicFragment(float[] out, int n) {
        synchronized (ringLock) {
            int minBack = n + SR / 2; // co najmniej 0,5 s wstecz → mniej sprzężenia
            if (ringFilled < minBack + SR / 4) return false;
            int back = minBack + rnd.nextInt(ringFilled - minBack);
            int start = ((ringPos - back) % ring.length + ring.length) % ring.length;
            for (int i = 0; i < n; i++) out[i] = ring[(start + i) % ring.length] / 32768f;
        }
        return true;
    }

    // ---------- Generator ----------

    private void playLoop() {
        int minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack track;
        try {
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(SR)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build())
                    .setBufferSizeInBytes(Math.max(minBuf * 2, 8192))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
        } catch (Exception e) {
            running = false;
            return;
        }
        track.play();

        float[] echo = new float[(int) (SR * 0.21f)];
        int echoPos = 0;
        Biquad bp = new Biquad();
        Biquad voice = new Biquad();
        float[] buf = new float[SR * 2];
        short[] pcm = new short[SR * 2];

        while (running) {
            int n = SR * sweepMs / 1000;
            int jitter = n / 5;
            if (jitter > 0) n += rnd.nextInt(jitter * 2) - jitter; // nieregularność jak w prawdziwym skanie
            int gap = SR * (4 + rnd.nextInt(14)) / 1000;
            if (n + gap > buf.length) n = buf.length - gap;

            int type = chooseType();
            if (type == STEP_MIC && !randomMicFragment(buf, n)) type = STEP_STATIC;

            switch (type) {
                case STEP_STATIC: genStatic(buf, n, bp); break;
                case STEP_CARRIER: genCarrier(buf, n); break;
                default: shapeVoice(buf, n, voice); break;
            }

            // krótkie wygładzenie brzegów (2 ms), żeby nie trzaskało za mocno
            int fade = Math.min(SR / 500, n / 4);
            for (int i = 0; i < fade; i++) {
                float g = i / (float) fade;
                buf[i] *= g;
                buf[n - 1 - i] *= g;
            }

            // przerwa między "stacjami" + pojedynczy klik
            for (int i = 0; i < gap; i++) buf[n + i] = (rnd.nextFloat() * 2 - 1) * 0.008f;
            if (gap > 2) buf[n + 1] = 0.25f;

            int total = n + gap;
            for (int i = 0; i < total; i++) {
                float x = buf[i];
                if (useEcho) {
                    float d = echo[echoPos];
                    echo[echoPos] = x + d * 0.38f;
                    echoPos = (echoPos + 1) % echo.length;
                    x = x + d * 0.42f;
                }
                x = (float) Math.tanh(x * 1.3f);
                pcm[i] = (short) (x * 30000f);
            }

            Listener l = listener;
            if (l != null) l.onStep(type);

            track.write(pcm, 0, total);

            synchronized (wavLock) {
                if (wav != null) {
                    try { wav.write(pcm, total); } catch (IOException ignored) { }
                }
            }
        }

        try { track.stop(); } catch (Exception ignored) { }
        track.release();
    }

    private int chooseType() {
        float r = rnd.nextFloat();
        if (useMic) {
            if (r < 0.40f) return STEP_MIC;
            if (r < 0.82f) return STEP_STATIC;
            return STEP_CARRIER;
        }
        return r < 0.72f ? STEP_STATIC : STEP_CARRIER;
    }

    private void genStatic(float[] b, int n, Biquad bp) {
        float f = 350f + rnd.nextFloat() * 3800f;
        float q = 0.6f + rnd.nextFloat() * 3f;
        bp.bandpass(f, q, SR);
        float amp = 0.5f + rnd.nextFloat() * 0.9f;
        // czasem "szczątkowa modulacja" – szum przerywany jak sylaby
        float am = rnd.nextFloat() < 0.4f ? 3f + rnd.nextFloat() * 6f : 0f;
        for (int i = 0; i < n; i++) {
            float w = rnd.nextFloat() * 2f - 1f;
            float env = am > 0 ? 0.55f + 0.45f * (float) Math.sin(2 * Math.PI * am * i / SR) : 1f;
            b[i] = bp.process(w) * amp * 2.2f * env + w * 0.05f;
        }
    }

    private void genCarrier(float[] b, int n) {
        double f0 = 140 + rnd.nextDouble() * 1300;
        double f1 = f0 * (0.55 + rnd.nextDouble() * 0.9);
        double whistle = 1800 + rnd.nextDouble() * 3500;
        double amf = 2 + rnd.nextDouble() * 10;
        double ph = 0, ph2 = 0;
        for (int i = 0; i < n; i++) {
            double t = i / (double) n;
            double f = f0 + (f1 - f0) * t;
            ph += 2 * Math.PI * f / SR;
            ph2 += 2 * Math.PI * (whistle * (1 - 0.3 * t)) / SR;
            double am = 0.6 + 0.4 * Math.sin(2 * Math.PI * amf * i / SR);
            float noise = rnd.nextFloat() * 2f - 1f;
            b[i] = (float) (Math.sin(ph) * 0.28 * am + Math.sin(ph2) * 0.05) + noise * 0.07f;
        }
    }

    /** Fragment z mikrofonu: pasmo "radiowe/telefoniczne", automatyczne wzmocnienie, szum. */
    private void shapeVoice(float[] b, int n, Biquad voice) {
        if (rnd.nextFloat() < 0.3f) { // odwrócony fragment
            for (int i = 0, j = n - 1; i < j; i++, j--) { float t = b[i]; b[i] = b[j]; b[j] = t; }
        }
        voice.reset();
        voice.bandpass(1100f, 0.55f, SR);
        double sum = 0;
        for (int i = 0; i < n; i++) {
            b[i] = voice.process(b[i]);
            sum += b[i] * b[i];
        }
        float rms = (float) Math.sqrt(sum / Math.max(1, n));
        float gain = rms > 1e-5f ? Math.min(0.30f / rms, 45f) : 1f;
        for (int i = 0; i < n; i++) {
            float w = rnd.nextFloat() * 2f - 1f;
            b[i] = b[i] * gain + w * 0.09f;
        }
    }
}
