package pl.duchy.spiritbox;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {

    private static final int REQ_MIC = 42;
    private static final int GREEN = Color.parseColor("#7CFFB2");
    private static final int DIM = Color.parseColor("#3C6B50");
    private static final int BG = Color.parseColor("#0B120E");
    private static final int PANEL = Color.parseColor("#122019");

    // poziomy ΔµT dla 5 diod
    private static final float[] LEVELS = {1.5f, 4f, 10f, 25f, 50f};
    private static final int[] LED_COLORS = {
            Color.parseColor("#2EE66B"), Color.parseColor("#9BE62E"),
            Color.parseColor("#F2E02B"), Color.parseColor("#FF9A1F"),
            Color.parseColor("#FF3B30")};

    private final SweepEngine engine = new SweepEngine();
    private SensorManager sm;
    private Sensor mag;
    private ToneGenerator tone;

    private float baseline = -1f, smoothDelta = 0f, lastTotal = 0f;
    private long lastUi = 0, lastBeep = 0, lastLog = 0;
    private float channel = 87.5f;

    private TextView emfTotal, emfDelta, scanText, logText, stepDot;
    private final TextView[] leds = new TextView[5];
    private EmfGraphView graph;
    private Button boxBtn, recBtn;
    private Switch micSwitch, beepSwitch;
    private final ArrayDeque<String> log = new ArrayDeque<>();
    private final SimpleDateFormat hms = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        mag = sm != null ? sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) : null;
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 70); } catch (RuntimeException ignored) { }

        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        setContentView(buildUi());

        engine.setListener(type -> runOnUiThread(() -> onStep(type)));
    }

    // ================= UI =================

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        root.setPadding(p, dp(28), p, p);
        sv.addView(root);

        TextView title = text("SPIRIT BOX", 30, GREEN, true);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.2f);
        root.addView(title);
        TextView sub = text("skaner + detektor EMF", 13, DIM, false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        // ---- EMF ----
        LinearLayout emf = panel(root, "DETEKTOR EMF (magnetometr)");
        emfTotal = text("—", 16, DIM, false);
        emfDelta = text("Δ 0.0 µT", 40, GREEN, true);
        emf.addView(emfDelta);
        emf.addView(emfTotal);

        LinearLayout ledRow = new LinearLayout(this);
        ledRow.setOrientation(LinearLayout.HORIZONTAL);
        ledRow.setPadding(0, dp(10), 0, dp(10));
        for (int i = 0; i < 5; i++) {
            TextView led = new TextView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(22), 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            led.setLayoutParams(lp);
            leds[i] = led;
            setLed(i, false);
            ledRow.addView(led);
        }
        emf.addView(ledRow);

        graph = new EmfGraphView(this);
        graph.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(110)));
        emf.addView(graph);

        LinearLayout emfBtns = new LinearLayout(this);
        emfBtns.setPadding(0, dp(10), 0, 0);
        Button cal = button("KALIBRUJ");
        cal.setOnClickListener(v -> {
            baseline = lastTotal;
            smoothDelta = 0;
            toast("Ustawiono tło magnetyczne. Trzymaj telefon z dala od metalu i magnesów.");
        });
        emfBtns.addView(cal, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        emf.addView(emfBtns);

        beepSwitch = sw("Pikanie przy skoku EMF", true);
        emf.addView(beepSwitch);

        if (mag == null) {
            emfDelta.setText("BRAK CZUJNIKA");
            emfTotal.setText("Ten telefon nie ma magnetometru.");
        }

        // ---- BOX ----
        LinearLayout box = panel(root, "SKANER");
        LinearLayout scanRow = new LinearLayout(this);
        scanRow.setGravity(Gravity.CENTER_VERTICAL);
        stepDot = text("●", 22, DIM, true);
        stepDot.setPadding(0, 0, dp(10), 0);
        scanText = text("87.5", 40, GREEN, true);
        scanRow.addView(stepDot);
        scanRow.addView(scanText);
        box.addView(scanRow);

        boxBtn = button("▶  START");
        boxBtn.setOnClickListener(v -> toggleBox());
        box.addView(boxBtn);

        TextView speedLbl = text("Szybkość skanu: 150 ms", 14, GREEN, false);
        speedLbl.setPadding(0, dp(12), 0, 0);
        box.addView(speedLbl);
        SeekBar speed = new SeekBar(this);
        speed.setMax(470); // 30..500 ms
        speed.setProgress(150 - 30);
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean u) {
                int ms = prog + 30;
                engine.setSweepMs(ms);
                speedLbl.setText("Szybkość skanu: " + ms + " ms");
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(speed);

        micSwitch = sw("Strzępki dźwięku z otoczenia (mikrofon)", false);
        micSwitch.setOnCheckedChangeListener((bt, on) -> {
            if (on && !hasMic()) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                return;
            }
            engine.setUseMic(on);
            if (on) toast("Użyj słuchawek – inaczej głośnik wraca do mikrofonu.");
        });
        box.addView(micSwitch);

        Switch echo = sw("Pogłos", true);
        echo.setOnCheckedChangeListener((bt, on) -> engine.setEcho(on));
        box.addView(echo);

        recBtn = button("●  NAGRYWAJ SESJĘ");
        recBtn.setOnClickListener(v -> toggleRec());
        box.addView(recBtn);

        // ---- LOG ----
        LinearLayout lg = panel(root, "DZIENNIK ZDARZEŃ");
        logText = text("Brak zdarzeń.", 13, GREEN, false);
        logText.setTypeface(Typeface.MONOSPACE);
        lg.addView(logText);

        TextView info = text("Uwaga: to aplikacja rozrywkowa. Dźwięk powstaje z szumu i przypadkowych " +
                "fragmentów otoczenia – mózg z natury doszukuje się w nim słów. Magnetometr reaguje " +
                "na magnesy, metal, kable i elektronikę.", 11, DIM, false);
        info.setPadding(0, dp(16), 0, dp(8));
        root.addView(info);
        return sv;
    }

    private LinearLayout panel(LinearLayout parent, String label) {
        TextView h = text(label, 12, DIM, true);
        h.setLetterSpacing(0.15f);
        h.setPadding(dp(4), dp(20), 0, dp(6));
        parent.addView(h);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(PANEL);
        g.setCornerRadius(dp(14));
        g.setStroke(dp(1), Color.parseColor("#1F3B2B"));
        l.setBackground(g);
        parent.addView(l);
        return l;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(BG);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setColor(GREEN);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        lp.setMargins(0, dp(10), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private Switch sw(String s, boolean on) {
        Switch w = new Switch(this);
        w.setText(s);
        w.setTextColor(GREEN);
        w.setChecked(on);
        w.setPadding(0, dp(10), 0, dp(4));
        return w;
    }

    private void setLed(int i, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(5));
        g.setColor(on ? LED_COLORS[i] : Color.parseColor("#1A2A20"));
        leds[i].setBackground(g);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ================= SKANER =================

    private void toggleBox() {
        if (engine.isRunning()) {
            if (engine.isRecording()) toggleRec();
            engine.stop();
            boxBtn.setText("▶  START");
            stepDot.setTextColor(DIM);
            addLog("Koniec sesji");
        } else {
            engine.setUseMic(micSwitch.isChecked() && hasMic());
            engine.start();
            boxBtn.setText("■  STOP");
            addLog("Start sesji");
        }
    }

    private void onStep(int type) {
        channel += 0.2f;
        if (channel > 108.0f) channel = 87.5f;
        scanText.setText(String.format(Locale.US, "%.1f", channel));
        int c = type == SweepEngine.STEP_MIC ? Color.parseColor("#FFB347")
                : type == SweepEngine.STEP_CARRIER ? Color.parseColor("#7FD8FF") : GREEN;
        stepDot.setTextColor(c);
    }

    private void toggleRec() {
        if (engine.isRecording()) {
            File f = engine.stopRecording();
            recBtn.setText("●  NAGRYWAJ SESJĘ");
            if (f != null) new Thread(() -> publish(f)).start();
            return;
        }
        if (!engine.isRunning()) {
            toast("Najpierw włącz skaner.");
            return;
        }
        try {
            String name = "SpiritBox_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".wav";
            File dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);
            if (dir == null) dir = getFilesDir();
            engine.startRecording(new File(dir, name));
            recBtn.setText("■  ZATRZYMAJ NAGRYWANIE");
            addLog("Nagrywanie…");
        } catch (Exception e) {
            toast("Nie udało się rozpocząć nagrywania: " + e.getMessage());
        }
    }

    /** Na Androidzie 10+ przenosi nagranie do Muzyka/SpiritBox, żeby było widać je w plikach. */
    private void publish(File f) {
        String where = f.getAbsolutePath();
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Audio.Media.DISPLAY_NAME, f.getName());
                v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/x-wav");
                v.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/SpiritBox");
                Uri uri = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
                if (uri != null) {
                    try (OutputStream os = getContentResolver().openOutputStream(uri);
                         InputStream is = new FileInputStream(f)) {
                        byte[] buf = new byte[65536];
                        int r;
                        while ((r = is.read(buf)) > 0) os.write(buf, 0, r);
                    }
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                    where = "Muzyka/SpiritBox/" + f.getName();
                }
            } catch (Exception ignored) { }
        }
        final String msg = "Zapisano: " + where;
        runOnUiThread(() -> { toast(msg); addLog("Nagranie zapisane"); });
    }

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_MIC) return;
        boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        micSwitch.setChecked(ok);
        engine.setUseMic(ok);
        if (!ok) toast("Bez dostępu do mikrofonu skaner używa tylko szumu.");
    }

    // ================= EMF =================

    @Override
    public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1], z = e.values[2];
        float m = (float) Math.sqrt(x * x + y * y + z * z);
        lastTotal = m;
        if (baseline < 0) baseline = m;
        else baseline += (m - baseline) * 0.002f; // powolne dopasowanie do tła
        float d = Math.abs(m - baseline);
        smoothDelta += (d - smoothDelta) * 0.25f;
        engine.addEntropy(m);

        int level = 0;
        for (float t : LEVELS) if (smoothDelta >= t) level++;

        long now = System.currentTimeMillis();
        if (level >= 3) {
            if (beepSwitch.isChecked() && tone != null && now - lastBeep > 250) {
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 60 + level * 20);
                lastBeep = now;
            }
            if (now - lastLog > 2000) {
                addLog(String.format(Locale.US, "Skok EMF Δ%.1f µT%s", smoothDelta,
                        engine.isRunning() ? " (w trakcie sesji)" : ""));
                lastLog = now;
            }
        }

        if (now - lastUi < 60) return;
        lastUi = now;
        emfDelta.setText(String.format(Locale.US, "Δ %.1f µT", smoothDelta));
        emfDelta.setTextColor(level == 0 ? GREEN : LED_COLORS[level - 1]);
        emfTotal.setText(String.format(Locale.US, "Pole całkowite: %.1f µT  ·  tło: %.1f µT", m, baseline));
        for (int i = 0; i < 5; i++) setLed(i, i < level);
        graph.add(smoothDelta);
    }

    @Override
    public void onAccuracyChanged(Sensor s, int a) { }

    private void addLog(String s) {
        log.addFirst(hms.format(new Date()) + "  " + s);
        while (log.size() > 25) log.removeLast();
        StringBuilder sb = new StringBuilder();
        for (String l : log) sb.append(l).append('\n');
        logText.setText(sb.toString().trim());
    }

    // ================= Cykl życia =================

    @Override
    protected void onResume() {
        super.onResume();
        if (mag != null) sm.registerListener(this, mag, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sm != null) sm.unregisterListener(this);
    }

    @Override
    protected void onDestroy() {
        if (engine.isRecording()) {
            File f = engine.stopRecording();
            if (f != null) publish(f);
        }
        engine.stop();
        if (tone != null) tone.release();
        super.onDestroy();
    }
}
