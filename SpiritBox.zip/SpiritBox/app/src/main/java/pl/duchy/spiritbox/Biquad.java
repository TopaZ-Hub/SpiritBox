package pl.duchy.spiritbox;

/** Prosty filtr biquad (RBJ) – pasmowo-przepustowy, w strukturze transposed DF-II. */
final class Biquad {
    private float b0, b1, b2, a1, a2, z1, z2;

    void bandpass(float freq, float q, int sampleRate) {
        double w = 2 * Math.PI * freq / sampleRate;
        double alpha = Math.sin(w) / (2 * q);
        double a0 = 1 + alpha;
        b0 = (float) (alpha / a0);
        b1 = 0f;
        b2 = (float) (-alpha / a0);
        a1 = (float) (-2 * Math.cos(w) / a0);
        a2 = (float) ((1 - alpha) / a0);
    }

    float process(float x) {
        float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

    void reset() {
        z1 = 0f;
        z2 = 0f;
    }
}
