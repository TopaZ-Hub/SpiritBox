package pl.duchy.spiritbox;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Ekran główny – sprzęt do wyboru. */
final class MenuScreen extends Screen {

    private static final Object[][] TOOLS = {
            {"box", "📻", "Spirit Box", "skaner częstotliwości", 0xFFFF6A3D},
            {"emf", "📶", "Miernik EMF", "pole elektromagnetyczne", 0xFF3DDC97},
            {"thermo", "🌡️", "Termometr", "pomiar temperatury", 0xFF4DB8FF},
            {"cam", "📹", "Kamera", "noktowizja · nagrywanie", 0xFF8B6CFF},
            {"view", "🖥️", "Podgląd kamer", "kamery drużyny", 0xFF2EE6C5},
            {"motion", "🚨", "Czujnik ruchu", "alarm na drużynę", 0xFFFF4D5E},
            {"music", "🎵", "Pozytywka", "melodia", 0xFFFFB547},
            {"book", "📖", "Dziennik", "słowa · zdjęcia · nagrania", 0xFFC9A46A},
            {"team", "👥", "Drużyna", "połącz telefony", 0xFF9AA3B8},
    };

    private final TextView status;
    private final TextView chip;

    MenuScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(16), dp(12), dp(16), dp(28));
        sv.addView(root);
        addView(sv);

        TextView h = Ui.text(a, "Ghost Kit", 34, Ui.TEXT, false);
        h.setTypeface(Ui.BLACK);
        root.addView(h);
        status = Ui.text(a, "", 14, Ui.DIM, false);
        status.setPadding(0, dp(2), 0, dp(10));
        root.addView(status);

        chip = Ui.text(a, "", 13, Ui.TEXT, true);
        chip.setPadding(dp(14), dp(8), dp(14), dp(8));
        chip.setOnClickListener(v -> act.open("team"));
        LinearLayout chipRow = Ui.row(a);
        chipRow.addView(chip);
        root.addView(chipRow);

        root.addView(Ui.section(a, "Sprzęt"));

        LinearLayout row = null;
        for (int i = 0; i < TOOLS.length; i++) {
            if (i % 2 == 0) {
                row = Ui.row(a);
                root.addView(row);
            }
            Object[] t = TOOLS[i];
            LinearLayout tile = Ui.col(a);
            tile.setPadding(dp(14), dp(16), dp(14), dp(16));
            Ui.card(tile, 22);
            tile.addView(Ui.badge(a, (String) t[1], (Integer) t[4], 48));
            TextView name = Ui.text(a, (String) t[2], 16, Ui.TEXT, true);
            name.setPadding(0, dp(12), 0, 0);
            TextView sub = Ui.text(a, (String) t[3], 12, Ui.DIM, false);
            tile.addView(name);
            tile.addView(sub);
            final String key = (String) t[0];
            tile.setOnClickListener(v -> act.open(key));
            Ui.addWeighted(row, tile);
        }
        if (TOOLS.length % 2 == 1 && row != null) Ui.addWeighted(row, new android.view.View(a));
    }

    @Override
    String title() {
        return "";
    }

    @Override
    void tick() {
        String s = core.engine.isRunning() ? "Spirit Box skanuje w tle" : "Wybierz sprzęt";
        if (!s.contentEquals(status.getText())) status.setText(s);

        boolean on = core.net.isConnected();
        String c = on ? "● Drużyna · " + (core.members.size() + 1) + " os." + (core.net.role == Net.HOST ? " · host" : "")
                : "○ Solo · " + core.myName + " — dotknij, aby połączyć";
        if (!c.contentEquals(chip.getText())) {
            chip.setText(c);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(20));
            g.setColor(on ? 0x2E3DDC97 : 0x22FFFFFF);
            g.setStroke(dp(1), on ? 0x663DDC97 : Ui.STROKE);
            chip.setBackground(g);
            chip.setTextColor(on ? Ui.GREEN : Ui.TEXT);
        }
    }
}
