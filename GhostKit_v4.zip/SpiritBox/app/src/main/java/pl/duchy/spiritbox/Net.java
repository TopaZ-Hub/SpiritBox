package pl.duchy.spiritbox;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Sieć drużyny w układzie gwiazdy: jeden telefon jest hostem (serwer TCP), reszta łączy się do niego.
 * Host przekazuje wiadomości dalej. Działa w tej samej sieci Wi-Fi, przez hotspot telefonu
 * oraz przez internet w sieci VPN typu Tailscale (łączenie po adresie IP).
 */
final class Net {
    static final int PORT = 47800;
    static final int DISC_PORT = 47801;
    private static final int MAGIC = 0x53425831;

    static final int NONE = 0, HOST = 1, CLIENT = 2;

    interface Listener {
        void onMsg(Msg m);
        void onNetState();
    }

    static final class Msg {
        final JSONObject j;
        final byte[] bin;

        Msg(JSONObject j, byte[] bin) {
            this.j = j;
            this.bin = bin;
        }

        String type() {
            return j.optString("type");
        }

        static JSONObject obj(String type) {
            JSONObject o = new JSONObject();
            try { o.put("type", type); } catch (JSONException ignored) { }
            return o;
        }
    }

    final class Peer {
        final Socket s;
        final DataInputStream in;
        final DataOutputStream out;
        volatile String id = "";
        volatile String name = "?";
        final LinkedBlockingQueue<Msg> q = new LinkedBlockingQueue<>();
        final AtomicReference<Msg> frame = new AtomicReference<>();
        final Set<String> subs = Collections.newSetFromMap(new ConcurrentHashMap<>());
        volatile boolean alive = true;

        Peer(Socket s) throws IOException {
            this.s = s;
            s.setTcpNoDelay(true);
            in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 65536));
            out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream(), 65536));
        }

        void start() {
            new Thread(this::readLoop, "net-read").start();
            new Thread(this::writeLoop, "net-write").start();
        }

        private void readLoop() {
            try {
                while (alive) onIncoming(this, readMsg(in));
            } catch (Exception ignored) {
            } finally {
                close();
                onPeerClosed(this);
            }
        }

        private void writeLoop() {
            try {
                while (alive) {
                    Msg m = q.poll(25, TimeUnit.MILLISECONDS);
                    if (m != null) writeMsg(out, m);
                    Msg f = frame.getAndSet(null);
                    if (f != null) writeMsg(out, f);
                    if (m != null || f != null) out.flush();
                }
            } catch (Exception ignored) {
            } finally {
                close();
            }
        }

        void close() {
            alive = false;
            try { s.close(); } catch (IOException ignored) { }
        }
    }

    private final Context ctx;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    final String myId;
    volatile String myName = "?";

    volatile int role = NONE;
    volatile boolean connecting = false;
    volatile String lastError = null;
    volatile String hostIp = null;

    private ServerSocket server;
    final List<Peer> peers = new CopyOnWriteArrayList<>();
    private volatile Peer hostPeer;
    private final Set<String> localSubs = Collections.newSetFromMap(new ConcurrentHashMap<>());

    // wykrywanie hostów
    final Map<String, String> foundName = new ConcurrentHashMap<>();
    final Map<String, Long> foundSeen = new ConcurrentHashMap<>();
    private volatile boolean discRunning = false;
    private WifiManager.MulticastLock mlock;

    Net(Context c, Listener l, String myId) {
        ctx = c.getApplicationContext();
        listener = l;
        this.myId = myId;
    }

    boolean isConnected() {
        return role == HOST || (role == CLIENT && hostPeer != null);
    }

    // ================= host =================

    synchronized void startHost() {
        stop();
        role = HOST;
        lastError = null;
        new Thread(() -> {
            try {
                ServerSocket ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(PORT));
                server = ss;
                while (role == HOST) {
                    Socket s = ss.accept();
                    Peer p = new Peer(s);
                    peers.add(p);
                    p.start();
                }
            } catch (IOException e) {
                if (role == HOST && server == null) {
                    role = NONE;
                    lastError = "Nie udało się uruchomić hosta: " + e.getMessage();
                    notifyState();
                }
            }
        }, "net-accept").start();
        startBeacon();
        notifyState();
    }

    private void startBeacon() {
        new Thread(() -> {
            try (DatagramSocket ds = new DatagramSocket()) {
                ds.setBroadcast(true);
                while (role == HOST) {
                    byte[] d = ("SBX|" + myName).getBytes(StandardCharsets.UTF_8);
                    for (InetAddress a : broadcastAddrs()) {
                        try { ds.send(new DatagramPacket(d, d.length, a, DISC_PORT)); } catch (IOException ignored) { }
                    }
                    Thread.sleep(1500);
                }
            } catch (Exception ignored) { }
        }, "net-beacon").start();
    }

    private static List<InetAddress> broadcastAddrs() {
        List<InetAddress> list = new ArrayList<>();
        try {
            list.add(InetAddress.getByName("255.255.255.255"));
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null) list.add(b);
                }
            }
        } catch (Exception ignored) { }
        return list;
    }

    /** Adresy IPv4 tego telefonu (do wpisania na innych telefonach). */
    static List<String> localIps() {
        List<String> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address) out.add(a.getHostAddress() + "  (" + ni.getName() + ")");
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    // ================= klient =================

    synchronized void connect(String ip) {
        stop();
        role = CLIENT;
        connecting = true;
        lastError = null;
        notifyState();
        new Thread(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip.trim(), PORT), 6000);
                Peer p = new Peer(s);
                p.id = "host";
                JSONObject h = Msg.obj("hello");
                h.put("id", myId);
                h.put("name", myName);
                p.q.add(new Msg(h, null));
                hostPeer = p;
                hostIp = ip.trim();
                p.start();
            } catch (Exception e) {
                role = NONE;
                lastError = "Nie udało się połączyć z " + ip;
            }
            connecting = false;
            notifyState();
        }, "net-connect").start();
    }

    void startDiscovery() {
        if (discRunning) return;
        discRunning = true;
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                mlock = wm.createMulticastLock("sbx");
                mlock.setReferenceCounted(false);
                mlock.acquire();
            }
        } catch (Exception ignored) { }
        new Thread(() -> {
            try (DatagramSocket ds = new DatagramSocket(null)) {
                ds.setReuseAddress(true);
                ds.bind(new InetSocketAddress(DISC_PORT));
                ds.setSoTimeout(1000);
                byte[] buf = new byte[512];
                while (discRunning) {
                    DatagramPacket pk = new DatagramPacket(buf, buf.length);
                    try { ds.receive(pk); } catch (SocketTimeoutException t) { continue; }
                    String s = new String(pk.getData(), 0, pk.getLength(), StandardCharsets.UTF_8);
                    if (!s.startsWith("SBX|")) continue;
                    String ip = pk.getAddress().getHostAddress();
                    foundName.put(ip, s.substring(4));
                    foundSeen.put(ip, System.currentTimeMillis());
                }
            } catch (IOException ignored) { }
        }, "net-discovery").start();
    }

    void stopDiscovery() {
        discRunning = false;
        try { if (mlock != null && mlock.isHeld()) mlock.release(); } catch (Exception ignored) { }
    }

    // ================= wspólne =================

    synchronized void stop() {
        role = NONE;
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        server = null;
        for (Peer p : peers) p.close();
        peers.clear();
        Peer hp = hostPeer;
        hostPeer = null;
        if (hp != null) hp.close();
        localSubs.clear();
        notifyState();
    }

    int peerCount() {
        return role == HOST ? peers.size() : (hostPeer != null ? 1 : 0);
    }

    /** Wysyła wiadomość do całej drużyny (host rozsyła dalej). */
    void send(Msg m) {
        String t = m.type();
        if (role == HOST) {
            if (t.equals("cmd")) {
                String to = m.j.optString("to");
                for (Peer o : peers) if (to.equals(o.id)) o.q.add(m);
            } else if (t.equals("frame")) {
                for (Peer o : peers) if (o.subs.contains(myId)) o.frame.set(m);
            } else if (t.equals("audio")) {
                for (Peer o : peers) if (o.subs.contains(myId)) o.q.add(m);
            } else {
                for (Peer o : peers) o.q.add(m);
            }
        } else if (role == CLIENT) {
            Peer hp = hostPeer;
            if (hp == null) return;
            if (t.equals("frame")) hp.frame.set(m); else hp.q.add(m);
        }
    }

    /** Tylko host: wiadomość do jednego członka drużyny. */
    void sendTo(String peerId, Msg m) {
        if (role != HOST) return;
        for (Peer o : peers) if (peerId.equals(o.id)) o.q.add(m);
    }

    /** Subskrypcję trzeba odnawiać co kilka sekund – kamera nadaje tylko, gdy ktoś ogląda. */
    void subscribe(String camId, boolean on) {
        if (role == HOST) {
            if (on) {
                localSubs.add(camId);
                forwardWatch(camId);
            } else localSubs.remove(camId);
        } else if (role == CLIENT) {
            JSONObject o = Msg.obj(on ? "sub" : "unsub");
            try { o.put("cam", camId); } catch (JSONException ignored) { }
            send(new Msg(o, null));
        }
    }

    private void forwardWatch(String camId) {
        JSONObject o = Msg.obj("watch");
        try { o.put("cam", camId); } catch (JSONException ignored) { }
        Msg w = new Msg(o, null);
        if (camId.equals(myId)) deliver(w);
        else for (Peer x : peers) if (camId.equals(x.id)) x.q.add(w);
    }

    private void onIncoming(Peer peer, Msg m) {
        String t = m.type();
        if (role != HOST) {
            deliver(m);
            return;
        }
        switch (t) {
            case "hello":
                peer.id = m.j.optString("id");
                peer.name = m.j.optString("name");
                deliver(m);
                return;
            case "sub":
                peer.subs.add(m.j.optString("cam"));
                forwardWatch(m.j.optString("cam"));
                return;
            case "unsub":
                peer.subs.remove(m.j.optString("cam"));
                return;
            case "frame": {
                String from = m.j.optString("from");
                for (Peer o : peers) if (o != peer && o.subs.contains(from)) o.frame.set(m);
                if (localSubs.contains(from)) deliver(m);
                return;
            }
            case "audio": {
                String from = m.j.optString("from");
                for (Peer o : peers) if (o != peer && o.subs.contains(from)) o.q.add(m);
                if (localSubs.contains(from)) deliver(m);
                return;
            }
            case "cmd": {
                String to = m.j.optString("to");
                if (to.equals(myId)) deliver(m);
                else for (Peer o : peers) if (to.equals(o.id)) o.q.add(m);
                return;
            }
            default:
                deliver(m);
                for (Peer o : peers) if (o != peer) o.q.add(m);
        }
    }

    private void onPeerClosed(Peer p) {
        if (role == HOST && peers.remove(p)) {
            JSONObject o = Msg.obj("left");
            try { o.put("id", p.id); } catch (JSONException ignored) { }
            Msg m = new Msg(o, null);
            for (Peer x : peers) x.q.add(m);
            deliver(m);
        } else if (role == CLIENT && p == hostPeer) {
            hostPeer = null;
            role = NONE;
            lastError = "Rozłączono z hostem";
            notifyState();
        }
    }

    private void deliver(Msg m) {
        main.post(() -> listener.onMsg(m));
    }

    private void notifyState() {
        main.post(listener::onNetState);
    }

    // ================= ramki =================

    private static void writeMsg(DataOutputStream o, Msg m) throws IOException {
        byte[] js = m.j.toString().getBytes(StandardCharsets.UTF_8);
        o.writeInt(MAGIC);
        o.writeInt(js.length);
        o.write(js);
        int bl = m.bin == null ? 0 : m.bin.length;
        o.writeInt(bl);
        if (bl > 0) o.write(m.bin);
    }

    private static Msg readMsg(DataInputStream i) throws IOException, JSONException {
        if (i.readInt() != MAGIC) throw new IOException("bad magic");
        int jl = i.readInt();
        if (jl < 0 || jl > 8_000_000) throw new IOException("bad json len");
        byte[] js = new byte[jl];
        i.readFully(js);
        int bl = i.readInt();
        if (bl < 0 || bl > 100_000_000) throw new IOException("bad bin len");
        byte[] b = null;
        if (bl > 0) {
            b = new byte[bl];
            i.readFully(b);
        }
        return new Msg(new JSONObject(new String(js, StandardCharsets.UTF_8)), b);
    }
}
