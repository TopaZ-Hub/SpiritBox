package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Czujnik ruchu: telefon leży nieruchomo, a akcelerometr i czujnik zbliżeniowy wykrywają poruszenie. */
final class MotionScreen extends Screen {

    private static final float[] SENS = {1.2f, 0.6f, 0.3f};
    private static final String[] SENS_NAME = {"NISKA", "ŚREDNIA", "WYSOKA"};

    private final Pir pir;
    private final Button armBtn, sensBtn;
    private final TextView info;
    private ToneGenerator tone;
    private boolean armed = false;
    private long armAt = 0, triggeredUntil = 0, lastEvent = 0;
    private int sens = 1, lastProx = 0, count = 0;

    MotionScreen(MainActivity a) {
        super(a);
        try { tone = new ToneGenerator(AudioManager.STREAM_ALARM, 90); } catch (RuntimeException ignored) { }
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(8), dp(8), dp(8), dp(20));
        sv.addView(root);
        addView(sv);
        pir = new Pir(a);
        root.addView(pir);
        LinearLayout row = Ui.row(a);
        armBtn = Ui.btn(a, "");
        armBtn.setOnClickListener(v -> toggleArm());
        sensBtn = Ui.btn(a, "");
        sensBtn.setOnClickListener(v -> { sens = (sens + 1) % 3; refresh(); });
        Ui.addWeighted(row, armBtn);
        Ui.addWeighted(row, sensBtn);
        root.addView(row);
        info = Ui.text(a, "Połóż telefon nieruchomo (np. na stole lub podłodze) i uzbrój czujnik. " +
                "Po 3 s reaguje na drgania podłoża i na coś, co przejdzie tuż nad ekranem (czujnik zbliżeniowy). " +
                "Alarm trafia do dziennika i na telefony całej drużyny.", 12, Ui.DIM, false);
        info.setPadding(dp(8), dp(10), dp(8), 0);
        root.addView(info);
        refresh();
    }

    private void refresh() {
        armBtn.setText(armed ? "■ ROZBRÓJ" : "▶ UZBRÓJ");
        Ui.color(armBtn, armed ? 0xFF6A1A14 : 0xFF1E4A30);
        sensBtn.setText("Czułość: " + SENS_NAME[sens]);
    }

    private void toggleArm() {
        armed = !armed;
        if (armed) {
            armAt = System.currentTimeMillis() + 3000;
            count = 0;
            core.toast("Uzbrajanie… odłóż telefon");
        }
        refresh();
    }

    @Override
    String title() {
        return "Czujnik ruchu";
    }

    @Override
    void tick() {
        long now = System.currentTimeMillis();
        float jolt = core.sensors.takeJolt();
        int prox = core.sensors.proxChanges;
        boolean proxHit = prox != lastProx;
        lastProx = prox;
        if (armed && now > armAt && (jolt > SENS[sens] || proxHit)) {
            triggeredUntil = now + 2500;
            if (tone != null) tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 400);
            if (now - lastEvent > 5000) {
                lastEvent = now;
                count++;
                core.alert(proxHit ? "Czujnik ruchu: coś przeszło nad telefonem" : "Czujnik ruchu: wykryto drgania");
            }
        }
        pir.armed = armed && now > armAt;
        pir.arming = armed && now <= armAt;
        pir.triggered = now < triggeredUntil;
        pir.count = count;
        pir.invalidate();
    }

    final class Pir extends View {
        boolean armed, arming, triggered;
        int count;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        Pir(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w);
            setMeasuredDimension(W, (int) (W * 1.15f));
        }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), H = getHeight(), u = W / 100f;
            long now = System.currentTimeMillis();

            // uchwyt montażowy
            p.setColor(0xFF2A2A2A);
            c.drawRoundRect(new RectF(42 * u, 2 * u, 58 * u, 12 * u), 2 * u, 2 * u, p);

            // obudowa
            r.set(14 * u, 8 * u, 86 * u, H - 4 * u);
            p.setShader(new LinearGradient(r.left, 0, r.right, 0,
                    new int[]{0xFFB8B8B4, 0xFFEDEDE8, 0xFFB0B0AC}, null, Shader.TileMode.CLAMP));
            c.drawRoundRect(r, 10 * u, 10 * u, p);
            p.setShader(null);

            // soczewka Fresnela
            float cx = 50 * u, cy = 46 * u, rad = 24 * u;
            p.setShader(new RadialGradient(cx - 6 * u, cy - 8 * u, rad * 1.3f,
                    0xFFF5F5F0, 0xFFA8A8A0, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, rad, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.4f * u);
            p.setColor(0x55000000);
            for (int i = 1; i < 6; i++) c.drawCircle(cx, cy, rad * i / 6f, p);
            for (int i = 0; i < 12; i++) {
                double a = Math.PI * 2 * i / 12;
                c.drawLine(cx, cy, cx + (float) Math.cos(a) * rad, cy + (float) Math.sin(a) * rad, p);
            }
            p.setStyle(Paint.Style.FILL);

            // dioda
            float lx = 50 * u, ly = 80 * u;
            int col;
            if (triggered) col = 0xFFFF2020;
            else if (arming) col = (now / 250) % 2 == 0 ? 0xFFFFB020 : 0xFF3A2A10;
            else if (armed) col = (now / 1000) % 2 == 0 ? 0xFF30FF60 : 0xFF0F3A1A;
            else col = 0xFF2A2A2A;
            if (triggered) {
                p.setShader(new RadialGradient(lx, ly, 14 * u, 0xAAFF2020, 0x00FF2020, Shader.TileMode.CLAMP));
                c.drawCircle(lx, ly, 14 * u, p);
                p.setShader(null);
            }
            p.setColor(0xFF555555);
            c.drawCircle(lx, ly, 3.2f * u, p);
            p.setColor(col);
            c.drawCircle(lx, ly, 2.4f * u, p);

            p.setColor(0xFF4A4A48);
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(4 * u);
            c.drawText(triggered ? "RUCH!" : armed ? "UZBROJONY" : arming ? "UZBRAJANIE…" : "WYŁĄCZONY", 50 * u, 92 * u, p);
            p.setTextSize(3 * u);
            c.drawText("MOTION SENSOR  ·  alarmy: " + count, 50 * u, 99 * u, p);
        }
    }
}
