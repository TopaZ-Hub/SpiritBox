package pl.duchy.spiritbox;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Wspólny stan aplikacji: sieć, dziennik, czujniki, Spirit Box i lista drużyny. */
final class Core implements Net.Listener {

    private static Core instance;

    static Core get(Context c) {
        if (instance == null) instance = new Core(c.getApplicationContext());
        return instance;
    }

    static final class Member {
        String id, name, tool;
        float emf, temp;
        boolean cam;
        long seen;
    }

    interface FrameSink { void onFrame(Net.Msg m); }

    interface CmdSink { void onCmd(String c, boolean v, int n, String fromName); }

    interface AudioSink { void onAudio(Net.Msg m); }

    final Context ctx;
    final Handler main = new Handler(Looper.getMainLooper());
    final SharedPreferences prefs;
    final String myId;
    String myName;

    final Net net;
    final Book book;
    final Sensors sensors;
    final SweepEngine engine = new SweepEngine();

    String tool = "menu";
    volatile boolean camActive = false;
    volatile long lastWatched = 0;
    final Map<String, Member> members = new LinkedHashMap<>();

    FrameSink frameSink;
    AudioSink audioSink;
    CmdSink cmdSink;
    Runnable teamUi;

    private Core(Context c) {
        ctx = c;
        prefs = c.getSharedPreferences("sbx", Context.MODE_PRIVATE);
        String id = prefs.getString("id", null);
        if (id == null) {
            id = UUID.randomUUID().toString().substring(0, 8);
            prefs.edit().putString("id", id).apply();
        }
        myId = id;
        myName = prefs.getString("name", Build.MODEL);
        net = new Net(c, this, myId);
        net.myName = myName;
        book = new Book(c, this);
        sensors = new Sensors(c, engine);
        main.postDelayed(statusTick, 1000);
    }

    void setName(String n) {
        n = n.trim();
        if (n.isEmpty()) return;
        myName = n;
        net.myName = n;
        prefs.edit().putString("name", n).apply();
    }

    private final Runnable statusTick = new Runnable() {
        @Override
        public void run() {
            if (net.isConnected()) net.send(statusMsg());
            long now = System.currentTimeMillis();
            boolean changed = false;
            Iterator<Member> it = members.values().iterator();
            while (it.hasNext()) {
                if (now - it.next().seen > 6000) { it.remove(); changed = true; }
            }
            if (changed && teamUi != null) teamUi.run();
            main.postDelayed(this, 1000);
        }
    };

    private Net.Msg statusMsg() {
        JSONObject o = Net.Msg.obj("status");
        try {
            o.put("from", myId);
            o.put("name", myName);
            o.put("tool", tool);
            o.put("emf", (double) sensors.emfDelta);
            o.put("temp", (double) sensors.temperature());
            o.put("cam", camActive);
        } catch (JSONException ignored) { }
        return new Net.Msg(o, null);
    }

    List<Member> cameras() {
        List<Member> l = new ArrayList<>();
        for (Member m : members.values()) if (m.cam) l.add(m);
        return l;
    }

    // ================= wiadomości z sieci =================

    @Override
    public void onMsg(Net.Msg m) {
        JSONObject j = m.j;
        switch (m.type()) {
            case "status": {
                String from = j.optString("from");
                if (from.equals(myId)) return;
                Member mb = members.get(from);
                if (mb == null) { mb = new Member(); mb.id = from; members.put(from, mb); }
                mb.name = j.optString("name");
                mb.tool = j.optString("tool");
                mb.emf = (float) j.optDouble("emf", 0);
                mb.temp = (float) j.optDouble("temp", Double.NaN);
                mb.cam = j.optBoolean("cam");
                mb.seen = System.currentTimeMillis();
                if (teamUi != null) teamUi.run();
                break;
            }
            case "hello":
                if (net.role == Net.HOST) {
                    book.syncTo(j.optString("id"));
                    toast(j.optString("name") + " dołączył do drużyny");
                }
                break;
            case "left":
                members.remove(j.optString("id"));
                if (teamUi != null) teamUi.run();
                break;
            case "watch":
                if (j.optString("cam").equals(myId)) lastWatched = System.currentTimeMillis();
                break;
            case "audio":
                if (audioSink != null) audioSink.onAudio(m);
                break;
            case "frame":
                if (frameSink != null) frameSink.onFrame(m);
                break;
            case "cmd":
                if (j.optString("to").equals(myId) && cmdSink != null)
                    cmdSink.onCmd(j.optString("c"), j.optBoolean("v"), j.optInt("n", 0), j.optString("name"));
                break;
            case "book_add":
                book.receive(m);
                break;
            case "book_clear":
                book.clear(false);
                toast(j.optString("name") + " wyczyścił dziennik");
                break;
            case "event":
                toast("⚠ " + j.optString("text"));
                vibrate(400);
                break;
        }
    }

    @Override
    public void onNetState() {
        if (!net.isConnected()) members.clear();
        if (net.lastError != null) {
            toast(net.lastError);
            net.lastError = null;
        }
        if (teamUi != null) teamUi.run();
    }

    // ================= pomocnicze =================

    /** Zdarzenie: alarm (powiadomienie + wibracja) na telefonach całej drużyny. */
    void alert(String text) {
        if (net.isConnected()) {
            JSONObject o = Net.Msg.obj("event");
            try {
                o.put("name", myName);
                o.put("text", myName + ": " + text);
            } catch (JSONException ignored) { }
            net.send(new Net.Msg(o, null));
        }
    }

    void sendCmd(String to, String c, boolean v) {
        sendCmd(to, c, v, 0);
    }

    void sendCmd(String to, String c, boolean v, int n) {
        JSONObject o = Net.Msg.obj("cmd");
        try {
            o.put("to", to);
            o.put("c", c);
            o.put("v", v);
            o.put("n", n);
            o.put("name", myName);
        } catch (JSONException ignored) { }
        net.send(new Net.Msg(o, null));
    }

    void toast(String s) {
        Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show();
    }

    @SuppressWarnings("deprecation")
    void vibrate(long ms) {
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(ms);
        } catch (Exception ignored) { }
    }
}
