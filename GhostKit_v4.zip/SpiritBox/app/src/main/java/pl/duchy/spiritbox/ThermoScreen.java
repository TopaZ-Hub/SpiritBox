package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/** Termometr w kształcie pirometru. Odczyt z czujnika otoczenia albo baterii telefonu. */
final class ThermoScreen extends Screen {

    private final Gun gun;
    private final TextView info;
    private ToneGenerator tone;
    private float ref = Float.NaN, min = Float.NaN, max = Float.NaN, shown = Float.NaN;
    private boolean fahrenheit = false, laser = true, measuring = false, cold = false, light = true;
    private int emis = 95;
    private long lastEvent = 0, lastBeep = 0;

    ThermoScreen(MainActivity a) {
        super(a);
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 60); } catch (RuntimeException ignored) { }
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(8), dp(8), dp(8), dp(20));
        sv.addView(root);
        addView(sv);
        gun = new Gun(a);
        root.addView(gun);
        info = Ui.text(a, "", 12, Ui.DIM, false);
        info.setPadding(dp(8), dp(10), dp(8), 0);
        root.addView(info);
    }

    @Override
    String title() {
        return "Termometr";
    }

    @Override
    void tick() {
        Sensors s = core.sensors;
        float t = s.temperature();
        long now = System.currentTimeMillis();
        if (measuring && !Float.isNaN(t)) {
            shown = t;
            if (Float.isNaN(ref)) ref = t;
            if (Float.isNaN(min) || t < min) min = t;
            if (Float.isNaN(max) || t > max) max = t;
            cold = t <= ref - 1.5f || t < 10f;
            if (cold && now - lastBeep > 600 && tone != null) {
                tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 80);
                lastBeep = now;
            }
            if (cold && now - lastEvent > 30000) {
                lastEvent = now;
                core.alert(String.format(Locale.US, "Zimne miejsce: %.1f °C (start %.1f °C)", t, ref));
            }
        }
        gun.invalidate();
        String p = Float.isNaN(s.pressure) ? "" : String.format(Locale.US, " · ciśnienie %.1f hPa", s.pressure);
        String txt = "Trzymaj spust (uchwyt), aby mierzyć. Źródło: " + s.tempSource() + p + ".\n" +
                (s.hasAmbientTemp() ? "" : "Ten telefon nie ma czujnika temperatury otoczenia, więc pokazuje temperaturę " +
                        "wnętrza telefonu – zmienia się wolno. ") +
                "Spadek o 1,5 °C od pierwszego pomiaru lub poniżej 10 °C = „zimne miejsce” w dzienniku.";
        if (!txt.contentEquals(info.getText())) info.setText(txt);
    }

    private String fmt(float c) {
        if (Float.isNaN(c)) return "--.-";
        float v = fahrenheit ? c * 9f / 5f + 32f : c;
        String s = String.format(Locale.US, "%.1f", v);
        while (s.replace(".", "").length() < 4) s = " " + s;
        return s;
    }

    final class Gun extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF r = new RectF();
        private final Seg7 seg = new Seg7();
        private final RectF[] btns = {new RectF(), new RectF(), new RectF(), new RectF(), new RectF(), new RectF()};
        private final RectF grip = new RectF();
        private int pressedBtn = -1;

        Gun(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w);
            setMeasuredDimension(W, (int) (W * 1.45f));
        }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), H = getHeight(), u = W / 100f;

            // uchwyt
            path.reset();
            path.moveTo(32 * u, 54 * u);
            path.lineTo(70 * u, 54 * u);
            path.lineTo(66 * u, H - 6 * u);
            path.quadTo(65 * u, H - 2 * u, 60 * u, H - 2 * u);
            path.lineTo(42 * u, H - 2 * u);
            path.quadTo(37 * u, H - 2 * u, 36 * u, H - 6 * u);
            path.close();
            p.setShader(new LinearGradient(32 * u, 0, 70 * u, 0,
                    new int[]{0xFF14162A, 0xFF2C3150, 0xFF14162A}, null, Shader.TileMode.CLAMP));
            c.drawPath(path, p);
            p.setShader(null);
            grip.set(20 * u, 54 * u, 72 * u, H);
            p.setColor(0xFF0E1020);
            for (float y = 64 * u; y < H - 10 * u; y += 3.4f * u)
                c.drawRoundRect(new RectF(40 * u, y, 62 * u, y + 1.4f * u), u, u, p);

            // spust
            path.reset();
            path.moveTo(32 * u, 58 * u);
            path.quadTo(22 * u, 60 * u, 24 * u, 72 * u);
            path.quadTo(28 * u, 70 * u, 33 * u, 72 * u);
            path.close();
            p.setColor(measuring ? 0xFFFFC21A : 0xFFE0A800);
            c.drawPath(path, p);

            // głowica
            r.set(8 * u, 4 * u, 92 * u, 56 * u);
            p.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xFF2E3354, 0xFF111326, Shader.TileMode.CLAMP));
            c.drawRoundRect(r, 8 * u, 8 * u, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.5f * u);
            p.setColor(0xFF3E4470);
            c.drawRoundRect(r, 8 * u, 8 * u, p);
            p.setStyle(Paint.Style.FILL);

            // emiter lasera
            float ex = 16 * u, ey = 11 * u;
            if (measuring && laser) {
                p.setShader(new RadialGradient(ex, ey, 6 * u, 0xAAFF2020, 0x00FF2020, Shader.TileMode.CLAMP));
                c.drawCircle(ex, ey, 6 * u, p);
                p.setShader(null);
            }
            p.setColor(measuring && laser ? 0xFFFF4040 : 0xFF3A1010);
            c.drawCircle(ex, ey, 1.6f * u, p);

            // LCD
            r.set(20 * u, 8 * u, 82 * u, 36 * u);
            p.setColor(0xFF080808);
            c.drawRoundRect(r, 1.5f * u, 1.5f * u, p);
            r.inset(1.2f * u, 1.2f * u);
            int bgTop = !light ? 0xFF56604E : cold && measuring ? 0xFF8FD6FF : 0xFF9BFF6A;
            int bgBot = !light ? 0xFF434B3D : cold && measuring ? 0xFF4FA8E6 : 0xFF5ED23A;
            p.setShader(new LinearGradient(0, r.top, 0, r.bottom, bgTop, bgBot, Shader.TileMode.CLAMP));
            c.drawRect(r, p);
            p.setShader(null);
            int on = 0xFF0B1A08, ghost = 0x180B1A08;
            float dh = r.height() * 0.5f;
            String big = fmt(shown);
            float bx = seg.draw(c, big, r.left + 4 * u, r.top + r.height() * 0.2f, dh, on, ghost);
            p.setColor(on);
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            p.setTextAlign(Paint.Align.LEFT);
            p.setTextSize(dh * 0.38f);
            c.drawText(fahrenheit ? "°F" : "°C", bx + u, r.top + r.height() * 0.2f + dh * 0.4f, p);
            p.setTextSize(r.height() * 0.11f);
            c.drawText(measuring ? "SCAN" : "HOLD", r.left + 2 * u, r.top + r.height() * 0.15f, p);
            if (laser) c.drawText("⚠ LASER", r.left + 12 * u, r.top + r.height() * 0.15f, p);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText("MAX " + fmt(max).trim(), r.right - 2 * u, r.top + r.height() * 0.42f, p);
            c.drawText("MIN " + fmt(min).trim(), r.right - 2 * u, r.top + r.height() * 0.62f, p);
            p.setTextAlign(Paint.Align.LEFT);
            if (cold && measuring) {
                p.setTextSize(r.height() * 0.13f);
                c.drawText("❄ ZIMNO", r.left + 2 * u, r.bottom - r.height() * 0.06f, p);
            }
            p.setColor(0xFF2A3A20);
            p.setTextSize(r.height() * 0.09f);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText(String.format(Locale.US, "ε=%.2f", emis / 100f), r.right - 2 * u, r.bottom - r.height() * 0.06f, p);

            // przyciski: górny rząd żółty / szary / żółty, dolny ▲ ● ▼
            String[] lab = {"°C/°F", "LASER", "LIGHT", "▲", "RESET", "▼"};
            int[] col = {0xFFE8B820, 0xFF8A8FA8, 0xFFE8B820, 0xFF6A6F88, 0xFFD02A24, 0xFF6A6F88};
            for (int i = 0; i < 6; i++) {
                int rr = i / 3, cc = i % 3;
                float bx0 = 24 * u + cc * 19 * u, by0 = 38.5f * u + rr * 7.5f * u;
                if (i == 4) btns[i].set(bx0 + 3 * u, by0 - 0.5f * u, bx0 + 12 * u, by0 + 6.5f * u);
                else btns[i].set(bx0, by0, bx0 + 15 * u, by0 + 5 * u);
                float off = pressedBtn == i ? 0.4f * u : 0;
                float rad = i == 4 ? 4 * u : 2 * u;
                p.setColor(0xFF05060C);
                c.drawRoundRect(new RectF(btns[i].left, btns[i].top + 0.6f * u, btns[i].right, btns[i].bottom + 0.6f * u), rad, rad, p);
                p.setColor(col[i]);
                c.drawRoundRect(new RectF(btns[i].left, btns[i].top + off, btns[i].right, btns[i].bottom + off), rad, rad, p);
                p.setColor(i < 3 ? 0xFF1A1A1A : 0xFFE8E8F0);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(2.3f * u);
                c.drawText(lab[i], btns[i].centerX(), btns[i].centerY() + 0.9f * u + off, p);
            }
            p.setColor(0xFF8088B0);
            p.setTextSize(3.4f * u);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText("IR THERMO", 50 * u, 54 * u, p);
            p.setColor(0xFF555A80);
            p.setTextSize(3 * u);
            c.drawText("trzymaj spust", 51 * u, H - 8 * u, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pressedBtn = -1;
                    for (int i = 0; i < 6; i++) {
                        RectF b = new RectF(btns[i]);
                        b.inset(-getWidth() / 100f, -getWidth() / 100f);
                        if (b.contains(x, y)) pressedBtn = i;
                    }
                    if (pressedBtn < 0 && grip.contains(x, y)) {
                        measuring = true;
                        if (tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 50);
                    } else if (pressedBtn < 0) return false;
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (pressedBtn == 0) fahrenheit = !fahrenheit;
                    else if (pressedBtn == 1) laser = !laser;
                    else if (pressedBtn == 2) light = !light;
                    else if (pressedBtn == 3) emis = Math.min(100, emis + 1);
                    else if (pressedBtn == 5) emis = Math.max(10, emis - 1);
                    else if (pressedBtn == 4) { ref = min = max = shown = Float.NaN; cold = false; }
                    pressedBtn = -1;
                    measuring = false;
                    invalidate();
                    return true;
            }
            return true;
        }
    }
}
