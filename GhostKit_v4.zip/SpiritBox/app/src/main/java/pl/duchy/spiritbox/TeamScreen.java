package pl.duchy.spiritbox;

import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Łączenie telefonów w drużynę. */
final class TeamScreen extends Screen {

    private final TextView state, members;
    private final LinearLayout found;
    private final EditText ipField, nameField;
    private String foundSig = "";

    TeamScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(12), dp(12), dp(12), dp(24));
        sv.addView(root);
        addView(sv);

        root.addView(Ui.text(a, "Twoja nazwa", 13, Ui.DIM, true));
        LinearLayout nr = Ui.row(a);
        nameField = new EditText(a);
        nameField.setText(core.myName);
        nameField.setTextColor(Ui.TEXT);
        nameField.setSingleLine(true);
        Button saveName = Ui.btn(a, "Zapisz");
        saveName.setOnClickListener(v -> {
            core.setName(nameField.getText().toString());
            core.toast("Nazwa: " + core.myName);
        });
        nr.addView(nameField, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        nr.addView(saveName);
        root.addView(nr);

        state = Ui.text(a, "", 15, Ui.TEXT, true);
        state.setPadding(0, dp(16), 0, dp(8));
        root.addView(state);

        LinearLayout r1 = Ui.row(a);
        Button host = Ui.btn(a, "👑 Utwórz drużynę", 0xFF5A1E12, Ui.TEXT);
        host.setOnClickListener(v -> core.net.startHost());
        Button leave = Ui.btn(a, "✖ Rozłącz");
        leave.setOnClickListener(v -> core.net.stop());
        Ui.addWeighted(r1, host);
        Ui.addWeighted(r1, leave);
        root.addView(r1);

        root.addView(section("Drużyny w pobliżu (ta sama sieć Wi-Fi lub hotspot)"));
        found = Ui.col(a);
        root.addView(found);

        root.addView(section("Połącz po adresie IP"));
        LinearLayout ir = Ui.row(a);
        ipField = new EditText(a);
        ipField.setHint("np. 192.168.43.1 lub 100.x.x.x");
        ipField.setTextColor(Ui.TEXT);
        ipField.setHintTextColor(Ui.DIM);
        ipField.setSingleLine(true);
        ipField.setText(core.prefs.getString("last_ip", ""));
        Button conn = Ui.btn(a, "Połącz");
        conn.setOnClickListener(v -> {
            String ip = ipField.getText().toString().trim();
            if (ip.isEmpty()) return;
            core.prefs.edit().putString("last_ip", ip).apply();
            core.net.connect(ip);
        });
        ir.addView(ipField, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        ir.addView(conn);
        root.addView(ir);

        root.addView(section("Członkowie"));
        members = Ui.text(a, "", 14, Ui.TEXT, false);
        root.addView(members);

        root.addView(section("Jak się połączyć"));
        root.addView(Ui.text(a,
                "1) Ta sama sieć Wi-Fi: jedna osoba klika „Utwórz drużynę”, reszta wybiera ją z listy „w pobliżu”.\n\n" +
                "2) Bez Wi-Fi, w terenie: host włącza hotspot w telefonie, pozostali łączą się z tym hotspotem, " +
                "a potem z listy albo po IP hosta (zwykle 192.168.x.1). Działa na kilkadziesiąt metrów i nie zużywa internetu.\n\n" +
                "3) Na duży dystans, przez internet: zainstalujcie wszyscy darmową aplikację Tailscale i zalogujcie się " +
                "do tej samej sieci Tailscale. Host klika „Utwórz drużynę”, a reszta wpisuje jego adres 100.x.x.x z Tailscale " +
                "w polu IP. Działa z dowolnego miejsca (Wi-Fi lub dane komórkowe).\n\n" +
                "Bluetooth nie jest używany – jest za wolny na przesyłanie obrazu z kamery; hotspot działa lepiej i dalej.\n" +
                "Wszystkie telefony muszą mieć otwartą aplikację (ekran włączony).",
                12, Ui.DIM, false));
    }

    private TextView section(String s) {
        TextView t = Ui.text(act, s.toUpperCase(Locale.getDefault()), 12, Ui.ACCENT, true);
        t.setPadding(0, dp(18), 0, dp(6));
        return t;
    }

    @Override
    String title() {
        return "Drużyna";
    }

    @Override
    void onShow() {
        core.net.startDiscovery();
        core.teamUi = this::refresh;
        foundSig = "";
        refresh();
    }

    @Override
    void onHide() {
        core.net.stopDiscovery();
        if (core.teamUi != null) core.teamUi = null;
    }

    @Override
    void tick() {
        // lista hostów w pobliżu
        long now = System.currentTimeMillis();
        List<String> ips = new ArrayList<>();
        StringBuilder sig = new StringBuilder();
        for (Map.Entry<String, Long> e : core.net.foundSeen.entrySet()) {
            if (now - e.getValue() < 5000) {
                ips.add(e.getKey());
                sig.append(e.getKey()).append(core.net.foundName.get(e.getKey()));
            }
        }
        if (!sig.toString().equals(foundSig)) {
            foundSig = sig.toString();
            found.removeAllViews();
            if (ips.isEmpty()) {
                found.addView(Ui.text(act, "Szukam… (nikt nie utworzył drużyny w tej sieci)", 13, Ui.DIM, false));
            }
            for (String ip : ips) {
                Button b = Ui.btn(act, "📡 " + core.net.foundName.get(ip) + "  ·  " + ip);
                b.setOnClickListener(v -> core.net.connect(ip));
                found.addView(b, Ui.matchWrap(act, 3));
            }
        }
        if (now % 1000 < 70) refresh();
    }

    private void refresh() {
        Net n = core.net;
        StringBuilder s = new StringBuilder();
        if (n.role == Net.HOST) {
            s.append("👑 Jesteś hostem drużyny. Inni łączą się do:\n");
            for (String ip : Net.localIps()) s.append("   ").append(ip).append('\n');
        } else if (n.connecting) {
            s.append("Łączenie…");
        } else if (n.isConnected()) {
            s.append("✅ Połączono z hostem ").append(n.hostIp);
        } else {
            s.append("Nie jesteś w drużynie.");
        }
        state.setText(s.toString().trim());

        StringBuilder m = new StringBuilder();
        m.append("• ").append(core.myName).append(" (ty) – ").append(toolName(core.tool)).append('\n');
        for (Core.Member mb : core.members.values()) {
            m.append("• ").append(mb.name).append(" – ").append(toolName(mb.tool));
            m.append(String.format(Locale.US, " · EMF Δ%.1f µT", mb.emf));
            if (!Float.isNaN(mb.temp)) m.append(String.format(Locale.US, " · %.1f °C", mb.temp));
            if (mb.cam) m.append(" · 📹");
            m.append('\n');
        }
        members.setText(m.toString().trim());
    }

    static String toolName(String t) {
        if (t == null) return "?";
        switch (t) {
            case "box": return "Spirit Box";
            case "emf": return "Miernik EMF";
            case "thermo": return "Termometr";
            case "cam": return "Kamera";
            case "view": return "Podgląd kamer";
            case "motion": return "Czujnik ruchu";
            case "music": return "Pozytywka";
            case "book": return "Dziennik";
            case "team": return "Drużyna";
            default: return "Sprzęt";
        }
    }
}
