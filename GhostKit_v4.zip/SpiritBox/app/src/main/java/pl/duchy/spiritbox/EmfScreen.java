package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/** Miernik EMF z pięcioma diodami (odczyt z magnetometru telefonu). */
final class EmfScreen extends Screen {

    static final float[] LEVELS = {1f, 3f, 8f, 20f, 40f}; // ΔµT  (= 10 / 30 / 80 / 200 / 400 mG)
    static final int[] COLORS = {0xFF2EE66B, 0xFF7EE62E, 0xFFFFE12B, 0xFFFF9A1F, 0xFFFF2E2E};

    private final Meter meter;
    private final TextView readout, info;
    private ToneGenerator tone;
    private long lastChirp = 0, lastEvent = 0;

    EmfScreen(MainActivity a) {
        super(a);
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 80); } catch (RuntimeException ignored) { }
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(8), dp(4), dp(8), dp(20));
        sv.addView(root);
        addView(sv);
        meter = new Meter(a);
        root.addView(meter);

        readout = Ui.text(a, "", 22, Ui.TEXT, false);
        readout.setTypeface(Ui.BLACK);
        readout.setGravity(android.view.Gravity.CENTER);
        readout.setPadding(0, dp(8), 0, dp(4));
        root.addView(readout);

        LinearLayout row = Ui.row(a);
        Button cal = Ui.btn(a, "⟲ Kalibruj tło");
        cal.setOnClickListener(v -> {
            core.sensors.calibrate();
            core.toast("Skalibrowano – trzymaj z dala od metalu i elektroniki");
        });
        Ui.addWeighted(row, cal);
        root.addView(row);

        info = Ui.text(a, "", 12, Ui.DIM, false);
        info.setPadding(dp(8), dp(8), dp(8), 0);
        root.addView(info);
    }

    @Override
    String title() {
        return "Miernik EMF";
    }

    @Override
    void tick() {
        Sensors s = core.sensors;
        meter.level = meter.on ? Sensors.level(s.emfDelta, LEVELS) : 0;
        meter.invalidate();
        long now = System.currentTimeMillis();
        if (meter.on && meter.level > 0 && tone != null) {
            long interval = new long[]{0, 700, 450, 280, 160, 90}[meter.level];
            if (now - lastChirp > interval) {
                tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 40);
                lastChirp = now;
            }
        }
        if (meter.on && meter.level >= 5 && now - lastEvent > 10000) {
            lastEvent = now;
            core.alert(String.format(Locale.US, "EMF poziom 5 (%.0f mG)", s.emfDelta * 10f));
        }
        String r = s.mag == null ? "brak magnetometru" :
                meter.on ? String.format(Locale.US, "%.0f mG", s.emfDelta * 10f) : "wyłączony";
        if (!r.contentEquals(readout.getText())) readout.setText(r);
        String t = s.mag == null ? "Ten telefon nie ma magnetometru." :
                String.format(Locale.US, "Dotknij przycisku na mierniku, by go włączyć. Pokazywana jest zmiana pola " +
                        "względem tła (tło: %.0f mG). Kalibruj z dala od metalu, kabli i elektroniki – one też zmieniają odczyt.",
                        s.emfBaseline * 10f);
        if (!t.contentEquals(info.getText())) info.setText(t);
    }

    // ================= rysunek urządzenia =================

    final class Meter extends View {
        boolean on = false;
        int level = 0;
        private boolean pressed = false;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF btn = new RectF();

        Meter(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w);
            setMeasuredDimension(W, (int) (W * 1.75f));
        }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), H = getHeight(), u = W / 100f;
            float cx = W / 2f;
            float hw = 30 * u;          // pół szerokości głowicy
            float top = 4 * u, bot = H - 4 * u;
            float shoulder = top + 95 * u;

            // obudowa: prostokątna głowica zwężająca się w rękojeść
            path.reset();
            path.moveTo(cx - hw + 8 * u, top);
            path.lineTo(cx + hw - 8 * u, top);
            path.quadTo(cx + hw, top, cx + hw, top + 8 * u);
            path.lineTo(cx + hw, shoulder);
            path.lineTo(cx + hw - 8 * u, bot - 8 * u);
            path.quadTo(cx + hw - 9 * u, bot, cx + hw - 17 * u, bot);
            path.lineTo(cx - hw + 17 * u, bot);
            path.quadTo(cx - hw + 9 * u, bot, cx - hw + 8 * u, bot - 8 * u);
            path.lineTo(cx - hw, shoulder);
            path.lineTo(cx - hw, top + 8 * u);
            path.quadTo(cx - hw, top, cx - hw + 8 * u, top);
            path.close();
            p.setShader(new LinearGradient(cx - hw, 0, cx + hw, 0,
                    new int[]{0xFF101010, 0xFF2C2C2C, 0xFF1A1A1A, 0xFF0C0C0C}, null, Shader.TileMode.CLAMP));
            c.drawPath(path, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.5f * u);
            p.setColor(0xFF3A3A3A);
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);

            // diody w rzędzie
            float ledY = top + 7 * u;
            for (int i = 0; i < 5; i++) {
                float lx = cx - 20 * u + i * 10 * u;
                boolean lit = i < level;
                if (lit) {
                    p.setShader(new RadialGradient(lx, ledY, 9 * u, (COLORS[i] & 0x00FFFFFF) | 0xAA000000,
                            COLORS[i] & 0x00FFFFFF, Shader.TileMode.CLAMP));
                    c.drawCircle(lx, ledY, 9 * u, p);
                    p.setShader(null);
                }
                p.setColor(0xFF050505);
                c.drawCircle(lx, ledY, 3.6f * u, p);
                p.setShader(new RadialGradient(lx - 1.1f * u, ledY - 1.1f * u, 3.2f * u,
                        lit ? 0xFFFFFFFF : dim(COLORS[i], 0.55f), lit ? COLORS[i] : dim(COLORS[i], 0.25f),
                        Shader.TileMode.CLAMP));
                c.drawCircle(lx, ledY, 3f * u, p);
                p.setShader(null);
            }

            // biała płytka z wachlarzem kolorów
            RectF plate = new RectF(cx - hw + 3 * u, top + 13 * u, cx + hw - 3 * u, top + 46 * u);
            p.setColor(0xFFF2F2F0);
            c.drawRect(plate, p);
            float fx = cx, fy = plate.bottom + 40 * u, rIn = 56 * u, rOut = 72 * u;
            c.save();
            c.clipRect(plate.left, plate.top, plate.right, plate.bottom);
            float startDeg = -112f, span = 44f / 5f;
            for (int i = 0; i < 5; i++) {
                p.setColor(COLORS[i]);
                path.reset();
                RectF outer = new RectF(fx - rOut, fy - rOut, fx + rOut, fy + rOut);
                RectF inner = new RectF(fx - rIn, fy - rIn, fx + rIn, fy + rIn);
                path.arcTo(outer, startDeg + i * span, span);
                path.arcTo(inner, startDeg + (i + 1) * span, -span);
                path.close();
                c.drawPath(path, p);
            }
            c.restore();
            p.setColor(0xFF1A1A1A);
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(3.2f * u);
            String[] lbl = {"10", "30", "80", "200", "400+"};
            for (int i = 0; i < 5; i++) {
                double ang = Math.toRadians(startDeg + (i + 0.5f) * span);
                float lr = rIn - 4f * u;
                c.drawText(lbl[i], fx + (float) Math.cos(ang) * lr, fy + (float) Math.sin(ang) * lr + u, p);
            }
            p.setTextSize(3f * u);
            c.drawText("milli GAUSS (mG)", cx, plate.bottom - 2.2f * u, p);

            // przycisk z jodełką
            btn.set(cx - 14 * u, top + 56 * u, cx + 14 * u, top + 88 * u);
            p.setColor(0xFF060606);
            c.drawRoundRect(btn, 3 * u, 3 * u, p);
            RectF inner = new RectF(btn);
            inner.inset(1.4f * u, 1.4f * u);
            if (pressed) inner.offset(0, 0.5f * u);
            p.setShader(new LinearGradient(0, inner.top, 0, inner.bottom,
                    pressed ? 0xFF181818 : 0xFF2A2A2A, 0xFF121212, Shader.TileMode.CLAMP));
            c.drawRoundRect(inner, 2.5f * u, 2.5f * u, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.2f * u);
            p.setColor(on ? 0xFF4A4A4A : 0xFF3A3A3A);
            for (int k = 0; k < 4; k++) {
                float y = inner.top + 7 * u + k * 6 * u;
                float wdt = 9 * u - k * 1.6f * u;
                c.drawLine(cx - wdt, y + 3 * u, cx, y, p);
                c.drawLine(cx, y, cx + wdt, y + 3 * u, p);
            }
            p.setStyle(Paint.Style.FILL);

            // dioda zasilania obok przycisku
            p.setColor(on ? 0xFF3DDC97 : 0xFF0F2A1C);
            c.drawCircle(cx + 20 * u, btn.top + 4 * u, 1.3f * u, p);

            // faktura rękojeści
            p.setColor(0xFF161616);
            for (float y = shoulder + 6 * u; y < bot - 14 * u; y += 3.4f * u) {
                c.drawRoundRect(new RectF(cx - 15 * u, y, cx + 15 * u, y + 1.4f * u), u, u, p);
            }
        }

        private int dim(int col, float f) {
            int r0 = (int) (((col >> 16) & 255) * f), g0 = (int) (((col >> 8) & 255) * f), b0 = (int) ((col & 255) * f);
            return 0xFF000000 | (r0 << 16) | (g0 << 8) | b0;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            boolean inBtn = e.getX() > btn.left - 20 && e.getX() < btn.right + 20
                    && e.getY() > btn.top - 20 && e.getY() < btn.bottom + 20;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (!inBtn) return false;
                    pressed = true;
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                    if (pressed) on = !on;
                    pressed = false;
                    invalidate();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    pressed = false;
                    invalidate();
                    return true;
            }
            return true;
        }
    }
}
