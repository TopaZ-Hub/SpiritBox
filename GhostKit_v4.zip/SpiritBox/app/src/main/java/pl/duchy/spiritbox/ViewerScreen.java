package pl.duchy.spiritbox;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.HandlerThread;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Podgląd kamery innego członka drużyny: obraz + dźwięk na żywo, zdalne sterowanie, zapis u siebie. */
final class ViewerScreen extends Screen implements Core.FrameSink, Core.AudioSink {

    private final FeedView feed;
    private final CamFrame frame;
    private final LinearLayout camList;
    private final TextView hint;
    private final Button flashBtn, modeBtn, motionBtn, recBtn, soundBtn, zoomLbl;
    private String selected = null, selName = "";
    private volatile boolean rFlash, rMotion = true;
    private volatile int rMode = 0, rZoom = 0, rZmax = 0;
    private volatile String rZtext = "1.0×";
    private boolean sound = true;
    private VideoRecorder recorder;
    private HandlerThread worker, audioWorker;
    private Handler wh, ah;
    private AudioTrack track;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private String listSig = "";
    private long lastSub = 0, lastCmd = 0;

    ViewerScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(8), dp(4), dp(8), dp(20));
        sv.addView(root);
        addView(sv);

        HorizontalScrollView hs = new HorizontalScrollView(a);
        camList = Ui.row(a);
        hs.addView(camList);
        root.addView(hs);

        feed = new FeedView(a);
        frame = new CamFrame(a, feed);
        root.addView(frame);

        LinearLayout r1 = Ui.row(a);
        flashBtn = Ui.btn(a, "");
        flashBtn.setOnClickListener(v -> cmd("flash", !rFlash, 0));
        modeBtn = Ui.btn(a, "");
        modeBtn.setOnClickListener(v -> cmd("mode", false, (rMode + 1) % 3));
        motionBtn = Ui.btn(a, "");
        motionBtn.setOnClickListener(v -> cmd("motion", !rMotion, 0));
        Ui.addWeighted(r1, flashBtn);
        Ui.addWeighted(r1, modeBtn);
        Ui.addWeighted(r1, motionBtn);
        root.addView(r1);

        LinearLayout r2 = Ui.row(a);
        Button zm = Ui.btn(a, "−");
        zm.setTextSize(22);
        zm.setOnClickListener(v -> cmd("zoom", false, Math.max(0, rZoom - Math.max(1, rZmax / 10))));
        zoomLbl = Ui.btn(a, "1.0×");
        zoomLbl.setOnClickListener(v -> cmd("zoom", false, 0));
        Button zp = Ui.btn(a, "+");
        zp.setTextSize(22);
        zp.setOnClickListener(v -> cmd("zoom", false, Math.min(rZmax, rZoom + Math.max(1, rZmax / 10))));
        Ui.addWeighted(r2, zm);
        Ui.addWeighted(r2, zoomLbl);
        Ui.addWeighted(r2, zp);
        root.addView(r2);

        LinearLayout r3 = Ui.row(a);
        Button photo = Ui.btn(a, "📸 Zdjęcie");
        photo.setOnClickListener(v -> {
            if (selected == null) return;
            Gallery.photo(core, act, feed, "Zdjęcie z kamery: " + selName + " (zapisał " + core.myName + ")");
        });
        recBtn = Ui.btn(a, "");
        recBtn.setOnClickListener(v -> toggleRec());
        soundBtn = Ui.btn(a, "");
        soundBtn.setOnClickListener(v -> { sound = !sound; refreshButtons(); });
        Ui.addWeighted(r3, photo);
        Ui.addWeighted(r3, recBtn);
        Ui.addWeighted(r3, soundBtn);
        root.addView(r3);

        hint = Ui.text(a, "", 12, Ui.DIM, false);
        hint.setPadding(dp(8), dp(8), dp(8), 0);
        root.addView(hint);
        refreshButtons();
    }

    @Override
    String title() {
        return "Podgląd kamer";
    }

    @Override
    void onShow() {
        core.frameSink = this;
        core.audioSink = this;
        if (worker == null) {
            worker = new HandlerThread("view-worker");
            worker.start();
            wh = new Handler(worker.getLooper());
        }
        if (audioWorker == null) {
            audioWorker = new HandlerThread("view-audio");
            audioWorker.start();
            ah = new Handler(audioWorker.getLooper());
            ah.post(this::openTrack);
        }
        if (selected != null) core.net.subscribe(selected, true);
        listSig = "";
    }

    @Override
    void onHide() {
        if (core.frameSink == this) core.frameSink = null;
        if (core.audioSink == this) core.audioSink = null;
        if (selected != null) core.net.subscribe(selected, false);
        if (recorder != null) toggleRec();
        if (worker != null) {
            worker.quitSafely();
            worker = null;
            wh = null;
        }
        if (audioWorker != null) {
            final AudioTrack t = track;
            track = null;
            Handler h = ah;
            h.post(() -> {
                if (t != null) {
                    try { t.stop(); } catch (Exception ignored) { }
                    t.release();
                }
            });
            audioWorker.quitSafely();
            audioWorker = null;
            ah = null;
        }
    }

    private void openTrack() {
        try {
            int sr = VideoRecorder.AUDIO_RATE;
            int minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(sr)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(minBuf * 4, sr))
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
            track.play();
        } catch (Exception e) {
            track = null;
        }
    }

    @Override
    void tick() {
        long now = System.currentTimeMillis();
        if (selected != null && now - lastSub > 2000) {
            lastSub = now;
            core.net.subscribe(selected, true);
        }
        List<Core.Member> cams = core.cameras();
        StringBuilder sig = new StringBuilder();
        for (Core.Member m : cams) sig.append(m.id).append(m.name).append(';');
        String s = sig.toString() + core.net.isConnected() + selected;
        if (!s.equals(listSig)) {
            listSig = s;
            camList.removeAllViews();
            for (Core.Member m : cams) {
                Button b = Ui.btn(act, "📹 " + m.name, m.id.equals(selected) ? 0xFF4A2E9A : Ui.CARD2, Ui.TEXT);
                b.setOnClickListener(v -> select(m.id, m.name));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(dp(4), dp(4), dp(4), dp(8));
                camList.addView(b, lp);
            }
            String h;
            if (!core.net.isConnected()) h = "Nie jesteś w drużynie. Wejdź w „Drużyna” i połącz telefony.";
            else if (cams.isEmpty()) h = "Nikt nie ma włączonej kamery. Na innym telefonie otwórz „Kamera”.";
            else h = "Wybierz kamerę powyżej. Latarka, tryb (Normalny / Noc / NV), zoom i ruch sterują kamerą zdalnie. " +
                        "Zdjęcia i nagrania (z dźwiękiem) zapisują się u ciebie, w galerii i we wspólnym dzienniku.";
            hint.setText(h);
            if (selected != null && core.members.get(selected) == null) {
                feed.frame = null;
                feed.invalidate();
            }
        }
        refreshButtons();
    }

    private void select(String id, String name) {
        if (id.equals(selected)) return;
        if (recorder != null) toggleRec();
        if (selected != null) core.net.subscribe(selected, false);
        selected = id;
        selName = name;
        feed.frame = null;
        feed.label = name;
        feed.invalidate();
        core.net.subscribe(id, true);
        lastSub = System.currentTimeMillis();
        listSig = "";
    }

    private void cmd(String c, boolean v, int n) {
        if (selected == null) {
            core.toast("Najpierw wybierz kamerę");
            return;
        }
        core.sendCmd(selected, c, v, n);
        lastCmd = System.currentTimeMillis();
        switch (c) {
            case "flash": rFlash = v; break;
            case "mode": rMode = n; break;
            case "motion": rMotion = v; break;
            case "zoom": rZoom = n; break;
        }
        refreshButtons();
    }

    private void setText(Button b, String t, int color) {
        if (!t.contentEquals(b.getText())) {
            b.setText(t);
            Ui.color(b, color);
        }
    }

    private void refreshButtons() {
        setText(flashBtn, rFlash ? "🔦 Latarka WŁ" : "🔦 Latarka", rFlash ? 0xFF6A5214 : Ui.CARD2);
        setText(modeBtn, rMode == 0 ? "🌙 Normalny" : rMode == 1 ? "🌙 Noc" : "🟢 NV",
                rMode == 0 ? Ui.CARD2 : rMode == 1 ? 0xFF2A2A6A : 0xFF14502A);
        setText(motionBtn, rMotion ? "👁 Ruch: WŁ" : "👁 Ruch: WYŁ", rMotion ? 0xFF1E3A5A : Ui.CARD2);
        setText(recBtn, recorder != null ? "■ Stop" : "⏺ Nagrywaj", recorder != null ? 0xFF7A1A14 : Ui.CARD2);
        setText(soundBtn, sound ? "🔊 Dźwięk" : "🔇 Cisza", sound ? 0xFF3A1E5A : Ui.CARD2);
        setText(zoomLbl, rZmax > 0 ? rZtext : "zoom –", Ui.CARD2);
    }

    // ================= dane z sieci =================

    @Override
    public void onFrame(Net.Msg m) {
        if (selected == null || !selected.equals(m.j.optString("from")) || m.bin == null) return;
        Handler h = wh;
        if (h == null || !busy.compareAndSet(false, true)) return;
        h.post(() -> {
            try {
                Bitmap b = BitmapFactory.decodeByteArray(m.bin, 0, m.bin.length);
                if (b == null) return;
                // po wysłaniu polecenia chwilę ufamy własnemu stanowi przycisków
                if (System.currentTimeMillis() - lastCmd > 1500) {
                    rFlash = m.j.optBoolean("flash");
                    rMode = m.j.optInt("mode", 0);
                    rMotion = m.j.optBoolean("motion", true);
                    rZoom = m.j.optInt("zoom", 0);
                }
                rZmax = m.j.optInt("zmax", 0);
                rZtext = m.j.optString("ztext", "1.0×");
                int mode = m.j.optInt("mode", 0);
                feed.rot = m.j.optInt("rot", 90);
                feed.mirror = m.j.optBoolean("mirror");
                feed.nv = mode == 2;
                feed.night = mode == 1;
                feed.flash = m.j.optBoolean("flash");
                feed.motionOn = m.j.optBoolean("motion", true);
                feed.mic = m.j.optBoolean("mic");
                feed.zoomText = m.j.optInt("zoom", 0) > 0 ? rZtext : "";
                feed.label = m.j.optString("name", selName);
                if (m.j.optBoolean("alert")) feed.motionUntil = System.currentTimeMillis() + 1500;
                feed.setFrame(b, m.j.optLong("ts", System.currentTimeMillis()));
                VideoRecorder r = recorder;
                if (r != null) r.addFrame(feed.compose(feed.outW(), feed.outH()));
            } catch (Exception ignored) {
            } finally {
                busy.set(false);
            }
        });
    }

    @Override
    public void onAudio(Net.Msg m) {
        if (selected == null || !selected.equals(m.j.optString("from")) || m.bin == null) return;
        Handler h = ah;
        if (h == null) return;
        final byte[] data = m.bin;
        h.post(() -> {
            int n = data.length / 2;
            short[] pcm = new short[n];
            ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(pcm);
            VideoRecorder r = recorder;
            if (r != null) r.addAudio(pcm, n, System.nanoTime() / 1000 - n * 1_000_000L / VideoRecorder.AUDIO_RATE);
            AudioTrack t = track;
            if (sound && t != null) t.write(pcm, 0, n);
        });
    }

    private void toggleRec() {
        if (recorder != null) {
            final VideoRecorder r = recorder;
            recorder = null;
            feed.rec = false;
            r.stop(ok -> Gallery.finishVideo(core, act, r.file, ok,
                    "Nagranie z kamery: " + selName + " (zapisał " + core.myName + ")"));
        } else {
            if (selected == null || feed.frame == null) {
                core.toast("Brak obrazu");
                return;
            }
            File f = new File(act.getCacheDir(), "View_" + Ui.fileStamp() + ".mp4");
            recorder = new VideoRecorder(f, feed.outW(), feed.outH(), true);
            feed.rec = true;
            frame.invalidate();
        }
        refreshButtons();
    }
}
