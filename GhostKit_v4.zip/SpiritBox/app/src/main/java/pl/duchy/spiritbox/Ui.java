package pl.duchy.spiritbox;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Styl aplikacji (ciemny, zaokrąglony, nowoczesny) i drobne pomocniki. */
final class Ui {
    static final int BG = 0xFF07080C;
    static final int CARD = 0xFF12141B;
    static final int CARD2 = 0xFF1A1D27;
    static final int STROKE = 0x1FFFFFFF;
    static final int TEXT = 0xFFF2F3F7;
    static final int DIM = 0xFF8B90A0;
    static final int ACCENT = 0xFF8B6CFF;
    static final int ACCENT2 = 0xFF2EE6C5;
    static final int RED = 0xFFFF4D5E;
    static final int GREEN = 0xFF3DDC97;
    static final int AMBER = 0xFFFFB547;

    static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    static final Typeface BLACK = Typeface.create("sans-serif-black", Typeface.NORMAL);

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(MEDIUM);
        return t;
    }

    static Button btn(Context c, String s) {
        return btn(c, s, CARD2, TEXT);
    }

    static Button btn(Context c, String s, int bg, int fg) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(14);
        b.setTypeface(MEDIUM);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c, 50));
        b.setPadding(dp(c, 10), dp(c, 6), dp(c, 10), dp(c, 6));
        b.setStateListAnimator(null);
        color(b, bg);
        return b;
    }

    /** Tło przycisku: zaokrąglona "pigułka" z efektem dotyku. */
    static void color(View b, int bg) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(b.getContext(), 16));
        g.setStroke(dp(b.getContext(), 1), STROKE);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), g, null));
    }

    /** Karta z delikatnym gradientem. */
    static void card(View v, int radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{CARD2, CARD});
        g.setCornerRadius(dp(v.getContext(), radiusDp));
        g.setStroke(dp(v.getContext(), 1), STROKE);
        v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22FFFFFF), g, null));
    }

    /** Okrągła plakietka z ikoną w kolorze narzędzia. */
    static TextView badge(Context c, String icon, int color, int sizeDp) {
        TextView t = new TextView(c);
        t.setText(icon);
        t.setTextSize(sizeDp * 0.42f);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor((color & 0x00FFFFFF) | 0x2E000000);
        g.setStroke(dp(c, 1), (color & 0x00FFFFFF) | 0x66000000);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        return t;
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static void addWeighted(LinearLayout row, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        int m = dp(row.getContext(), 4);
        lp.setMargins(m, m, m, m);
        row.addView(v, lp);
    }

    static LinearLayout.LayoutParams matchWrap(Context c, int marginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        int m = dp(c, marginDp);
        lp.setMargins(m, m, m, m);
        return lp;
    }

    static TextView section(Context c, String s) {
        TextView t = text(c, s.toUpperCase(Locale.getDefault()), 12, DIM, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(dp(c, 6), dp(c, 18), 0, dp(c, 8));
        return t;
    }

    static String stamp(long ts) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date(ts));
    }

    static String time(long ts) {
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(ts));
    }

    static String fileStamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }
}
