package pl.duchy.spiritbox;

import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.HandlerThread;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Kamera tego telefonu. Tryby: normalny, NOC (rozjaśniony kolor) i NV (zielona noktowizja).
 * W trybach nocnych kamera wydłuża naświetlanie, a obraz jest programowo wzmacniany i odszumiany.
 * Obraz i dźwięk idą do drużyny, która może zdalnie sterować latarką, trybem i zoomem.
 */
@SuppressWarnings("deprecation")
final class CamScreen extends Screen implements Camera.PreviewCallback, Core.CmdSink {

    static final String[] MODE_NAMES = {"Normalny", "Noc", "Noktowizja"};

    private final FeedView feed;
    private final CamFrame frame;
    private final Button flashBtn, modeBtn, motionBtn, recBtn, micBtn, zoomLbl;
    private Camera cam;
    private SurfaceTexture st;
    private int camId = 0, pw, ph;
    private boolean flash = false, motionOn = true, micOn = true;
    private volatile int mode = 0;
    private int zoom = 0, maxZoom = 0;
    private List<Integer> zoomRatios;
    private int[] defaultFps;
    private VideoRecorder recorder;
    private HandlerThread worker;
    private Handler wh;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private long lastSend = 0, lastMotion = 0, ignoreMotionUntil = 0;
    private byte[] prevY;
    private int[] acc;
    private static final byte[] LUT_NIGHT = lut(0.55, 1.15), LUT_NV = lut(0.42, 1.35);

    private volatile boolean audioRun = false;
    private Thread audioThread;

    CamScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(8), dp(4), dp(8), dp(20));
        sv.addView(root);
        addView(sv);

        feed = new FeedView(a);
        frame = new CamFrame(a, feed);
        root.addView(frame);

        LinearLayout r1 = Ui.row(a);
        flashBtn = Ui.btn(a, "");
        flashBtn.setOnClickListener(v -> { flash = !flash; applyParams(); });
        modeBtn = Ui.btn(a, "");
        modeBtn.setOnClickListener(v -> { mode = (mode + 1) % 3; applyParams(); });
        Button sw = Ui.btn(a, "🔄 Obróć");
        sw.setOnClickListener(v -> switchCam());
        Ui.addWeighted(r1, flashBtn);
        Ui.addWeighted(r1, modeBtn);
        Ui.addWeighted(r1, sw);
        root.addView(r1);

        LinearLayout r2 = Ui.row(a);
        Button zm = Ui.btn(a, "−");
        zm.setTextSize(22);
        zm.setOnClickListener(v -> setZoom(zoom - zoomStep()));
        zoomLbl = Ui.btn(a, "1.0×");
        zoomLbl.setOnClickListener(v -> setZoom(0));
        Button zp = Ui.btn(a, "+");
        zp.setTextSize(22);
        zp.setOnClickListener(v -> setZoom(zoom + zoomStep()));
        Ui.addWeighted(r2, zm);
        Ui.addWeighted(r2, zoomLbl);
        Ui.addWeighted(r2, zp);
        root.addView(r2);

        LinearLayout r3 = Ui.row(a);
        Button photo = Ui.btn(a, "📸 Zdjęcie");
        photo.setOnClickListener(v -> Gallery.photo(core, act, feed, "Zdjęcie z kamery (" + core.myName + ")"));
        recBtn = Ui.btn(a, "");
        recBtn.setOnClickListener(v -> toggleRec());
        Ui.addWeighted(r3, photo);
        Ui.addWeighted(r3, recBtn);
        root.addView(r3);

        LinearLayout r4 = Ui.row(a);
        micBtn = Ui.btn(a, "");
        micBtn.setOnClickListener(v -> { micOn = !micOn; refreshButtons(); });
        motionBtn = Ui.btn(a, "");
        motionBtn.setOnClickListener(v -> { motionOn = !motionOn; applyParams(); });
        Ui.addWeighted(r4, micBtn);
        Ui.addWeighted(r4, motionBtn);
        root.addView(r4);

        TextView info = Ui.text(a, "Noc – kamera dłużej naświetla, a obraz jest rozjaśniany i odszumiany (w kolorze). " +
                "Noktowizja – to samo mocniej, w zieleni. Telefon nie ma promiennika podczerwieni, więc w zupełnej " +
                "ciemności pomoże latarka.\nDrużyna widzi tę kamerę w „Podglądzie kamer”, słyszy dźwięk i może zdalnie " +
                "sterować latarką, trybem, zoomem i wykrywaniem ruchu. Zostaw ten ekran otwarty.", 12, Ui.DIM, false);
        info.setPadding(dp(8), dp(8), dp(8), 0);
        root.addView(info);
        refreshButtons();
    }

    private static byte[] lut(double gamma, double gain) {
        byte[] l = new byte[4096];
        for (int i = 0; i < 4096; i++) {
            double v = Math.pow(i / 4095.0, gamma) * gain * 255.0;
            l[i] = (byte) Math.max(0, Math.min(255, (int) v));
        }
        return l;
    }

    @Override
    String title() {
        return "Kamera";
    }

    @Override
    void onShow() {
        core.camActive = true;
        core.cmdSink = this;
        if (worker == null) {
            worker = new HandlerThread("cam-worker");
            worker.start();
            wh = new Handler(worker.getLooper());
        }
        act.withPermission(Manifest.permission.CAMERA, () -> {
            openCam();
            act.withPermission(Manifest.permission.RECORD_AUDIO, this::startAudio);
        });
    }

    @Override
    void onHide() {
        core.camActive = false;
        if (core.cmdSink == this) core.cmdSink = null;
        if (recorder != null) toggleRec();
        stopAudio();
        closeCam();
        if (worker != null) {
            worker.quitSafely();
            worker = null;
            wh = null;
        }
    }

    // ================= kamera =================

    private void openCam() {
        if (cam != null || !core.camActive) return;
        try {
            cam = Camera.open(camId);
            Camera.Parameters p = cam.getParameters();
            Camera.Size best = null;
            for (Camera.Size s : p.getSupportedPreviewSizes()) {
                if (s.width > 800) continue;
                if (best == null || Math.abs(s.width * s.height - 640 * 480) < Math.abs(best.width * best.height - 640 * 480))
                    best = s;
            }
            if (best != null) p.setPreviewSize(best.width, best.height);
            p.setPreviewFormat(ImageFormat.NV21);
            List<String> fm = p.getSupportedFocusModes();
            if (fm != null && fm.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO))
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            cam.setParameters(p);
            p = cam.getParameters();
            Camera.Size s = p.getPreviewSize();
            pw = s.width;
            ph = s.height;
            defaultFps = new int[2];
            p.getPreviewFpsRange(defaultFps);
            maxZoom = p.isZoomSupported() ? p.getMaxZoom() : 0;
            zoomRatios = p.isZoomSupported() ? p.getZoomRatios() : null;
            zoom = Math.min(zoom, maxZoom);
            st = new SurfaceTexture(10);
            cam.setPreviewTexture(st);
            int size = pw * ph * ImageFormat.getBitsPerPixel(ImageFormat.NV21) / 8;
            for (int i = 0; i < 3; i++) cam.addCallbackBuffer(new byte[size]);
            cam.setPreviewCallbackWithBuffer(this);
            cam.startPreview();
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(camId, info);
            feed.rot = info.orientation;
            feed.mirror = info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT;
            feed.label = core.myName + " · CAM " + (camId + 1);
            prevY = null;
            acc = null;
            applyParams();
        } catch (Exception e) {
            closeCam();
            core.toast("Nie udało się uruchomić kamery");
        }
    }

    private void closeCam() {
        if (cam != null) {
            try {
                cam.setPreviewCallbackWithBuffer(null);
                cam.stopPreview();
            } catch (Exception ignored) { }
            cam.release();
            cam = null;
        }
        if (st != null) {
            st.release();
            st = null;
        }
    }

    private void switchCam() {
        int n = Camera.getNumberOfCameras();
        if (n < 2) return;
        if (recorder != null) toggleRec();
        closeCam();
        camId = (camId + 1) % n;
        flash = false;
        zoom = 0;
        openCam();
    }

    private int zoomStep() {
        return Math.max(1, maxZoom / 10);
    }

    private void setZoom(int z) {
        zoom = Math.max(0, Math.min(maxZoom, z));
        applyParams();
    }

    private String zoomText() {
        if (zoomRatios == null || zoom >= zoomRatios.size()) return "1.0×";
        return String.format(Locale.US, "%.1f×", zoomRatios.get(zoom) / 100f);
    }

    private void applyParams() {
        if (cam != null) {
            boolean dark = mode > 0;
            try {
                Camera.Parameters p = cam.getParameters();
                List<String> fl = p.getSupportedFlashModes();
                if (fl != null && fl.contains(Camera.Parameters.FLASH_MODE_TORCH))
                    p.setFlashMode(flash ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
                p.setExposureCompensation(dark ? p.getMaxExposureCompensation() : 0);
                if (p.isZoomSupported()) p.setZoom(zoom);
                cam.setParameters(p);
            } catch (Exception ignored) { }
            // dłuższe naświetlanie: najniższy dostępny zakres FPS i tryb sceny "noc" (jeśli telefon pozwala)
            try {
                Camera.Parameters p = cam.getParameters();
                int[] fps = defaultFps;
                if (dark) {
                    for (int[] r : p.getSupportedPreviewFpsRange()) {
                        if (fps == null || r[0] < fps[0] || (r[0] == fps[0] && r[1] > fps[1])) fps = r;
                    }
                }
                if (fps != null) p.setPreviewFpsRange(fps[0], fps[1]);
                cam.setParameters(p);
            } catch (Exception ignored) { }
            try {
                Camera.Parameters p = cam.getParameters();
                List<String> sm = p.getSupportedSceneModes();
                if (sm != null && sm.contains(Camera.Parameters.SCENE_MODE_NIGHT))
                    p.setSceneMode(dark ? Camera.Parameters.SCENE_MODE_NIGHT : Camera.Parameters.SCENE_MODE_AUTO);
                cam.setParameters(p);
            } catch (Exception ignored) { }
        }
        feed.nv = mode == 2;
        feed.night = mode == 1;
        feed.flash = flash;
        feed.motionOn = motionOn;
        feed.zoomText = zoom > 0 ? zoomText() : "";
        acc = null;
        ignoreMotionUntil = System.currentTimeMillis() + 2500;
        refreshButtons();
    }

    private void refreshButtons() {
        flashBtn.setText(flash ? "🔦 Latarka WŁ" : "🔦 Latarka");
        Ui.color(flashBtn, flash ? 0xFF6A5214 : Ui.CARD2);
        modeBtn.setText(mode == 0 ? "🌙 Normalny" : mode == 1 ? "🌙 Noc" : "🟢 NV");
        Ui.color(modeBtn, mode == 0 ? Ui.CARD2 : mode == 1 ? 0xFF2A2A6A : 0xFF14502A);
        motionBtn.setText(motionOn ? "👁 Ruch: WŁ" : "👁 Ruch: WYŁ");
        Ui.color(motionBtn, motionOn ? 0xFF1E3A5A : Ui.CARD2);
        recBtn.setText(recorder != null ? "■ Stop" : "⏺ Nagrywaj");
        Ui.color(recBtn, recorder != null ? 0xFF7A1A14 : Ui.CARD2);
        micBtn.setText(micOn ? "🎙 Dźwięk: WŁ" : "🎙 Dźwięk: WYŁ");
        Ui.color(micBtn, micOn ? 0xFF3A1E5A : Ui.CARD2);
        zoomLbl.setText(zoomText());
        feed.mic = micOn && audioRun;
    }

    @Override
    public void onCmd(String c, boolean v, int n, String fromName) {
        String what;
        switch (c) {
            case "flash": flash = v; what = v ? "włączył latarkę" : "wyłączył latarkę"; break;
            case "mode": mode = Math.max(0, Math.min(2, n)); what = "ustawił tryb: " + MODE_NAMES[mode]; break;
            case "motion": motionOn = v; what = v ? "włączył wykrywanie ruchu" : "wyłączył wykrywanie ruchu"; break;
            case "zoom": zoom = Math.max(0, Math.min(maxZoom, n)); what = null; break;
            default: return;
        }
        applyParams();
        if (what != null) core.toast(fromName + " " + what);
    }

    // ================= obraz =================

    @Override
    public void onPreviewFrame(byte[] data, Camera c) {
        Handler h = wh;
        if (h != null && busy.compareAndSet(false, true)) {
            final byte[] copy = data.clone();
            final int w = pw, hh = ph;
            h.post(() -> process(copy, w, hh));
        }
        c.addCallbackBuffer(data);
    }

    private void process(byte[] d, int w, int h) {
        try {
            long now = System.currentTimeMillis();
            if (motionOn) detectMotion(d, w, h, now);
            if (mode > 0) enhance(d, w, h);
            YuvImage yi = new YuvImage(d, ImageFormat.NV21, w, h, null);
            ByteArrayOutputStream bo = new ByteArrayOutputStream(65536);
            yi.compressToJpeg(new Rect(0, 0, w, h), 65, bo);
            byte[] jpg = bo.toByteArray();
            if (core.net.isConnected() && now - core.lastWatched < 6000 && now - lastSend > 110) {
                lastSend = now;
                core.net.send(frameMsg(jpg, now));
            }
            Bitmap bm = BitmapFactory.decodeByteArray(jpg, 0, jpg.length);
            if (bm != null) {
                feed.setFrame(bm, now);
                VideoRecorder r = recorder;
                if (r != null) r.addFrame(feed.compose(feed.outW(), feed.outH()));
            }
        } catch (Exception ignored) {
        } finally {
            busy.set(false);
        }
    }

    /** Rozjaśnianie (krzywa gamma + wzmocnienie) i odszumianie w czasie (uśrednianie klatek). */
    private void enhance(byte[] d, int w, int h) {
        int n = w * h;
        int[] a = acc;
        boolean nv = mode == 2;
        if (a == null || a.length != n) {
            a = new int[n];
            for (int i = 0; i < n; i++) a[i] = (d[i] & 255) << 4;
            acc = a;
        }
        byte[] lut = nv ? LUT_NV : LUT_NIGHT;
        for (int i = 0; i < n; i++) {
            int y = (d[i] & 255) << 4;
            int v = nv ? (a[i] * 2 + y) / 3 : (a[i] + y) >> 1;
            a[i] = v;
            d[i] = lut[Math.min(4095, v)];
        }
        if (nv) {
            for (int i = n; i < d.length; i++) d[i] = (byte) 128;
        }
    }

    private Net.Msg frameMsg(byte[] jpg, long now) {
        JSONObject o = Net.Msg.obj("frame");
        try {
            o.put("from", core.myId);
            o.put("name", core.myName);
            o.put("ts", now);
            o.put("rot", feed.rot);
            o.put("mirror", feed.mirror);
            o.put("mode", mode);
            o.put("flash", flash);
            o.put("motion", motionOn);
            o.put("alert", now < feed.motionUntil);
            o.put("zoom", zoom);
            o.put("zmax", maxZoom);
            o.put("ztext", zoomText());
            o.put("mic", micOn && audioRun);
        } catch (JSONException ignored) { }
        return new Net.Msg(o, jpg);
    }

    private void detectMotion(byte[] d, int w, int h, long now) {
        int step = 16, cols = w / step, rows = h / step;
        byte[] cur = new byte[cols * rows];
        for (int y = 0; y < rows; y++)
            for (int x = 0; x < cols; x++) cur[y * cols + x] = d[(y * step) * w + x * step];
        byte[] prev = prevY;
        prevY = cur;
        if (prev == null || prev.length != cur.length) return;
        long diff = 0;
        for (int i = 0; i < cur.length; i++) diff += Math.abs((cur[i] & 255) - (prev[i] & 255));
        float mean = diff / (float) cur.length;
        if (mean > 14f && now > ignoreMotionUntil && now - lastMotion > 5000) {
            lastMotion = now;
            feed.motionUntil = now + 2000;
            core.main.post(() -> core.alert("Kamera (" + core.myName + "): wykryto ruch"));
        }
    }

    // ================= dźwięk =================

    private void startAudio() {
        if (audioRun || !core.camActive) return;
        audioRun = true;
        audioThread = new Thread(this::audioLoop, "cam-audio");
        audioThread.start();
        core.main.post(this::refreshButtons);
    }

    private void stopAudio() {
        audioRun = false;
        if (audioThread != null) {
            try { audioThread.join(600); } catch (InterruptedException ignored) { }
            audioThread = null;
        }
    }

    private void audioLoop() {
        final int sr = VideoRecorder.AUDIO_RATE;
        AudioRecord rec = null;
        try {
            int minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            rec = new AudioRecord(MediaRecorder.AudioSource.CAMCORDER, sr, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, sr));
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                rec.release();
                rec = new AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, sr));
            }
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) return;
            rec.startRecording();
            short[] buf = new short[sr / 10];
            while (audioRun) {
                int r = rec.read(buf, 0, buf.length);
                if (r <= 0 || !micOn) continue;
                long pts = System.nanoTime() / 1000 - r * 1_000_000L / sr;
                VideoRecorder vr = recorder;
                if (vr != null) vr.addAudio(buf, r, pts);
                if (core.net.isConnected() && System.currentTimeMillis() - core.lastWatched < 6000) {
                    ByteBuffer bb = ByteBuffer.allocate(r * 2).order(ByteOrder.LITTLE_ENDIAN);
                    bb.asShortBuffer().put(buf, 0, r);
                    JSONObject o = Net.Msg.obj("audio");
                    try { o.put("from", core.myId); } catch (JSONException ignored) { }
                    core.net.send(new Net.Msg(o, bb.array()));
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (rec != null) {
                try { rec.stop(); } catch (Exception ignored) { }
                rec.release();
            }
            audioRun = false;
        }
    }

    // ================= nagrywanie =================

    private void toggleRec() {
        if (recorder != null) {
            final VideoRecorder r = recorder;
            recorder = null;
            feed.rec = false;
            r.stop(ok -> Gallery.finishVideo(core, act, r.file, ok, "Nagranie z kamery (" + core.myName + ")"));
        } else {
            if (feed.frame == null) {
                core.toast("Brak obrazu z kamery");
                return;
            }
            File f = new File(act.getCacheDir(), "Cam_" + Ui.fileStamp() + ".mp4");
            recorder = new VideoRecorder(f, feed.outW(), feed.outH(), audioRun && micOn);
            feed.rec = true;
            frame.invalidate();
        }
        refreshButtons();
    }
}
