package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.widget.FrameLayout;

/** Obudowa rozkładanego ekranu kamery: ramka, śruby, zawias, dioda REC. */
final class CamFrame extends FrameLayout {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final FeedView feed;

    CamFrame(Context c, FeedView child) {
        super(c);
        feed = child;
        setWillNotDraw(false);
        int d = Ui.dp(c, 1);
        setPadding(16 * d, 16 * d, 34 * d, 22 * d);
        addView(child, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
    }

    @Override
    protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight(), d = Ui.dp(getContext(), 1);
        RectF body = new RectF(2 * d, 2 * d, W - 2 * d, H - 2 * d);
        p.setShader(new LinearGradient(0, 0, 0, H, new int[]{0xFF3A3D44, 0xFF23252A, 0xFF17181C}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(body, 18 * d, 18 * d, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(d);
        p.setColor(0x33FFFFFF);
        c.drawRoundRect(body, 18 * d, 18 * d, p);
        p.setStyle(Paint.Style.FILL);

        // czarna ramka wokół ekranu
        View ch = getChildAt(0);
        if (ch != null) {
            RectF bez = new RectF(ch.getLeft() - 5 * d, ch.getTop() - 5 * d, ch.getRight() + 5 * d, ch.getBottom() + 5 * d);
            p.setColor(0xFF050506);
            c.drawRoundRect(bez, 8 * d, 8 * d, p);
        }

        // śruby
        float[][] screws = {{10 * d, 10 * d}, {W - 26 * d, 10 * d}, {10 * d, H - 12 * d}, {W - 26 * d, H - 12 * d}};
        for (float[] s : screws) {
            p.setColor(0xFF15161A);
            c.drawCircle(s[0], s[1], 4 * d, p);
            p.setColor(0xFF5A5D66);
            c.drawCircle(s[0], s[1], 3 * d, p);
            p.setColor(0xFF15161A);
            p.setStrokeWidth(d);
            c.drawLine(s[0] - 2 * d, s[1] - 2 * d, s[0] + 2 * d, s[1] + 2 * d, p);
        }

        // zawias po prawej
        RectF hinge = new RectF(W - 22 * d, H * 0.18f, W - 8 * d, H * 0.82f);
        p.setShader(new LinearGradient(hinge.left, 0, hinge.right, 0,
                new int[]{0xFF1A1B1F, 0xFF4A4D55, 0xFF1A1B1F}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(hinge, 6 * d, 6 * d, p);
        p.setShader(null);
        p.setColor(0x55000000);
        for (float y = hinge.top + 10 * d; y < hinge.bottom - 8 * d; y += 6 * d)
            c.drawRect(hinge.left + 3 * d, y, hinge.right - 3 * d, y + 2 * d, p);

        // dioda REC i napis
        boolean rec = feed.rec;
        p.setColor(rec && (System.currentTimeMillis() / 500) % 2 == 0 ? 0xFFFF2A2A : 0xFF3A1414);
        c.drawCircle(W - 15 * d, H * 0.1f, 3 * d, p);
        p.setColor(0xFF8A8D96);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        p.setTextSize(9 * d);
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText("HD · NIGHT VISION", 18 * d, H - 6 * d, p);
        if (rec) postInvalidateDelayed(250);
    }
}
