package pl.duchy.spiritbox;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

/** Cyfry 7-segmentowe jak na wyświetlaczu LCD (z widocznymi niezapalonymi segmentami). */
final class Seg7 {
    private static final int[] SEG = new int[128];
    static {
        SEG['0'] = 63; SEG['1'] = 6; SEG['2'] = 91; SEG['3'] = 79; SEG['4'] = 102;
        SEG['5'] = 109; SEG['6'] = 125; SEG['7'] = 7; SEG['8'] = 127; SEG['9'] = 111;
        SEG['-'] = 64; SEG['O'] = 63; SEG['F'] = 113; SEG['A'] = 119; SEG['E'] = 121;
        SEG['L'] = 56; SEG['n'] = 84; SEG['U'] = 62; SEG['C'] = 57; SEG['H'] = 118;
        SEG['P'] = 115; SEG['r'] = 80; SEG['o'] = 92; SEG['d'] = 94; SEG['b'] = 124;
    }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    /** @return x za ostatnią cyfrą */
    float draw(Canvas c, String s, float x, float y, float h, int on, int ghost) {
        float w = h * 0.52f, t = h * 0.12f, gap = h * 0.20f;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '.') {
                p.setColor(on);
                c.drawCircle(x - gap * 0.55f, y + h - t * 0.5f, t * 0.62f, p);
                continue;
            }
            digit(c, x, y, w, h, t, 127, ghost);
            int m = ch < 128 ? SEG[ch] : 0;
            if (m != 0) digit(c, x, y, w, h, t, m, on);
            x += w + gap;
        }
        return x - gap * 0.4f;
    }

    static float width(String s, float h) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) != '.') n++;
        return n * (h * 0.72f) - h * 0.08f;
    }

    private void digit(Canvas c, float x, float y, float w, float h, float t, int mask, int color) {
        p.setColor(color);
        c.save();
        c.translate(x, y + h);
        c.skew(-0.09f, 0f);
        float top = -h + t / 2, mid = -h / 2, bot = -t / 2, left = t / 2, right = w - t / 2;
        float g = t * 0.18f;
        if ((mask & 1) != 0) hSeg(c, left + g, right - g, top, t);
        if ((mask & 2) != 0) vSeg(c, right, top + g, mid - g, t);
        if ((mask & 4) != 0) vSeg(c, right, mid + g, bot - g, t);
        if ((mask & 8) != 0) hSeg(c, left + g, right - g, bot, t);
        if ((mask & 16) != 0) vSeg(c, left, mid + g, bot - g, t);
        if ((mask & 32) != 0) vSeg(c, left, top + g, mid - g, t);
        if ((mask & 64) != 0) hSeg(c, left + g, right - g, mid, t);
        c.restore();
    }

    private void hSeg(Canvas c, float x1, float x2, float yc, float t) {
        float ht = t / 2;
        path.reset();
        path.moveTo(x1, yc);
        path.lineTo(x1 + ht, yc - ht);
        path.lineTo(x2 - ht, yc - ht);
        path.lineTo(x2, yc);
        path.lineTo(x2 - ht, yc + ht);
        path.lineTo(x1 + ht, yc + ht);
        path.close();
        c.drawPath(path, p);
    }

    private void vSeg(Canvas c, float xc, float y1, float y2, float t) {
        float ht = t / 2;
        path.reset();
        path.moveTo(xc, y1);
        path.lineTo(xc + ht, y1 + ht);
        path.lineTo(xc + ht, y2 - ht);
        path.lineTo(xc, y2);
        path.lineTo(xc - ht, y2 - ht);
        path.lineTo(xc - ht, y1 + ht);
        path.close();
        c.drawPath(path, p);
    }
}
