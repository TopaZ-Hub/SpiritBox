package pl.duchy.spiritbox;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.Random;

/** "Materiały" do rysunków urządzeń: cień pod obudową, ziarnisty plastik, odblask światła. */
final class Mat {
    private static Bitmap noise;
    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);

    private static Bitmap noise() {
        if (noise == null) {
            int n = 96;
            noise = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
            int[] px = new int[n * n];
            Random r = new Random(7);
            for (int i = 0; i < px.length; i++) {
                int a = r.nextInt(26);
                px[i] = (r.nextBoolean() ? 0x00FFFFFF : 0x00000000) | (a << 24);
            }
            noise.setPixels(px, 0, n, 0, 0, n, n);
        }
        return noise;
    }

    /** Miękki cień pod kształtem (kilka przesuniętych, półprzezroczystych warstw). */
    static synchronized void shadow(Canvas c, Path path, float u) {
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        for (int i = 4; i >= 1; i--) {
            P.setColor(((int) (18 + 8 * (5 - i)) << 24));
            c.save();
            c.translate(i * 0.5f * u, i * 0.9f * u);
            c.drawPath(path, P);
            c.restore();
        }
    }

    static synchronized void shadowCircle(Canvas c, float cx, float cy, float r, float u) {
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        for (int i = 4; i >= 1; i--) {
            P.setColor(((int) (18 + 8 * (5 - i)) << 24));
            c.drawCircle(cx + i * 0.5f * u, cy + i * 0.9f * u, r + i * 0.3f * u, P);
        }
    }

    /** Ziarnistość matowego plastiku w obrębie kształtu. */
    static synchronized void grain(Canvas c, Path path, float u) {
        c.save();
        c.clipPath(path);
        P.setStyle(Paint.Style.FILL);
        P.setShader(new BitmapShader(noise(), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
        c.drawPaint(P);
        P.setShader(null);
        c.restore();
    }

    /** Ukośny odblask światła na górnej części obudowy. */
    static synchronized void gloss(Canvas c, RectF r, float u) {
        P.setStyle(Paint.Style.FILL);
        P.setShader(new LinearGradient(r.left, r.top, r.left + r.width() * 0.6f, r.top + r.height() * 0.5f,
                0x26FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.save();
        c.clipRect(r.left, r.top, r.right, r.top + r.height() * 0.55f);
        c.drawRoundRect(r, 6 * u, 6 * u, P);
        c.restore();
        P.setShader(null);
    }

    static synchronized void glossCircle(Canvas c, float cx, float cy, float r) {
        P.setStyle(Paint.Style.FILL);
        P.setShader(new LinearGradient(cx - r, cy - r, cx + r * 0.2f, cy + r * 0.2f, 0x30FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, P);
        P.setShader(null);
    }

    /** Cienka jasna krawędź u góry (fazowanie). */
    static synchronized void bevel(Canvas c, RectF r, float radius, float u) {
        P.setShader(null);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(0.5f * u);
        P.setColor(0x33FFFFFF);
        c.save();
        c.clipRect(r.left, r.top - u, r.right, r.top + r.height() * 0.3f);
        c.drawRoundRect(r, radius, radius, P);
        c.restore();
        P.setStyle(Paint.Style.FILL);
    }
}
