package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.view.Gravity;
import android.view.TextureView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.UdpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.rtsp.RtspMediaSource;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Kamera zewnętrzna: GoPro (przez jej Wi-Fi) albo kamera IP z noktowizją (RTSP, np. Tapo, Imou, Reolink).
 * Obraz z nakładką, zdjęcia, nagrania i udostępnianie drużynie jak kamera telefonu.
 */
final class ExtCamScreen extends Screen {

    private final TextureView tex;
    private final FeedView feed;
    private final EditText url;
    private final Button connectBtn, shareBtn, recBtn;
    private final TextView state;
    private ExoPlayer player;
    private boolean gopro = false, share = false, connected = false;
    private volatile boolean keepAlive = false;
    private VideoRecorder recorder;
    private long lastShot = 0;
    private final Runnable grabber = new Runnable() {
        @Override
        public void run() {
            grab();
            core.main.postDelayed(this, 100);
        }
    };

    ExtCamScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        sv.addView(root);
        addView(sv);

        FrameLayout box = new FrameLayout(a);
        box.setBackgroundColor(0xFF000000);
        tex = new TextureView(a);
        feed = new FeedView(a);
        feed.aspect = 9f / 16f;
        feed.rot = 0;
        feed.overlayOnly = true;
        feed.motionOn = false;
        box.addView(tex, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        box.addView(feed, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        root.addView(box);

        LinearLayout panel = Ui.col(a);
        panel.setPadding(dp(12), dp(12), dp(12), dp(24));
        root.addView(panel);

        state = Ui.head(a, "○ NIEPOŁĄCZONA", 13, Ui.TEXT);
        state.setPadding(0, 0, 0, dp(8));
        panel.addView(state);

        url = new EditText(a);
        LinearLayout presets = Ui.row(a);
        Button gp = Ui.btn(a, "GOPRO");
        gp.setOnClickListener(v -> { url.setText("udp://0.0.0.0:8554"); gopro = true; });
        Button ip = Ui.btn(a, "KAMERA IP");
        ip.setOnClickListener(v -> { url.setText("rtsp://login:haslo@192.168.1.50:554/stream1"); gopro = false; });
        Ui.addWeighted(presets, gp);
        Ui.addWeighted(presets, ip);
        panel.addView(presets);

        url.setSingleLine(true);
        url.setTextColor(Ui.TEXT);
        url.setHintTextColor(Ui.DIM);
        url.setHint("adres strumienia (rtsp://… albo udp://…)");
        url.setText(core.prefs.getString("ext_url", ""));
        panel.addView(url);

        LinearLayout r = Ui.row(a);
        connectBtn = Ui.btn(a, "POŁĄCZ");
        connectBtn.setOnClickListener(v -> { if (connected) disconnect(); else connect(); });
        shareBtn = Ui.btn(a, "UDOSTĘPNIJ DRUŻYNIE");
        shareBtn.setOnClickListener(v -> { share = !share; core.camActive = share && connected; refresh(); });
        Ui.addWeighted(r, connectBtn);
        Ui.addWeighted(r, shareBtn);
        panel.addView(r);
        LinearLayout r2 = Ui.row(a);
        Button photo = Ui.btn(a, "ZDJĘCIE");
        photo.setOnClickListener(v -> photo());
        recBtn = Ui.btn(a, "NAGRYWAJ");
        recBtn.setOnClickListener(v -> toggleRec());
        Ui.addWeighted(r2, photo);
        Ui.addWeighted(r2, recBtn);
        panel.addView(r2);

        TextView info = Ui.text(a,
                "GOPRO (HERO 5–12): włącz w kamerze połączenie z aplikacją, połącz telefon z Wi-Fi kamery, " +
                "kliknij GOPRO i POŁĄCZ. Telefon traci wtedy internet i połączenie z drużyną przez inne Wi-Fi.\n\n" +
                "KAMERA IP z noktowizją (najlepiej widzi w ciemności): w aplikacji producenta włącz RTSP / „konto kamery”, " +
                "wpisz adres jak w przykładzie (login i hasło konta kamery, jej IP w sieci). Kamera i telefon muszą być " +
                "w tej samej sieci.\n\nNagrania z kamery zewnętrznej są bez dźwięku.", 12, Ui.DIM, false);
        info.setGravity(Gravity.START);
        info.setPadding(0, dp(14), 0, 0);
        panel.addView(info);
        refresh();
    }

    @Override
    String title() {
        return "Kamera zewnętrzna";
    }

    @Override
    void onHide() {
        if (recorder != null) toggleRec();
        disconnect();
    }

    private void refresh() {
        connectBtn.setText(connected ? "ROZŁĄCZ" : "POŁĄCZ");
        Ui.active(connectBtn, connected);
        shareBtn.setText(share ? "UDOSTĘPNIAM DRUŻYNIE" : "UDOSTĘPNIJ DRUŻYNIE");
        Ui.active(shareBtn, share);
        recBtn.setText(recorder != null ? "■ STOP" : "NAGRYWAJ");
        Ui.active(recBtn, recorder != null);
    }

    private void connect() {
        String u = url.getText().toString().trim();
        if (u.isEmpty()) {
            core.toast("Wpisz adres albo wybierz GOPRO / KAMERA IP");
            return;
        }
        core.prefs.edit().putString("ext_url", u).apply();
        gopro = u.startsWith("udp://");
        connected = true;
        feed.label = gopro ? "GOPRO" : "KAMERA IP";
        state.setText("◌ ŁĄCZENIE…");
        if (gopro) startGoPro();
        else startPlayer(u);
        core.main.post(grabber);
        refresh();
    }

    private void startPlayer(String u) {
        try {
            if (player != null) player.release();
            player = new ExoPlayer.Builder(act)
                    .setLoadControl(new DefaultLoadControl.Builder().setBufferDurationsMs(500, 2000, 250, 250).build())
                    .build();
            player.setVideoTextureView(tex);
            MediaSource src;
            MediaItem item = MediaItem.fromUri(u);
            if (u.startsWith("rtsp")) src = new RtspMediaSource.Factory().createMediaSource(item);
            else if (u.startsWith("udp")) src = new ProgressiveMediaSource.Factory(() -> new UdpDataSource(3000, 8000)).createMediaSource(item);
            else src = new DefaultMediaSourceFactory(act).createMediaSource(item);
            player.addListener(new Player.Listener() {
                @Override
                public void onPlayerError(PlaybackException e) {
                    state.setText("✕ BŁĄD STRUMIENIA – PONAWIAM…");
                    core.main.postDelayed(() -> { if (connected) startPlayer(u); }, 3000);
                }

                @Override
                public void onRenderedFirstFrame() {
                    state.setText("● NA ŻYWO");
                }
            });
            player.setMediaSource(src);
            player.prepare();
            player.play();
        } catch (Exception e) {
            state.setText("✕ NIE UDAŁO SIĘ OTWORZYĆ STRUMIENIA");
        }
    }

    /** GoPro: przypięcie do Wi-Fi kamery, polecenie startu podglądu, podtrzymywanie strumienia. */
    private void startGoPro() {
        bindWifi(true);
        keepAlive = true;
        new Thread(() -> {
            String[] cmds = {
                    "http://10.5.5.9:8080/gopro/camera/stream/start",          // HERO 9–12 (Open GoPro)
                    "http://10.5.5.9/gp/gpControl/execute?p1=gpStream&c1=restart" // HERO 5–8
            };
            for (String c : cmds) {
                try {
                    HttpURLConnection h = (HttpURLConnection) new URL(c).openConnection();
                    h.setConnectTimeout(2500);
                    h.setReadTimeout(2500);
                    h.getResponseCode();
                    h.disconnect();
                } catch (Exception ignored) { }
            }
            core.main.post(() -> startPlayer("udp://0.0.0.0:8554"));
            try (DatagramSocket ds = new DatagramSocket()) {
                byte[] msg = "_GPHD_:0:0:2:0.000000\n".getBytes(StandardCharsets.US_ASCII);
                InetAddress gp = InetAddress.getByName("10.5.5.9");
                while (keepAlive) {
                    ds.send(new DatagramPacket(msg, msg.length, gp, 8554));
                    Thread.sleep(2500);
                }
            } catch (Exception ignored) { }
        }, "gopro").start();
    }

    private void bindWifi(boolean on) {
        try {
            ConnectivityManager cm = (ConnectivityManager) act.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return;
            if (!on) {
                cm.bindProcessToNetwork(null);
                return;
            }
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    cm.bindProcessToNetwork(n);
                    return;
                }
            }
        } catch (Exception ignored) { }
    }

    private void disconnect() {
        connected = false;
        keepAlive = false;
        core.main.removeCallbacks(grabber);
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
        if (gopro) bindWifi(false);
        if (share) core.camActive = false;
        share = false;
        state.setText("○ NIEPOŁĄCZONA");
        refresh();
    }

    /** Co 100 ms: klatka dla drużyny / do nagrania. */
    private void grab() {
        if (!connected) return;
        long now = System.currentTimeMillis();
        boolean watched = share && core.net.isConnected() && now - core.lastWatched < 6000;
        if (!watched && recorder == null) return;
        Bitmap b = tex.getBitmap(640, 360);
        if (b == null) return;
        VideoRecorder r = recorder;
        if (r != null) r.addFrame(feed.compose(b, 640, 352));
        if (watched && now - lastShot > 140) {
            lastShot = now;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 60, bo);
            JSONObject o = Net.Msg.obj("frame");
            try {
                o.put("from", core.myId);
                o.put("name", core.myName + " · " + feed.label);
                o.put("ts", now);
                o.put("rot", 0);
                o.put("mirror", false);
            } catch (JSONException ignored) { }
            core.net.send(new Net.Msg(o, bo.toByteArray()));
        }
    }

    private void photo() {
        Bitmap b = tex.getBitmap();
        if (b == null || !connected) {
            core.toast("Brak obrazu");
            return;
        }
        Gallery.photoFromBitmap(core, act, feed, b, 1280, 720, "Zdjęcie z kamery zewnętrznej (" + core.myName + ")");
    }

    private void toggleRec() {
        if (recorder != null) {
            final VideoRecorder r = recorder;
            recorder = null;
            feed.rec = false;
            r.stop(ok -> Gallery.finishVideo(core, act, r.file, ok, "Nagranie z kamery zewnętrznej (" + core.myName + ")"));
        } else {
            if (!connected) {
                core.toast("Najpierw połącz kamerę");
                return;
            }
            recorder = new VideoRecorder(new File(act.getCacheDir(), "Ext_" + Ui.fileStamp() + ".mp4"), 640, 352, false);
            feed.rec = true;
        }
        refresh();
        feed.invalidate();
    }
}
