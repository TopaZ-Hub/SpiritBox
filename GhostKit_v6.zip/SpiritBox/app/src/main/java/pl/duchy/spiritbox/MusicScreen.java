package pl.duchy.spiritbox;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Pozytywka: gra wbudowaną (własną) melodię albo wybrany przez ciebie plik. Reaguje na skoki EMF. */
final class MusicScreen extends Screen {

    private final BoxView box;
    private final Button playBtn;
    private final TextView src;
    private volatile boolean playing = false;
    private volatile float pitch = 1f;
    private Thread synthThread;
    private MediaPlayer mp;
    private Uri custom;
    private long hauntUntil = 0, lastHaunt = 0;
    private float[] melody;

    MusicScreen(MainActivity a) {
        super(a);
        String u = core.prefs.getString("music_uri", null);
        if (u != null) custom = Uri.parse(u);

        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(8), dp(8), dp(8), dp(20));
        sv.addView(root);
        addView(sv);
        box = new BoxView(a);
        root.addView(box);

        LinearLayout r1 = Ui.row(a);
        playBtn = Ui.btn(a, "");
        playBtn.setOnClickListener(v -> {
            if (playing) stopMusic();
            else if (custom == null && !core.prefs.getBoolean("music_asked", false)) askForFile();
            else startMusic();
            refresh();
        });
        Ui.addWeighted(r1, playBtn);
        root.addView(r1);

        LinearLayout r2 = Ui.row(a);
        Button pick = Ui.btn(a, "WYBIERZ PLIK");
        pick.setOnClickListener(v -> pickFile());
        Button builtin = Ui.btn(a, "WBUDOWANA");
        builtin.setOnClickListener(v -> {
            boolean was = playing;
            stopMusic();
            custom = null;
            core.prefs.edit().remove("music_uri").apply();
            if (was) startMusic();
            refresh();
        });
        Ui.addWeighted(r2, pick);
        Ui.addWeighted(r2, builtin);
        root.addView(r2);

        src = Ui.text(a, "", 12, Ui.DIM, false);
        src.setPadding(dp(8), dp(8), dp(8), 0);
        root.addView(src);
        refresh();
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        act.startActivityForResult(i, MainActivity.REQ_PICK_AUDIO);
    }

    private void askForFile() {
        core.prefs.edit().putBoolean("music_asked", true).apply();
        new android.app.AlertDialog.Builder(act)
                .setTitle("Melodia pozytywki")
                .setMessage("Wybierz plik audio (np. MP3 z melodią pozytywki). Zostanie zapamiętany i będzie grał " +
                        "domyślnie przy każdym nakręceniu.")
                .setPositiveButton("Wybierz plik", (d, w) -> pickFile())
                .setNegativeButton("Graj wbudowaną", (d, w) -> { startMusic(); refresh(); })
                .show();
    }

    void onPicked(Uri uri) {
        try {
            act.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        stopMusic();
        custom = uri;
        core.prefs.edit().putString("music_uri", uri.toString()).apply();
        startMusic();
        refresh();
    }

    private void refresh() {
        playBtn.setText(playing ? "■  ZATRZYMAJ" : "▶  NAKRĘĆ I GRAJ");
        Ui.active(playBtn, playing);
        src.setText("Melodia: " + (custom != null ? "twój plik (domyślna)" : "wbudowana kołysanka") +
                ". Wybrany plik zostaje zapamiętany. Przy skoku pola EMF (poziom 3+) melodia zwalnia i się rozstraja.");
    }

    @Override
    String title() {
        return "Pozytywka";
    }

    @Override
    void onHide() {
        stopMusic();
        refresh();
    }

    @Override
    void tick() {
        long now = System.currentTimeMillis();
        if (playing && Sensors.level(core.sensors.emfDelta, EmfScreen.LEVELS) >= 3 && now - lastHaunt > 15000) {
            lastHaunt = now;
            hauntUntil = now + 6000;
            core.alert("Pozytywka: skok pola EMF");
        }
        boolean haunted = now < hauntUntil;
        float target = haunted ? 0.80f + 0.06f * (float) Math.sin(now / 300.0) : 1f;
        pitch = target;
        if (mp != null) {
            try {
                if (haunted || Math.abs(box.lastPitch - 1f) > 0.001f) {
                    mp.setPlaybackParams(new PlaybackParams().setPitch(target).setSpeed(haunted ? 0.85f : 1f));
                }
            } catch (Exception ignored) { }
        }
        box.lastPitch = target;
        box.playing = playing;
        box.haunted = haunted;
        box.invalidate();
    }

    // ================= odtwarzanie =================

    private void startMusic() {
        if (playing) return;
        playing = true;
        if (custom != null) {
            try {
                mp = new MediaPlayer();
                mp.setDataSource(act, custom);
                mp.setLooping(true);
                mp.prepare();
                mp.start();
                return;
            } catch (Exception e) {
                core.toast("Nie można odtworzyć pliku – gram melodię wbudowaną");
                if (mp != null) mp.release();
                mp = null;
            }
        }
        synthThread = new Thread(this::synthLoop, "music-box");
        synthThread.start();
    }

    private void stopMusic() {
        playing = false;
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) { }
            mp.release();
            mp = null;
        }
        if (synthThread != null) {
            try { synthThread.join(500); } catch (InterruptedException ignored) { }
            synthThread = null;
        }
    }

    private void synthLoop() {
        final int sr = 44100;
        if (melody == null) melody = renderMelody(sr);
        int minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack t;
        try {
            t = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(sr)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(minBuf * 2, 8192))
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
        } catch (Exception e) {
            playing = false;
            return;
        }
        t.play();
        short[] out = new short[1024];
        double pos = 0;
        float cur = 1f;
        while (playing) {
            for (int i = 0; i < out.length; i++) {
                cur += (pitch - cur) * 0.0005f;
                int i0 = (int) pos;
                float fr = (float) (pos - i0);
                float a = melody[i0 % melody.length], b = melody[(i0 + 1) % melody.length];
                out[i] = (short) ((a + (b - a) * fr) * 28000f);
                pos += cur;
                if (pos >= melody.length) pos -= melody.length;
            }
            t.write(out, 0, out.length);
        }
        try { t.stop(); } catch (Exception ignored) { }
        t.release();
    }

    /** Własna, smutna kołysanka w a-moll (3/4), brzmienie grzebienia pozytywki. */
    private static float[] renderMelody(int sr) {
        // {midi, początek w taktach (ćwierćnutach), długość}
        double[][] mel = {
                {69, 0, 1}, {72, 1, 1}, {76, 2, 1},
                {74, 3, 1.5}, {72, 4.5, .5}, {71, 5, 1},
                {69, 6, 1}, {64, 7, 1}, {69, 8, 1},
                {68, 9, 2}, {64, 11, 1},
                {69, 12, 1}, {72, 13, 1}, {76, 14, 1},
                {77, 15, 1.5}, {76, 16.5, .5}, {74, 17, 1},
                {72, 18, 1}, {71, 19, 1}, {68, 20, 1},
                {69, 21, 3},
                {76, 24, 1}, {77, 25, 1}, {76, 26, 1},
                {74, 27, 1}, {72, 28, 1}, {74, 29, 1},
                {72, 30, 1}, {71, 31, 1}, {69, 32, 1},
                {71, 33, 2}, {64, 35, 1},
                {69, 36, 1}, {71, 37, 1}, {72, 38, 1},
                {74, 39, 1}, {76, 40, 1}, {77, 41, 1},
                {76, 42, 1}, {74, 43, 1}, {71, 44, 1},
                {69, 45, 3},
        };
        int[] bass = {57, 52, 57, 52, 57, 50, 52, 57, 57, 55, 53, 52, 57, 50, 52, 57};
        double beat = 0.62;
        int len = (int) ((48 * beat + 3) * sr);
        float[] buf = new float[len];
        for (double[] n : mel) addNote(buf, sr, n[0], n[1] * beat, 0.7f);
        for (int bar = 0; bar < bass.length; bar++) {
            addNote(buf, sr, bass[bar], bar * 3 * beat, 0.45f);
            addNote(buf, sr, bass[bar] + 7, (bar * 3 + 1) * beat, 0.22f);
            addNote(buf, sr, bass[bar] + 12, (bar * 3 + 2) * beat, 0.18f);
        }
        float peak = 0;
        for (float v : buf) peak = Math.max(peak, Math.abs(v));
        if (peak > 0) for (int i = 0; i < len; i++) buf[i] *= 0.85f / peak;
        return buf;
    }

    private static void addNote(float[] buf, int sr, double midi, double start, float amp) {
        double f = 440.0 * Math.pow(2, (midi - 69) / 12.0);
        int s0 = (int) (start * sr), n = (int) (2.6 * sr);
        for (int i = 0; i < n && s0 + i < buf.length; i++) {
            double t = i / (double) sr;
            double env = Math.exp(-t / 0.9) * (1 - Math.exp(-t / 0.002));
            double v = Math.sin(2 * Math.PI * f * t)
                    + 0.35 * Math.sin(2 * Math.PI * 2 * f * t) * Math.exp(-t / 0.3)
                    + 0.12 * Math.sin(2 * Math.PI * 3.01 * f * t) * Math.exp(-t / 0.15)
                    + 0.05 * Math.sin(2 * Math.PI * 4.2 * f * t) * Math.exp(-t / 0.08);
            buf[s0 + i] += (float) (v * env * amp);
        }
    }

    // ================= rysunek =================

    static final class BoxView extends View {
        boolean playing, haunted;
        float lastPitch = 1f;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float crank = 0;

        BoxView(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w);
            setMeasuredDimension(W, (int) (W * 1.05f));
        }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), u = W / 100f;
            long now = System.currentTimeMillis();
            if (playing) crank += haunted ? 0.05f : 0.12f;
            float shake = haunted ? (float) Math.sin(now / 25.0) * 0.6f * u : 0;
            c.save();
            c.translate(shake, 0);

            int[] wood = {0xFF4A2412, 0xFF7A4024, 0xFF5A2C16, 0xFF6E3A1E};

            // wieko (otwarte, z tyłu)
            RectF lid = new RectF(12 * u, 4 * u, 88 * u, 46 * u);
            p.setShader(new LinearGradient(lid.left, lid.top, lid.right, lid.bottom, wood, null, Shader.TileMode.MIRROR));
            c.drawRoundRect(lid, 2 * u, 2 * u, p);
            p.setShader(null);
            grain(c, lid, u);
            // kartka z nutami
            RectF sheet = new RectF(30 * u, 12 * u, 70 * u, 36 * u);
            p.setColor(0xFF3A2A10);
            c.drawRect(sheet.left - u, sheet.top - u, sheet.right + u, sheet.bottom + u, p);
            p.setColor(0xFFE8DCC0);
            c.drawRect(sheet, p);
            p.setColor(0xFF4A3A2A);
            p.setStrokeWidth(0.25f * u);
            for (int s = 0; s < 2; s++) {
                float y0 = sheet.top + 6 * u + s * 10 * u;
                for (int l = 0; l < 5; l++) c.drawLine(sheet.left + 2 * u, y0 + l * u, sheet.right - 2 * u, y0 + l * u, p);
                for (int k = 0; k < 9; k++) {
                    float nx = sheet.left + 5 * u + k * 3.8f * u;
                    float ny = y0 + ((k * 7 + s * 3) % 5) * u;
                    c.drawCircle(nx, ny, 0.7f * u, p);
                    c.drawLine(nx + 0.6f * u, ny, nx + 0.6f * u, ny - 3 * u, p);
                }
            }
            p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC));
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(2.6f * u);
            c.drawText("Kołysanka", sheet.centerX(), sheet.top + 3.4f * u, p);

            // wnętrze z mechanizmem
            RectF inside = new RectF(12 * u, 46 * u, 88 * u, 62 * u);
            p.setColor(0xFF1E120A);
            c.drawRect(inside, p);
            // walec
            RectF cyl = new RectF(42 * u, 49 * u, 76 * u, 59 * u);
            p.setShader(new LinearGradient(0, cyl.top, 0, cyl.bottom,
                    new int[]{0xFF6A5420, 0xFFE8CC70, 0xFF6A5420}, null, Shader.TileMode.CLAMP));
            c.drawRoundRect(cyl, 2 * u, 2 * u, p);
            p.setShader(null);
            p.setColor(0xFF3A2A08);
            float off = (crank * 6 * u) % (3 * u);
            for (float x = cyl.left + 1.5f * u - off; x < cyl.right - u; x += 3 * u) {
                if (x < cyl.left + u) continue;
                for (int k = 0; k < 3; k++) c.drawCircle(x, cyl.top + 2.5f * u + k * 2.5f * u + ((int) (x / u) % 2) * 1.2f * u, 0.45f * u, p);
            }
            // grzebień
            p.setColor(0xFFB8A060);
            for (float x = cyl.left; x < cyl.right; x += 1.6f * u) c.drawRect(x, 59 * u, x + 0.9f * u, 62 * u, p);
            // bęben sprężyny
            p.setColor(0xFF2A2A2A);
            c.drawCircle(26 * u, 54 * u, 5 * u, p);
            p.setColor(0xFF555555);
            c.drawCircle(26 * u, 54 * u, 2 * u, p);

            // przód skrzynki
            RectF front = new RectF(8 * u, 62 * u, 92 * u, 96 * u);
            p.setShader(new LinearGradient(front.left, front.top, front.right, front.bottom, wood, null, Shader.TileMode.MIRROR));
            c.drawRoundRect(front, 2 * u, 2 * u, p);
            p.setShader(null);
            grain(c, front, u);
            p.setColor(0xFF2A160A);
            c.drawRect(8 * u, 94 * u, 92 * u, 98 * u, p);
            // dziurka od klucza
            p.setColor(0xFFB8A060);
            c.drawCircle(50 * u, 76 * u, 3 * u, p);
            p.setColor(0xFF0A0604);
            c.drawCircle(50 * u, 75.5f * u, 1.1f * u, p);
            c.drawRect(49.5f * u, 76 * u, 50.5f * u, 79 * u, p);

            // korbka
            float kx = 94 * u, ky = 78 * u;
            p.setColor(0xFF444444);
            c.drawCircle(kx - 2 * u, ky, 1.5f * u, p);
            float ex = kx + (float) Math.cos(crank) * 5 * u, ey = ky + (float) Math.sin(crank) * 5 * u;
            p.setStrokeWidth(1.2f * u);
            c.drawLine(kx - 2 * u, ky, ex, ey, p);
            p.setColor(0xFF7A2A1A);
            c.drawCircle(ex, ey, 1.8f * u, p);

            if (haunted) {
                p.setColor(0x66FF3020);
                p.setTextSize(5 * u);
                p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC));
                c.drawText("…", 50 * u, 104 * u, p);
            }
            c.restore();
        }

        private void grain(Canvas c, RectF r, float u) {
            p.setColor(0x22000000);
            p.setStrokeWidth(0.3f * u);
            for (float y = r.top + 2 * u; y < r.bottom - u; y += 2.3f * u) {
                float w = (float) Math.sin(y * 0.37f) * u;
                c.drawLine(r.left + u, y + w, r.right - u, y - w, p);
            }
        }
    }
}
