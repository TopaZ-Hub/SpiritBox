package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Ręcznie rysowane ikony (linia) i logo aplikacji – zamiast emoji. */
final class Icons {

    /** Logo: duszek z falistym dołem w okręgu. */
    static void ghost(Canvas c, Paint p, Path path, float cx, float cy, float s, int body, int eyes) {
        float w = s * 0.62f, top = cy - s * 0.52f, bot = cy + s * 0.46f;
        path.reset();
        path.moveTo(cx - w / 2, bot);
        path.lineTo(cx - w / 2, top + w / 2);
        path.arcTo(new RectF(cx - w / 2, top, cx + w / 2, top + w), 180, 180);
        path.lineTo(cx + w / 2, bot);
        int waves = 3;
        float ww = w / waves;
        for (int i = 0; i < waves; i++) {
            float x0 = cx + w / 2 - i * ww;
            path.quadTo(x0 - ww * 0.25f, bot - s * 0.12f, x0 - ww * 0.5f, bot);
            path.quadTo(x0 - ww * 0.75f, bot + s * 0.08f, x0 - ww, bot);
        }
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(body);
        c.drawPath(path, p);
        p.setColor(eyes);
        float ey = top + w * 0.55f;
        c.drawOval(new RectF(cx - w * 0.26f, ey - s * 0.07f, cx - w * 0.08f, ey + s * 0.07f), p);
        c.drawOval(new RectF(cx + w * 0.08f, ey - s * 0.07f, cx + w * 0.26f, ey + s * 0.07f), p);
        c.drawOval(new RectF(cx - w * 0.08f, ey + s * 0.12f, cx + w * 0.08f, ey + s * 0.24f), p);
    }

    static final class Logo extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        Logo(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight());
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Ui.accent(0x22));
            c.drawCircle(cx, cy, s / 2f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s * 0.04f);
            p.setColor(Ui.ACCENT);
            c.drawCircle(cx, cy, s / 2f - s * 0.03f, p);
            ghost(c, p, path, cx, cy + s * 0.02f, s * 0.62f, Ui.TEXT, Ui.BG);
        }
    }

    /** Ikona narzędzia rysowana kreską. */
    static final class Tool extends View {
        private final String type;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        Tool(Context c, String type) {
            super(c);
            this.type = type;
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight()), u = s / 24f;
            c.save();
            c.translate((getWidth() - s) / 2f, (getHeight() - s) / 2f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.7f * u);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(Ui.ACCENT);
            switch (type) {
                case "box":
                    c.drawRoundRect(new RectF(3 * u, 7 * u, 21 * u, 21 * u), 2 * u, 2 * u, p);
                    c.drawLine(15 * u, 7 * u, 19 * u, 2 * u, p);
                    c.drawCircle(15 * u, 15 * u, 3 * u, p);
                    c.drawLine(6 * u, 11 * u, 10 * u, 11 * u, p);
                    c.drawLine(6 * u, 14 * u, 10 * u, 14 * u, p);
                    c.drawLine(6 * u, 17 * u, 10 * u, 17 * u, p);
                    break;
                case "emf":
                    c.drawRoundRect(new RectF(7 * u, 3 * u, 17 * u, 21 * u), 2 * u, 2 * u, p);
                    for (int i = 0; i < 3; i++) c.drawCircle((9.5f + i * 2.5f) * u, 6.5f * u, 0.6f * u, p);
                    c.drawArc(new RectF(9 * u, 9 * u, 15 * u, 15 * u), 200, 140, false, p);
                    c.drawLine(12 * u, 14 * u, 12 * u, 18 * u, p);
                    break;
                case "thermo":
                    c.drawLine(10 * u, 4 * u, 10 * u, 14 * u, p);
                    c.drawLine(14 * u, 4 * u, 14 * u, 14 * u, p);
                    c.drawArc(new RectF(10 * u, 2 * u, 14 * u, 6 * u), 180, 180, false, p);
                    c.drawCircle(12 * u, 17.5f * u, 3.6f * u, p);
                    c.drawLine(16 * u, 7 * u, 19 * u, 7 * u, p);
                    c.drawLine(16 * u, 10 * u, 18 * u, 10 * u, p);
                    break;
                case "cam":
                    c.drawRoundRect(new RectF(2 * u, 7 * u, 16 * u, 18 * u), 2 * u, 2 * u, p);
                    path.reset();
                    path.moveTo(16 * u, 11 * u);
                    path.lineTo(22 * u, 7.5f * u);
                    path.lineTo(22 * u, 17.5f * u);
                    path.lineTo(16 * u, 14 * u);
                    c.drawPath(path, p);
                    c.drawCircle(6 * u, 11 * u, 1 * u, p);
                    break;
                case "view":
                    c.drawRoundRect(new RectF(2 * u, 4 * u, 22 * u, 17 * u), 2 * u, 2 * u, p);
                    c.drawLine(8 * u, 21 * u, 16 * u, 21 * u, p);
                    c.drawLine(12 * u, 17 * u, 12 * u, 21 * u, p);
                    c.drawCircle(12 * u, 10.5f * u, 2.5f * u, p);
                    break;
                case "motion":
                    c.drawArc(new RectF(3 * u, 3 * u, 21 * u, 21 * u), 200, 140, false, p);
                    c.drawArc(new RectF(7 * u, 7 * u, 17 * u, 17 * u), 200, 140, false, p);
                    c.drawCircle(12 * u, 14 * u, 1.4f * u, p);
                    c.drawLine(12 * u, 16 * u, 12 * u, 21 * u, p);
                    break;
                case "music":
                    c.drawRect(3 * u, 11 * u, 21 * u, 20 * u, p);
                    c.drawLine(3 * u, 11 * u, 6 * u, 4 * u, p);
                    c.drawLine(6 * u, 4 * u, 21 * u, 4 * u, p);
                    c.drawLine(21 * u, 4 * u, 21 * u, 11 * u, p);
                    c.drawCircle(12 * u, 15.5f * u, 1.2f * u, p);
                    break;
                case "book":
                    path.reset();
                    path.moveTo(12 * u, 6 * u);
                    path.quadTo(7 * u, 3.5f * u, 3 * u, 5 * u);
                    path.lineTo(3 * u, 19 * u);
                    path.quadTo(7 * u, 17.5f * u, 12 * u, 20 * u);
                    path.quadTo(17 * u, 17.5f * u, 21 * u, 19 * u);
                    path.lineTo(21 * u, 5 * u);
                    path.quadTo(17 * u, 3.5f * u, 12 * u, 6 * u);
                    path.lineTo(12 * u, 20 * u);
                    c.drawPath(path, p);
                    break;
                case "team":
                    c.drawCircle(9 * u, 8 * u, 3 * u, p);
                    c.drawArc(new RectF(3 * u, 13 * u, 15 * u, 25 * u), 180, 180, false, p);
                    c.drawCircle(17 * u, 9 * u, 2.4f * u, p);
                    c.drawArc(new RectF(13 * u, 14 * u, 22 * u, 23 * u), 200, 140, false, p);
                    break;
                case "compass":
                    c.drawCircle(12 * u, 12 * u, 9 * u, p);
                    path.reset();
                    path.moveTo(12 * u, 5 * u);
                    path.lineTo(14.5f * u, 12 * u);
                    path.lineTo(12 * u, 19 * u);
                    path.lineTo(9.5f * u, 12 * u);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case "para":
                    c.drawArc(new RectF(3 * u, 3 * u, 21 * u, 21 * u), 120, 240, false, p);
                    c.drawCircle(12 * u, 12 * u, 2 * u, p);
                    c.drawLine(12 * u, 14 * u, 12 * u, 22 * u, p);
                    break;
                case "gate":
                    c.drawRect(5 * u, 3 * u, 19 * u, 21 * u, p);
                    c.drawLine(12 * u, 3 * u, 12 * u, 21 * u, p);
                    c.drawCircle(15 * u, 12 * u, 0.8f * u, p);
                    break;
                case "ext":
                    c.drawRoundRect(new RectF(3 * u, 7 * u, 21 * u, 19 * u), 2 * u, 2 * u, p);
                    c.drawCircle(12 * u, 13 * u, 3.5f * u, p);
                    c.drawLine(15 * u, 4 * u, 19 * u, 4 * u, p);
                    break;
                case "walkie":
                    c.drawRoundRect(new RectF(7 * u, 6 * u, 17 * u, 22 * u), 2 * u, 2 * u, p);
                    c.drawLine(14 * u, 6 * u, 14 * u, 1.5f * u, p);
                    c.drawLine(9.5f * u, 10 * u, 14.5f * u, 10 * u, p);
                    c.drawLine(9.5f * u, 12.5f * u, 14.5f * u, 12.5f * u, p);
                    c.drawCircle(12 * u, 17.5f * u, 1.6f * u, p);
                    break;
                case "settings":
                    c.drawCircle(12 * u, 12 * u, 3 * u, p);
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI * 2 * i / 8;
                        c.drawLine(12 * u + (float) Math.cos(a) * 6 * u, 12 * u + (float) Math.sin(a) * 6 * u,
                                12 * u + (float) Math.cos(a) * 9 * u, 12 * u + (float) Math.sin(a) * 9 * u, p);
                    }
                    c.drawCircle(12 * u, 12 * u, 6 * u, p);
                    break;
            }
            c.restore();
        }
    }
}
