package pl.duchy.spiritbox;

import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.graphics.YuvImage;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.view.Gravity;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.Locale;

/**
 * Kamera tego telefonu (Camera2).
 * - Podgląd na żywo prosto na ekran – bez opóźnienia.
 * - Noktowizja: ręczny, długi czas naświetlania + maksymalna czułość, potem automatyczne rozjaśnianie
 *   i składanie kolejnych klatek (mniej szumu).
 * - Zoom 1–4× z kierunkiem (palcem, strzałkami albo zdalnie), wykrywanie ruchu i sylwetek.
 */
final class CamScreen extends Screen implements Core.CmdSink, TextureView.SurfaceTextureListener {

    private static final long[] EXPOSURES = {66_000_000L, 125_000_000L, 250_000_000L, 500_000_000L};
    private static final String[] EXPO_NAMES = {"1/15 s", "1/8 s", "1/4 s", "1/2 s"};

    private final TextureView tex;
    private final FeedView feed;
    private final Controls.Round flashB, nvB, motionB, poseB, micB;
    private final Controls.Shutter recB;
    private final TextView[] chips = new TextView[4];
    private final TextView[] expo = new TextView[4];
    private final LinearLayout lensRow, expoRow;
    private final TextView expoNote;
    private final Controls.PanZoom pz;
    private final PoseTracker poseTracker = new PoseTracker();
    private final CamDevice dev;
    private List<CamDevice.Lens> lenses;
    private int lensIdx = 0, expoIdx = 2;

    private SurfaceTexture surface;
    private volatile int rotation = 90;
    private volatile boolean front = false;
    private volatile boolean flash = false, nv = false, motionOn = true, poseOn = false, micOn = true;
    private volatile boolean photoRequested = false;
    private VideoRecorder recorder;
    private int recW, recH;
    private long lastSend = 0, lastMotion = 0, ignoreMotionUntil = 0, lastMotionCheck = 0;
    private byte[] prevY;
    private int[] acc;
    private Rect accRect;
    private int[] argb;

    private volatile boolean audioRun = false;
    private Thread audioThread;

    CamScreen(MainActivity a) {
        super(a);
        dev = new CamDevice(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        sv.addView(root);
        addView(sv);

        FrameLayout box = new FrameLayout(a);
        tex = new TextureView(a);
        tex.setSurfaceTextureListener(this);
        feed = new FeedView(a);
        feed.overlayOnly = true;
        box.addView(tex, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        box.addView(feed, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        root.addView(box, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        pz = new Controls.PanZoom(a, (z, u, v, done) -> applyView());
        feed.setOnTouchListener(pz);

        LinearLayout panel = Ui.col(a);
        panel.setPadding(dp(12), dp(10), dp(12), dp(16));
        panel.setBackgroundColor(Ui.CARD);
        root.addView(panel);

        lensRow = Ui.row(a);
        lensRow.setGravity(Gravity.CENTER);
        panel.addView(lensRow);

        // zoom + krzyżak
        LinearLayout zr = Ui.row(a);
        zr.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout zc = Ui.col(a);
        for (int i = 0; i < 4; i++) {
            final int z = i + 1;
            chips[i] = Ui.head(a, z + "×", 13, Ui.TEXT);
            chips[i].setGravity(Gravity.CENTER);
            chips[i].setOnClickListener(v -> { pz.set(z, pz.u, pz.v); applyView(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(64), dp(30));
            lp.setMargins(0, dp(2), 0, dp(2));
            zc.addView(chips[i], lp);
        }
        zr.addView(zc);
        TextView zh = Ui.text(a, "ZOOM\n\nprzeciągnij\nobraz albo\nużyj strzałek", 10, Ui.DIM, false);
        zh.setGravity(Gravity.CENTER);
        zr.addView(zh, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        zr.addView(Controls.dpad(a, pz));
        panel.addView(zr);

        LinearLayout tr = Ui.row(a);
        tr.setPadding(0, dp(12), 0, 0);
        flashB = new Controls.Round(a, "flash");
        nvB = new Controls.Round(a, "nv");
        motionB = new Controls.Round(a, "motion");
        poseB = new Controls.Round(a, "pose");
        micB = new Controls.Round(a, "mic");
        Ui.addWeighted(tr, Controls.labeled(a, flashB, "LAMPA", 48, v -> { flash = !flash; applyParams(); }));
        Ui.addWeighted(tr, Controls.labeled(a, nvB, "NOKTOWIZJA", 48, v -> { nv = !nv; applyParams(); }));
        Ui.addWeighted(tr, Controls.labeled(a, motionB, "RUCH", 48, v -> { motionOn = !motionOn; applyParams(); }));
        Ui.addWeighted(tr, Controls.labeled(a, poseB, "SYLWETKI", 48, v -> { poseOn = !poseOn; applyParams(); }));
        Ui.addWeighted(tr, Controls.labeled(a, micB, "DŹWIĘK", 48, v -> { micOn = !micOn; refreshControls(); }));
        panel.addView(tr);

        expoRow = Ui.row(a);
        expoRow.setGravity(Gravity.CENTER);
        expoRow.setPadding(0, dp(10), 0, 0);
        for (int i = 0; i < 4; i++) {
            final int k = i;
            expo[i] = Ui.head(a, EXPO_NAMES[i], 11, Ui.TEXT);
            expo[i].setGravity(Gravity.CENTER);
            expo[i].setOnClickListener(v -> { expoIdx = k; applyParams(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(30), 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            expoRow.addView(expo[i], lp);
        }
        panel.addView(expoRow);
        expoNote = Ui.text(a, "", 10, Ui.DIM, false);
        expoNote.setGravity(Gravity.CENTER);
        panel.addView(expoNote);

        LinearLayout sr = Ui.row(a);
        sr.setPadding(0, dp(12), 0, 0);
        Controls.Shutter photoB = new Controls.Shutter(a, false);
        recB = new Controls.Shutter(a, true);
        Ui.addWeighted(sr, Controls.labeled(a, photoB, "ZDJĘCIE", 68, v -> photoRequested = true));
        Ui.addWeighted(sr, Controls.labeled(a, recB, "NAGRYWANIE", 68, v -> toggleRec()));
        panel.addView(sr);

        TextView info = Ui.text(a, "Noktowizja: dłuższy czas naświetlania = jaśniej, ale mniej płynnie. " +
                "Aparat telefonu nie ma oświetlacza podczerwieni – w zupełnej ciemności pomoże lampa albo latarka IR " +
                "(sprawdź pilotem od TV, czy aparat widzi podczerwień). Sylwetki – wykrywanie postaci ludzkiej w kadrze.",
                11, Ui.DIM, false);
        info.setPadding(dp(4), dp(14), dp(4), 0);
        panel.addView(info);
        buildLensRow();
        refreshControls();
    }

    private void buildLensRow() {
        lenses = CamDevice.lenses(act);
        lensRow.removeAllViews();
        for (int i = 0; i < lenses.size(); i++) {
            final int k = i;
            TextView t = Ui.head(act, lenses.get(i).label, 10, Ui.TEXT);
            t.setPadding(dp(10), dp(6), dp(10), dp(6));
            t.setOnClickListener(v -> switchLens(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(3), 0, dp(3), dp(10));
            lensRow.addView(t, lp);
        }
    }

    @Override
    String title() {
        return "Kamera";
    }

    @Override
    void onShow() {
        core.camActive = true;
        core.cmdSink = this;
        act.withPermission(Manifest.permission.CAMERA, () -> {
            if (lenses == null || lenses.isEmpty()) buildLensRow();
            openCam();
            act.withPermission(Manifest.permission.RECORD_AUDIO, this::startAudio);
        });
    }

    @Override
    void onHide() {
        core.camActive = false;
        if (core.cmdSink == this) core.cmdSink = null;
        if (recorder != null) toggleRec();
        stopAudio();
        dev.close();
    }

    @Override
    void tick() {
        long now = System.currentTimeMillis();
        boolean watched = core.net.isConnected() && now - core.lastWatched < 6000;
        boolean heavy = nv || recorder != null;
        dev.wantFrames = heavy || watched || poseOn || photoRequested || motionOn;
        dev.frameIntervalMs = heavy ? 80 : (watched || poseOn || photoRequested) ? 120 : 250;
        if (!poseOn) feed.pose = null;
    }

    // ================= TextureView =================

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
        surface = st;
        if (core.camActive && act.has(Manifest.permission.CAMERA)) openCam();
        applyView();
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
        applyView();
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        surface = null;
        dev.close();
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture st) { }

    // ================= aparat =================

    private void openCam() {
        if (surface == null || !core.camActive || lenses == null || lenses.isEmpty()) return;
        CamDevice.Lens l = lenses.get(Math.min(lensIdx, lenses.size() - 1));
        rotation = l.orientation;
        front = l.front;
        feed.rot = rotation;
        feed.mirror = front;
        feed.label = core.myName + " · " + l.label;
        prevY = null;
        acc = null;
        boolean hq = core.prefs.getBoolean("cam_hq", false);
        dev.torch = flash;
        dev.night = nv;
        dev.nightExposureNs = EXPOSURES[expoIdx];
        dev.open(l, surface, hq ? 1280 : 800, this::onFrame);
        ignoreMotionUntil = System.currentTimeMillis() + 2500;
        refreshControls();
    }

    private void switchLens(int k) {
        if (k == lensIdx) return;
        if (recorder != null) toggleRec();
        lensIdx = k;
        flash = false;
        pz.set(1, 0.5f, 0.5f);
        dev.close();
        openCam();
        applyView();
    }

    private void applyParams() {
        dev.torch = flash;
        dev.night = nv;
        dev.nightExposureNs = EXPOSURES[expoIdx];
        dev.update();
        feed.nv = nv;
        feed.flash = flash;
        feed.motionOn = motionOn;
        feed.poseOn = poseOn;
        feed.overlayOnly = !nv;
        if (!nv) feed.frame = null;
        acc = null;
        ignoreMotionUntil = System.currentTimeMillis() + 2500;
        refreshControls();
        feed.invalidate();
    }

    private void applyView() {
        int W = tex.getWidth(), H = tex.getHeight();
        if (W > 0 && H > 0) {
            Matrix m = new Matrix();
            m.setScale(pz.z, pz.z);
            m.postTranslate(W / 2f - pz.u * W * pz.z, H / 2f - pz.v * H * pz.z);
            tex.setTransform(m);
        }
        feed.zoomText = pz.z > 1.05f ? String.format(Locale.US, "%.1f×", pz.z) : "";
        acc = null;
        refreshControls();
        feed.invalidate();
    }

    private void chip(TextView t, boolean on, int radius) {
        t.setTextColor(on ? Ui.BG : Ui.TEXT);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(radius));
        g.setColor(on ? Ui.ACCENT : Ui.CARD2);
        g.setStroke(dp(1), Ui.STROKE);
        t.setBackground(g);
    }

    private void refreshControls() {
        flashB.set(flash);
        nvB.set(nv);
        motionB.set(motionOn);
        poseB.set(poseOn);
        micB.set(micOn && audioRun);
        recB.set(recorder != null);
        feed.mic = micOn && audioRun;
        for (int i = 0; i < 4; i++) chip(chips[i], Math.abs(pz.z - (i + 1)) < 0.25f, 15);
        for (int i = 0; i < lensRow.getChildCount(); i++) chip((TextView) lensRow.getChildAt(i), i == lensIdx, 14);
        boolean manual = dev.manual();
        expoRow.setVisibility(nv && manual ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 4; i++) chip(expo[i], i == expoIdx, 8);
        expoNote.setVisibility(nv ? View.VISIBLE : View.GONE);
        expoNote.setText(manual ? "czas naświetlania w noktowizji" :
                "ten obiektyw nie pozwala ręcznie ustawić naświetlania – używam automatycznego trybu nocnego");
    }

    @Override
    public void onCmd(JSONObject j) {
        String c = j.optString("c"), from = j.optString("name");
        String what;
        switch (c) {
            case "flash": flash = j.optBoolean("v"); what = flash ? "włączył lampę" : "wyłączył lampę"; break;
            case "nv": nv = j.optBoolean("v"); what = nv ? "włączył noktowizję" : "wyłączył noktowizję"; break;
            case "motion": motionOn = j.optBoolean("v"); what = motionOn ? "włączył wykrywanie ruchu" : "wyłączył wykrywanie ruchu"; break;
            case "pose": poseOn = j.optBoolean("v"); what = poseOn ? "włączył wykrywanie sylwetek" : "wyłączył wykrywanie sylwetek"; break;
            case "view":
                pz.set((float) j.optDouble("z", 1), (float) j.optDouble("u", 0.5), (float) j.optDouble("v", 0.5));
                applyView();
                return;
            default: return;
        }
        applyParams();
        core.toast(from + " " + what);
    }

    // ================= klatki (wątek aparatu) =================

    private void onFrame(byte[] d, int w, int h) {
        long now = System.currentTimeMillis();
        if (motionOn && now - lastMotionCheck > 200) {
            lastMotionCheck = now;
            detectMotion(d, w, h, now);
        }
        boolean watched = core.net.isConnected() && now - core.lastWatched < 6000;
        boolean rec = recorder != null;
        if (!(nv || watched || rec || photoRequested || poseOn)) return;
        Rect r = cropRect(w, h);
        if (nv) enhance(d, w, h, r);
        byte[] jpg = null;
        boolean needBmp = rec || photoRequested || poseOn;
        if (watched || (!nv && needBmp)) {
            YuvImage yi = new YuvImage(d, ImageFormat.NV21, w, h, null);
            ByteArrayOutputStream bo = new ByteArrayOutputStream(65536);
            yi.compressToJpeg(r, 62, bo);
            jpg = bo.toByteArray();
        }
        Bitmap bm = null;
        if (nv) {
            bm = grayBitmap(d, w, r);
            feed.setFrame(bm, now);
        } else if (needBmp && jpg != null) {
            bm = BitmapFactory.decodeByteArray(jpg, 0, jpg.length);
        }
        if (poseOn && bm != null) {
            poseTracker.submit(bm, rotation, front);
            feed.pose = poseTracker.current();
            feed.postInvalidate();
        }
        if (watched && jpg != null && now - lastSend > 110) {
            lastSend = now;
            core.net.send(frameMsg(jpg, now));
        }
        if (bm != null) {
            VideoRecorder vr = recorder;
            if (vr != null) vr.addFrame(feed.compose(bm, recW, recH));
            if (photoRequested) {
                photoRequested = false;
                final Bitmap shot = bm;
                boolean swap = rotation % 180 != 0;
                final int pw2 = swap ? 720 : 960, ph2 = swap ? 960 : 720;
                core.main.post(() -> Gallery.photoFromBitmap(core, act, feed, shot, pw2, ph2,
                        "Zdjęcie z kamery (" + core.myName + ")"));
            }
        }
    }

    private Rect cropRect(int w, int h) {
        float z = pz.z, u = pz.u, v = pz.v;
        if (front) u = 1 - u;
        float sx, sy;
        switch (rotation) {
            case 90: sx = v; sy = 1 - u; break;
            case 270: sx = 1 - v; sy = u; break;
            case 180: sx = 1 - u; sy = 1 - v; break;
            default: sx = u; sy = v;
        }
        int cw = ((int) (w / z)) & ~1, ch = ((int) (h / z)) & ~1;
        int l = Math.max(0, Math.min(w - cw, (int) (sx * w - cw / 2f))) & ~1;
        int t = Math.max(0, Math.min(h - ch, (int) (sy * h - ch / 2f))) & ~1;
        return new Rect(l, t, l + cw, t + ch);
    }

    /** Automatyczna krzywa jasności + składanie klatek (uśrednianie ~4 ostatnich). */
    private void enhance(byte[] d, int w, int h, Rect r) {
        long sum = 0;
        int cnt = 0;
        for (int y = r.top; y < r.bottom; y += 8)
            for (int x = r.left; x < r.right; x += 8) { sum += d[y * w + x] & 255; cnt++; }
        double mean = Math.max(1.0, sum / (double) Math.max(1, cnt));
        double gamma = Math.log(120 / 255.0) / Math.log(mean / 255.0);
        gamma = Math.max(0.15, Math.min(1.0, gamma));
        // czarny punkt: odcięcie najciemniejszego szumu
        int black = (int) Math.min(6, mean * 0.25);
        byte[] lut = new byte[4096];
        for (int i = 0; i < 4096; i++) {
            double x = Math.max(0, i / 16.0 - black) / (255.0 - black);
            double v = Math.pow(x, gamma) * 255.0 * 1.05;
            lut[i] = (byte) Math.max(0, Math.min(255, (int) v));
        }
        int cw = r.width(), ch = r.height();
        if (acc == null || accRect == null || !accRect.equals(r)) {
            acc = new int[cw * ch];
            accRect = new Rect(r);
            for (int y = 0; y < ch; y++)
                for (int x = 0; x < cw; x++) acc[y * cw + x] = (d[(y + r.top) * w + x + r.left] & 255) << 4;
        }
        int[] a = acc;
        for (int y = 0; y < ch; y++) {
            int row = (y + r.top) * w + r.left, ar = y * cw;
            for (int x = 0; x < cw; x++) {
                int cur = (d[row + x] & 255) << 4;
                int prev = a[ar + x];
                // przy dużej zmianie (ruch) szybciej doganiaj obraz, żeby nie było smug
                int v = Math.abs(cur - prev) > 640 ? (prev + cur) >> 1 : (prev * 3 + cur) >> 2;
                a[ar + x] = v;
                d[row + x] = lut[Math.min(4095, v)];
            }
        }
        int uvStart = w * h;
        for (int y = r.top / 2; y < r.bottom / 2; y++) {
            int row = uvStart + y * w;
            for (int x = r.left; x < r.right; x++) d[row + x] = (byte) 128;
        }
    }

    private Bitmap grayBitmap(byte[] d, int w, Rect r) {
        int cw = r.width(), ch = r.height();
        if (argb == null || argb.length != cw * ch) argb = new int[cw * ch];
        int[] px = argb;
        for (int y = 0; y < ch; y++) {
            int row = (y + r.top) * w + r.left, o = y * cw;
            for (int x = 0; x < cw; x++) {
                int g = d[row + x] & 255;
                px[o + x] = 0xFF000000 | (g << 16) | (g << 8) | g;
            }
        }
        Bitmap b = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888);
        b.setPixels(px, 0, cw, 0, 0, cw, ch);
        return b;
    }

    private Net.Msg frameMsg(byte[] jpg, long now) {
        JSONObject o = Net.Msg.obj("frame");
        try {
            o.put("from", core.myId);
            o.put("name", core.myName);
            o.put("ts", now);
            o.put("rot", rotation);
            o.put("mirror", front);
            o.put("nv", nv);
            o.put("flash", flash);
            o.put("motion", motionOn);
            o.put("poseOn", poseOn);
            o.put("alert", now < feed.motionUntil);
            o.put("z", (double) pz.z);
            o.put("u", (double) pz.u);
            o.put("v", (double) pz.v);
            o.put("mic", micOn && audioRun);
            float[] ps = feed.pose;
            if (ps != null) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < ps.length; i++) {
                    if (i > 0) sb.append(',');
                    sb.append(Float.isNaN(ps[i]) ? "x" : String.format(Locale.US, "%.3f", ps[i]));
                }
                o.put("pose", sb.toString());
            }
        } catch (JSONException ignored) { }
        return new Net.Msg(o, jpg);
    }

    static float[] parsePose(String s) {
        if (s == null || s.isEmpty()) return null;
        String[] p = s.split(",");
        if (p.length != 66) return null;
        float[] out = new float[66];
        for (int i = 0; i < 66; i++) {
            try { out[i] = p[i].equals("x") ? Float.NaN : Float.parseFloat(p[i]); } catch (Exception e) { out[i] = Float.NaN; }
        }
        return out;
    }

    private void detectMotion(byte[] d, int w, int h, long now) {
        int step = 16, cols = w / step, rows = h / step;
        byte[] cur = new byte[cols * rows];
        for (int y = 0; y < rows; y++)
            for (int x = 0; x < cols; x++) cur[y * cols + x] = d[(y * step) * w + x * step];
        byte[] prev = prevY;
        prevY = cur;
        if (prev == null || prev.length != cur.length) return;
        long diff = 0;
        for (int i = 0; i < cur.length; i++) diff += Math.abs((cur[i] & 255) - (prev[i] & 255));
        float mean = diff / (float) cur.length;
        if (mean > 12f && now > ignoreMotionUntil && now - lastMotion > 5000) {
            lastMotion = now;
            feed.motionUntil = now + 2000;
            feed.postInvalidate();
            core.main.post(() -> core.alert("Kamera (" + core.myName + "): wykryto ruch"));
        }
    }

    // ================= dźwięk =================

    private void startAudio() {
        if (audioRun || !core.camActive) return;
        audioRun = true;
        audioThread = new Thread(this::audioLoop, "cam-audio");
        audioThread.start();
        refreshControls();
    }

    private void stopAudio() {
        audioRun = false;
        if (audioThread != null) {
            try { audioThread.join(600); } catch (InterruptedException ignored) { }
            audioThread = null;
        }
    }

    private void audioLoop() {
        final int sr = VideoRecorder.AUDIO_RATE;
        AudioRecord rec = AudioIn.open(MediaRecorder.AudioSource.CAMCORDER, sr);
        try {
            if (rec == null || rec.getState() != AudioRecord.STATE_INITIALIZED) return;
            rec.startRecording();
            short[] buf = new short[sr / 10];
            while (audioRun) {
                int r = rec.read(buf, 0, buf.length);
                if (r <= 0 || !micOn) continue;
                long pts = System.nanoTime() / 1000 - r * 1_000_000L / sr;
                VideoRecorder vr = recorder;
                if (vr != null) vr.addAudio(buf, r, pts);
                if (core.net.isConnected() && System.currentTimeMillis() - core.lastWatched < 6000) {
                    ByteBuffer bb = ByteBuffer.allocate(r * 2).order(ByteOrder.LITTLE_ENDIAN);
                    bb.asShortBuffer().put(buf, 0, r);
                    JSONObject o = Net.Msg.obj("audio");
                    try { o.put("from", core.myId); } catch (JSONException ignored) { }
                    core.net.send(new Net.Msg(o, bb.array()));
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (rec != null) {
                try { rec.stop(); } catch (Exception ignored) { }
                rec.release();
            }
            audioRun = false;
        }
    }

    // ================= nagrywanie =================

    private void toggleRec() {
        if (recorder != null) {
            final VideoRecorder r = recorder;
            recorder = null;
            feed.rec = false;
            r.stop(ok -> Gallery.finishVideo(core, act, r.file, ok, "Nagranie z kamery (" + core.myName + ")"));
        } else {
            boolean swap = rotation % 180 != 0;
            boolean hq = dev.width >= 1000;
            recW = swap ? (hq ? 720 : 480) : (hq ? 960 : 640);
            recH = swap ? (hq ? 960 : 640) : (hq ? 720 : 480);
            File f = new File(act.getCacheDir(), "Cam_" + Ui.fileStamp() + ".mp4");
            recorder = new VideoRecorder(f, recW, recH, audioRun && micOn);
            feed.rec = true;
        }
        refreshControls();
        feed.invalidate();
    }
}
