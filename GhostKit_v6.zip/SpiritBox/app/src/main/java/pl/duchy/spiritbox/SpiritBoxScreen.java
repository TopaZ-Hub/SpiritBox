package pl.duchy.spiritbox;

import android.Manifest;
import android.app.AlertDialog;
import android.media.AudioManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.Locale;

final class SpiritBoxScreen extends Screen implements RadioView.Listener {

    private static final int[] RATES = {50, 100, 150, 200, 250, 300, 400, 500};

    private final RadioView radio;
    private final SweepEngine engine;

    private int rateIdx = 2;
    private int fmTenths = 875, amKhz = 530;
    private boolean fwd = true;
    private final WordListener words;

    SpiritBoxScreen(MainActivity a) {
        super(a);
        engine = core.engine;

        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(6), dp(4), dp(6), dp(20));
        sv.addView(root);
        addView(sv);

        radio = new RadioView(a);
        radio.setListener(this);
        radio.sweepMs = RATES[rateIdx];
        radio.freq = fmText();
        root.addView(radio);

        TextView info = Ui.text(a,
                "POWER – start/stop · SWEEP RATE – szybkość skanu · FWD/REV – kierunek · AM/FM – pasmo · " +
                "BACK LIGHT – podświetlenie · MIC – fragmenty dźwięku z otoczenia (używaj słuchawek) · " +
                "REC – nagranie całej sesji · ECHO – pogłos.\n\n" +
                "AUTO – podczas skanu telefon nasłuchuje i sam wpisuje wykryte słowa do dziennika (z nagraniem). " +
                "SAVE – ręcznie zapisuje ostatnie 6 s i słowo, które usłyszałeś. Przytrzymaj SAVE, by włączyć/wyłączyć AUTO.",
                12, Ui.DIM, false);
        info.setPadding(dp(10), dp(10), dp(10), dp(8));
        root.addView(info);

        engine.setListener(type -> core.main.post(this::advanceFreq));
        words = core.words(this::onWord);
        radio.auto = core.prefs.getBoolean("words_auto", true);
    }

    @Override
    String title() {
        return "Spirit Box";
    }

    @Override
    void onShow() {
        radio.running = engine.isRunning();
        radio.mic = engine.isMic();
        radio.auto = core.prefs.getBoolean("words_auto", true);
        if (engine.isRunning() && radio.auto && !words.isActive()) startWords();
    }

    @Override
    void tick() {
        radio.level = engine.level;
        radio.battery = core.sensors.battery;
        core.sensors.refreshBattery();
        radio.invalidate();
    }

    // ================= przyciski =================

    @Override
    public void onButton(int id, boolean longPress) {
        switch (id) {
            case RadioView.B_POWER:
                if (engine.isRunning()) {
                    if (engine.isRecording()) toggleRec();
                    engine.stop();
                    words.stop();
                } else {
                    engine.setUseMic(radio.mic && act.has(Manifest.permission.RECORD_AUDIO));
                    engine.start();
                    startWords();
                }
                radio.running = engine.isRunning();
                break;
            case RadioView.B_RATE:
                rateIdx = (rateIdx + 1) % RATES.length;
                engine.setSweepMs(RATES[rateIdx]);
                radio.sweepMs = RATES[rateIdx];
                break;
            case RadioView.B_FWD:
                fwd = true;
                radio.fwd = true;
                break;
            case RadioView.B_REV:
                fwd = false;
                radio.fwd = false;
                break;
            case RadioView.B_VOLUP:
            case RadioView.B_VOLDN: {
                AudioManager am = (AudioManager) act.getSystemService(android.content.Context.AUDIO_SERVICE);
                if (am != null) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                            id == RadioView.B_VOLUP ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, 0);
                    radio.volText = String.valueOf(am.getStreamVolume(AudioManager.STREAM_MUSIC));
                    radio.volUntil = System.currentTimeMillis() + 1500;
                }
                break;
            }
            case RadioView.B_BAND:
                engine.setAmBand(!engine.isAm());
                radio.amBand = engine.isAm();
                radio.freq = radio.amBand ? amText() : fmText();
                break;
            case RadioView.B_LIGHT:
                radio.backlight = (radio.backlight + 1) % 3;
                break;
            case RadioView.B_MIC:
                if (radio.mic) {
                    radio.mic = false;
                    engine.setUseMic(false);
                } else {
                    act.withPermission(Manifest.permission.RECORD_AUDIO, () -> {
                        radio.mic = true;
                        engine.setUseMic(true);
                        core.toast("Użyj słuchawek – inaczej głośnik wraca do mikrofonu");
                        radio.invalidate();
                    });
                }
                break;
            case RadioView.B_REC:
                toggleRec();
                break;
            case RadioView.B_ECHO:
                engine.setEcho(!engine.isEcho());
                radio.echo = engine.isEcho();
                break;
            case RadioView.B_SAVE:
                if (longPress) {
                    boolean auto = !radio.auto;
                    radio.auto = auto;
                    core.prefs.edit().putBoolean("words_auto", auto).apply();
                    if (auto) startWords(); else words.stop();
                    core.toast(auto ? "Nasłuch słów włączony" : "Nasłuch słów wyłączony");
                } else {
                    askAndSave();
                }
                break;
        }
        radio.invalidate();
    }

    private void advanceFreq() {
        if (engine.isAm()) {
            amKhz += fwd ? 10 : -10;
            if (amKhz > 1710) amKhz = 530;
            if (amKhz < 530) amKhz = 1710;
            radio.freq = amText();
        } else {
            fmTenths += fwd ? 1 : -1;
            if (fmTenths > 1080) fmTenths = 875;
            if (fmTenths < 875) fmTenths = 1080;
            radio.freq = fmText();
        }
        radio.invalidate();
    }

    private String fmText() {
        String s = (fmTenths / 10) + "." + (fmTenths % 10);
        return s.length() < 5 ? " " + s : s;
    }

    private String amText() {
        String s = String.valueOf(amKhz);
        return s.length() < 4 ? " " + s : s;
    }

    private String freqLabel() {
        return engine.isAm() ? amKhz + " kHz AM" : String.format(Locale.US, "%.1f MHz FM", fmTenths / 10f);
    }

    // ================= dziennik =================

    private void startWords() {
        if (!radio.auto || !engine.isRunning()) return;
        act.withPermission(Manifest.permission.RECORD_AUDIO, () -> {
            if (engine.isRunning() && radio.auto) words.start();
        });
    }

    /** Słowo wykryte przez rozpoznawanie mowy – do dziennika z nagraniem ostatnich 4 s. */
    private void onWord(String text) {
        if (!engine.isRunning()) return;
        short[] s = engine.lastOutput(SweepEngine.SR * 4);
        core.book.addBytes("voice", "„" + text + "” · " + freqLabel() + " · auto",
                WavWriter.encode(s, SweepEngine.SR), "wav");
        core.toast("Wykryto: „" + text + "”");
    }

    private void askAndSave() {
        if (!engine.isRunning()) {
            core.toast("Najpierw włącz POWER");
            return;
        }
        final short[] s = engine.lastOutput(SweepEngine.SR * 6);
        final String f = freqLabel();
        EditText et = new EditText(act);
        et.setHint("Jakie słowo usłyszałeś?");
        new AlertDialog.Builder(act)
                .setTitle("Zapisz słowo (ostatnie 6 s)")
                .setView(et)
                .setPositiveButton("Zapisz", (d, w) -> {
                    String heard = et.getText().toString().trim();
                    String text = (heard.isEmpty() ? "(niezidentyfikowany głos)" : "„" + heard + "”") + " · " + f;
                    core.book.addBytes("voice", text, WavWriter.encode(s, SweepEngine.SR), "wav");
                    core.toast("Zapisano w dzienniku");
                })
                .setNegativeButton("Anuluj", null)
                .show();
    }

    private void toggleRec() {
        if (engine.isRecording()) {
            File f = engine.stopRecording();
            radio.rec = false;
            if (f != null) {
                core.book.addFile("audio", "Nagranie sesji Spirit Box (" + core.myName + ")", f, "wav");
                core.toast("Nagranie sesji zapisane w dzienniku");
            }
            return;
        }
        if (!engine.isRunning()) {
            core.toast("Najpierw włącz POWER");
            return;
        }
        try {
            File f = new File(act.getCacheDir(), "session_" + Ui.fileStamp() + ".wav");
            engine.startRecording(f);
            radio.rec = true;
        } catch (Exception e) {
            core.toast("Nie udało się nagrywać");
        }
    }
}
