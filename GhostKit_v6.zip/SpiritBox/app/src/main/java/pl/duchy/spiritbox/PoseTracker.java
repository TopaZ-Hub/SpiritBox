package pl.duchy.spiritbox;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.PointF;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.pose.Pose;
import com.google.mlkit.vision.pose.PoseDetection;
import com.google.mlkit.vision.pose.PoseDetector;
import com.google.mlkit.vision.pose.PoseLandmark;
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions;

import java.util.List;

/**
 * Wykrywanie sylwetki człowieka w kadrze (Google ML Kit, działa w telefonie, bez internetu).
 * Wynik: 33 punkty ciała w znormalizowanych współrzędnych obrazu (0..1), NaN = brak punktu.
 */
final class PoseTracker {

    /** Pary punktów tworzące "patyczaka". */
    static final int[][] BONES = {
            {11, 12}, {11, 13}, {13, 15}, {12, 14}, {14, 16},
            {11, 23}, {12, 24}, {23, 24},
            {23, 25}, {25, 27}, {24, 26}, {26, 28},
            {27, 31}, {28, 32}, {0, 11}, {0, 12}
    };

    private PoseDetector det;
    private volatile boolean busy = false;
    volatile float[] points; // 66 wartości: x0,y0,x1,y1...
    volatile long at = 0;

    private PoseDetector detector() {
        if (det == null) {
            det = PoseDetection.getClient(new PoseDetectorOptions.Builder()
                    .setDetectorMode(PoseDetectorOptions.STREAM_MODE).build());
        }
        return det;
    }

    /** Klatka w orientacji sensora; rot – o ile obrócić, by była pionowa; mirror – przednia kamera. */
    void submit(Bitmap src, int rot, boolean mirror) {
        if (busy || src == null) return;
        busy = true;
        try {
            float scale = 360f / Math.max(src.getWidth(), src.getHeight());
            Matrix m = new Matrix();
            m.postScale(scale, scale);
            m.postRotate(rot);
            if (mirror) m.postScale(-1, 1);
            Bitmap up = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
            final int w = up.getWidth(), h = up.getHeight();
            detector().process(InputImage.fromBitmap(up, 0))
                    .addOnSuccessListener(pose -> {
                        points = toPoints(pose, w, h);
                        at = System.currentTimeMillis();
                    })
                    .addOnCompleteListener(t -> busy = false);
        } catch (Exception e) {
            busy = false;
        }
    }

    private static float[] toPoints(Pose pose, int w, int h) {
        List<PoseLandmark> lms = pose.getAllPoseLandmarks();
        if (lms == null || lms.isEmpty()) return null;
        float[] out = new float[66];
        java.util.Arrays.fill(out, Float.NaN);
        int good = 0;
        for (PoseLandmark lm : lms) {
            int t = lm.getLandmarkType();
            if (t < 0 || t >= 33 || lm.getInFrameLikelihood() < 0.5f) continue;
            PointF p = lm.getPosition();
            out[t * 2] = p.x / w;
            out[t * 2 + 1] = p.y / h;
            good++;
        }
        return good >= 6 ? out : null;
    }

    /** Aktualne punkty (puste, jeśli starsze niż 1,5 s). */
    float[] current() {
        return System.currentTimeMillis() - at < 1500 ? points : null;
    }

    void close() {
        if (det != null) {
            try { det.close(); } catch (Exception ignored) { }
            det = null;
        }
    }
}
