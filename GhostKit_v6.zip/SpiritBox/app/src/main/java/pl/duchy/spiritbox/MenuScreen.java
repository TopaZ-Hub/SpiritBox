package pl.duchy.spiritbox;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Ekran główny – sprzęt do wyboru. */
final class MenuScreen extends Screen {

    private static final String[][][] SECTIONS = {
            {{"pomiary"},
                    {"box", "Spirit Box", "skaner FM / AM"},
                    {"emf", "Miernik EMF", "pole elektromagnetyczne"},
                    {"thermo", "Termometr", "pomiar temperatury"},
                    {"compass", "Kompas", "zakłócenia pola"},
                    {"para", "Mikrofon kierunkowy", "podsłuch dźwięków"},
                    {"motion", "Czujnik ruchu", "drgania i zbliżenie"}},
            {{"kamery"},
                    {"cam", "Kamera", "noktowizja · sylwetki"},
                    {"view", "Podgląd", "kamery drużyny"},
                    {"gate", "Bramka", "linia w przejściu"},
                    {"ext", "Kamera zewn.", "GoPro · kamera IP"}},
            {{"drużyna"},
                    {"walkie", "Krótkofalówka", "rozmowa · SOS · GPS"},
                    {"team", "Drużyna", "połącz telefony"},
                    {"book", "Dziennik", "słowa · zdjęcia · nagrania"}},
            {{"inne"},
                    {"music", "Pozytywka", "melodia"},
                    {"settings", "Ustawienia", "motyw · mikrofon · SOS"}},
    };

    private final TextView status, chip;

    MenuScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(16), dp(14), dp(16), dp(28));
        sv.addView(root);
        addView(sv);

        LinearLayout head = Ui.row(a);
        head.setGravity(Gravity.CENTER_VERTICAL);
        Icons.Logo logo = new Icons.Logo(a);
        head.addView(logo, new LinearLayout.LayoutParams(dp(56), dp(56)));
        LinearLayout ht = Ui.col(a);
        ht.setPadding(dp(12), 0, 0, 0);
        TextView h = Ui.head(a, "GHOST KIT", 28, Ui.TEXT);
        h.setLetterSpacing(0.1f);
        ht.addView(h);
        status = Ui.head(a, "", 11, Ui.DIM);
        ht.addView(status);
        head.addView(ht);
        root.addView(head);

        chip = Ui.head(a, "", 12, Ui.TEXT);
        chip.setPadding(dp(12), dp(10), dp(12), dp(10));
        chip.setOnClickListener(v -> act.open("team"));
        root.addView(chip, Ui.matchWrap(a, 0));
        ((LinearLayout.LayoutParams) chip.getLayoutParams()).topMargin = dp(16);

        int num = 0;
        for (String[][] sec : SECTIONS) {
            root.addView(Ui.section(a, sec[0][0]));
            LinearLayout row = null;
            for (int i = 1; i < sec.length; i++) {
                if ((i - 1) % 2 == 0) {
                    row = Ui.row(a);
                    root.addView(row);
                }
                String[] t = sec[i];
                num++;
                LinearLayout tile = Ui.col(a);
                tile.setPadding(dp(14), dp(14), dp(14), dp(16));
                Ui.card(tile);
                LinearLayout top = Ui.row(a);
                top.setGravity(Gravity.CENTER_VERTICAL);
                top.addView(new Icons.Tool(a, t[0]), new LinearLayout.LayoutParams(dp(34), dp(34)));
                TextView nm = Ui.head(a, String.format("%02d", num), 11, Ui.DIM);
                nm.setGravity(Gravity.END);
                top.addView(nm, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                tile.addView(top);
                TextView name = Ui.head(a, t[1].toUpperCase(), 13, Ui.TEXT);
                name.setPadding(0, dp(14), 0, dp(2));
                tile.addView(name);
                tile.addView(Ui.text(a, t[2], 12, Ui.DIM, false));
                final String key = t[0];
                tile.setOnClickListener(v -> act.open(key));
                Ui.addWeighted(row, tile);
            }
            if ((sec.length - 1) % 2 == 1 && row != null) Ui.addWeighted(row, new android.view.View(a));
        }
    }

    @Override
    String title() {
        return "";
    }

    @Override
    void tick() {
        String s = core.engine.isRunning() ? "SPIRIT BOX · SKANUJE" : "ZESTAW BADAWCZY · " + core.myName.toUpperCase();
        if (!s.contentEquals(status.getText())) status.setText(s);

        boolean on = core.net.isConnected();
        String c;
        if (core.net.connecting) c = "◌  ŁĄCZENIE…";
        else if (on) c = "●  DRUŻYNA: " + (core.members.size() + 1) + " OS." + (core.net.role == Net.HOST ? "  ·  TY JESTEŚ HOSTEM" : "");
        else c = "○  SOLO  ·  DOTKNIJ, ABY POŁĄCZYĆ TELEFONY";
        if (!c.contentEquals(chip.getText())) {
            chip.setText(c);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(8));
            g.setColor(on ? Ui.accent(0x1E) : Ui.CARD);
            g.setStroke(dp(1), on ? Ui.ACCENT : Ui.STROKE);
            chip.setBackground(g);
            chip.setTextColor(on ? Ui.ACCENT : Ui.TEXT);
        }
    }
}
