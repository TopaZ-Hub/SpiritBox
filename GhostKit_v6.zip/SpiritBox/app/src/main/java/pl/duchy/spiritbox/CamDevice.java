package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Range;
import android.util.Size;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Aparat przez Camera2: podgląd do SurfaceTexture + klatki YUV na żądanie.
 * Tryb nocny: ręczny czas naświetlania i maksymalna czułość (jeśli telefon pozwala),
 * w przeciwnym razie najniższy zakres FPS i maksymalna kompensacja ekspozycji.
 */
final class CamDevice {

    interface FrameCb { void onFrame(byte[] nv21, int w, int h); }

    static final class Lens {
        String id, label;
        boolean front;
        int orientation;
    }

    private final Context ctx;
    private final CameraManager cm;
    private HandlerThread bgThread;
    private Handler bg;
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader reader;
    private Surface preview;
    private CameraCharacteristics chars;
    private volatile boolean closing = false;

    volatile boolean torch = false, night = false;
    volatile long nightExposureNs = 250_000_000L; // 1/4 s
    volatile boolean wantFrames = false;
    volatile long frameIntervalMs = 100;
    private long lastFrame = 0;
    private FrameCb cb;
    private byte[] nv21;
    int width, height;
    Lens lens;

    CamDevice(Context c) {
        ctx = c.getApplicationContext();
        cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
    }

    static List<Lens> lenses(Context c) {
        List<Lens> out = new ArrayList<>();
        try {
            CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            int backNo = 0;
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                Integer or = ch.get(CameraCharacteristics.SENSOR_ORIENTATION);
                Lens l = new Lens();
                l.id = id;
                l.front = facing != null && facing == CameraMetadata.LENS_FACING_FRONT;
                l.orientation = or == null ? 90 : or;
                if (l.front) l.label = "PRZÓD";
                else {
                    float[] fl = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                    backNo++;
                    l.label = "TYŁ " + backNo + (fl != null && fl.length > 0 ? String.format(java.util.Locale.US, " · %.1fmm", fl[0]) : "");
                }
                out.add(l);
            }
        } catch (Exception ignored) { }
        java.util.Collections.sort(out, (a, b) -> Boolean.compare(a.front, b.front));
        return out;
    }

    /** Czy aparat pozwala ręcznie ustawić czas naświetlania i ISO. */
    boolean manual() {
        if (chars == null) return false;
        int[] caps = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        if (caps == null) return false;
        for (int c : caps) if (c == CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) return true;
        return false;
    }

    boolean hasFlash() {
        Boolean f = chars == null ? null : chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
        return f != null && f;
    }

    @SuppressWarnings("MissingPermission")
    void open(Lens l, SurfaceTexture st, int maxW, FrameCb frameCb) {
        close();
        closing = false;
        lens = l;
        cb = frameCb;
        bgThread = new HandlerThread("cam2");
        bgThread.start();
        bg = new Handler(bgThread.getLooper());
        try {
            chars = cm.getCameraCharacteristics(l.id);
            StreamConfigurationMap map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size best = null;
            if (map != null) {
                for (Size s : map.getOutputSizes(ImageFormat.YUV_420_888)) {
                    if (s.getWidth() * 3 != s.getHeight() * 4 || s.getWidth() > maxW) continue;
                    if (best == null || s.getWidth() > best.getWidth()) best = s;
                }
                if (best == null) best = map.getOutputSizes(ImageFormat.YUV_420_888)[0];
            }
            width = best != null ? best.getWidth() : 640;
            height = best != null ? best.getHeight() : 480;
            st.setDefaultBufferSize(width, height);
            preview = new Surface(st);
            reader = ImageReader.newInstance(width, height, ImageFormat.YUV_420_888, 3);
            reader.setOnImageAvailableListener(this::onImage, bg);
            cm.openCamera(l.id, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice d) {
                    if (closing) { d.close(); return; }
                    device = d;
                    createSession();
                }

                @Override
                public void onDisconnected(CameraDevice d) {
                    d.close();
                }

                @Override
                public void onError(CameraDevice d, int e) {
                    d.close();
                }
            }, bg);
        } catch (Exception e) {
            close();
        }
    }

    private void createSession() {
        try {
            device.createCaptureSession(Arrays.asList(preview, reader.getSurface()), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession s) {
                    if (closing) return;
                    session = s;
                    update();
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession s) { }
            }, bg);
        } catch (Exception ignored) { }
    }

    /** Zastosuj lampę i tryb nocny. */
    void update() {
        CameraDevice d = device;
        CameraCaptureSession s = session;
        if (d == null || s == null || closing) return;
        try {
            CaptureRequest.Builder b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(preview);
            b.addTarget(reader.getSurface());
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
            b.set(CaptureRequest.FLASH_MODE, torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            Range<Integer>[] ranges = chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            if (night) {
                b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY);
                if (manual()) {
                    Range<Long> er = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
                    Range<Integer> ir = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
                    long exp = nightExposureNs;
                    if (er != null) exp = Math.max(er.getLower(), Math.min(er.getUpper(), exp));
                    int iso = ir != null ? ir.getUpper() : 3200;
                    b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
                    b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp);
                    b.set(CaptureRequest.SENSOR_SENSITIVITY, iso);
                    b.set(CaptureRequest.SENSOR_FRAME_DURATION, exp);
                } else {
                    b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                    Range<Integer> ec = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
                    if (ec != null) b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ec.getUpper());
                    if (ranges != null) {
                        Range<Integer> low = null;
                        for (Range<Integer> r : ranges) if (low == null || r.getLower() < low.getLower()) low = r;
                        if (low != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, low);
                    }
                }
            } else {
                b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                if (ranges != null) { // ~15–20 kl./s – oszczędza baterię
                    Range<Integer> pick = null;
                    for (Range<Integer> r : ranges)
                        if (r.getUpper() <= 20 && (pick == null || r.getUpper() > pick.getUpper())) pick = r;
                    if (pick != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, pick);
                }
            }
            s.setRepeatingRequest(b.build(), null, bg);
        } catch (Exception ignored) { }
    }

    private void onImage(ImageReader r) {
        Image img = r.acquireLatestImage();
        if (img == null) return;
        try {
            long now = System.currentTimeMillis();
            if (!wantFrames || now - lastFrame < frameIntervalMs || cb == null) return;
            lastFrame = now;
            int w = img.getWidth(), h = img.getHeight();
            if (nv21 == null || nv21.length != w * h * 3 / 2) nv21 = new byte[w * h * 3 / 2];
            toNv21(img, nv21, w, h);
            cb.onFrame(nv21, w, h);
        } catch (Exception ignored) {
        } finally {
            img.close();
        }
    }

    private static void toNv21(Image img, byte[] out, int w, int h) {
        Image.Plane[] p = img.getPlanes();
        ByteBuffer y = p[0].getBuffer(), u = p[1].getBuffer(), v = p[2].getBuffer();
        int yRow = p[0].getRowStride();
        if (yRow == w) {
            y.get(out, 0, Math.min(w * h, y.remaining()));
        } else {
            for (int r = 0; r < h; r++) {
                y.position(r * yRow);
                y.get(out, r * w, w);
            }
        }
        int uvRow = p[1].getRowStride(), uvPix = p[1].getPixelStride();
        int o = w * h;
        for (int r = 0; r < h / 2; r++) {
            for (int c = 0; c < w / 2; c++) {
                int i = r * uvRow + c * uvPix;
                out[o++] = v.get(i);
                out[o++] = u.get(i);
            }
        }
    }

    void close() {
        closing = true;
        try { if (session != null) session.close(); } catch (Exception ignored) { }
        session = null;
        try { if (device != null) device.close(); } catch (Exception ignored) { }
        device = null;
        try { if (reader != null) reader.close(); } catch (Exception ignored) { }
        reader = null;
        if (preview != null) preview.release();
        preview = null;
        if (bgThread != null) {
            bgThread.quitSafely();
            bgThread = null;
        }
    }

    @SuppressWarnings("unused")
    private static void ignore(CameraAccessException e) { }
}
