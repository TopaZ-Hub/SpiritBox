package pl.duchy.spiritbox;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.HandlerThread;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Krótkofalówka: przytrzymaj i mów – głos idzie na żywo do całej drużyny. */
final class Ptt {
    private static final int SR = 16000;

    private final Core core;
    private volatile boolean talking = false;
    private Thread recThread;
    private HandlerThread playThread;
    private Handler ph;
    private AudioTrack track;
    volatile String speaker = null;
    volatile long speakerAt = 0;

    Ptt(Core core) {
        this.core = core;
    }

    boolean isTalking() {
        return talking;
    }

    /** Imię osoby, która właśnie mówi (albo null). */
    String speaking() {
        return System.currentTimeMillis() - speakerAt < 700 ? speaker : null;
    }

    void down() {
        if (talking) return;
        if (!core.net.isConnected()) {
            core.toast("Krótkofalówka działa po połączeniu w drużynę");
            return;
        }
        talking = true;
        core.vibrate(40);
        send("ptt_start", null);
        recThread = new Thread(this::recLoop, "ptt-rec");
        recThread.start();
    }

    void up() {
        if (!talking) return;
        talking = false;
        core.vibrate(25);
        send("ptt_end", null);
    }

    private void recLoop() {
        AudioRecord rec = AudioIn.open(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SR);
        try {
            if (rec == null || rec.getState() != AudioRecord.STATE_INITIALIZED) return;
            rec.startRecording();
            short[] buf = new short[SR / 10];
            while (talking) {
                int r = rec.read(buf, 0, buf.length);
                if (r <= 0) continue;
                ByteBuffer bb = ByteBuffer.allocate(r * 2).order(ByteOrder.LITTLE_ENDIAN);
                bb.asShortBuffer().put(buf, 0, r);
                send("ptt", bb.array());
            }
        } catch (Exception ignored) {
        } finally {
            if (rec != null) {
                try { rec.stop(); } catch (Exception ignored) { }
                rec.release();
            }
        }
    }

    private void send(String type, byte[] bin) {
        JSONObject o = Net.Msg.obj(type);
        try {
            o.put("from", core.myId);
            o.put("name", core.myName);
        } catch (JSONException ignored) { }
        core.net.send(new Net.Msg(o, bin));
    }

    /** Odbiór z sieci. */
    void onMsg(Net.Msg m) {
        ensurePlayer();
        String t = m.type();
        speaker = m.j.optString("name");
        speakerAt = System.currentTimeMillis();
        if (t.equals("ptt_start")) ph.post(() -> tone(1400, 60));
        else if (t.equals("ptt_end")) ph.post(() -> { tone(1000, 50); tone(1400, 70); });
        else if (m.bin != null) {
            final byte[] data = m.bin;
            ph.post(() -> {
                int n = data.length / 2;
                short[] pcm = new short[n];
                ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(pcm);
                AudioTrack tr = track;
                if (tr != null) tr.write(pcm, 0, n);
            });
        }
    }

    private void ensurePlayer() {
        if (playThread != null) return;
        playThread = new HandlerThread("ptt-play");
        playThread.start();
        ph = new Handler(playThread.getLooper());
        ph.post(() -> {
            try {
                int minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                        .setBufferSizeInBytes(Math.max(minBuf * 3, SR / 2))
                        .setTransferMode(AudioTrack.MODE_STREAM).build();
                track.play();
            } catch (Exception e) {
                track = null;
            }
        });
    }

    /** Krótki sygnał jak w krótkofalówce. */
    private void tone(int f, int ms) {
        AudioTrack tr = track;
        if (tr == null) return;
        int n = SR * ms / 1000;
        short[] s = new short[n];
        for (int i = 0; i < n; i++) {
            double env = Math.min(1, Math.min(i, n - i) / 80.0);
            s[i] = (short) (Math.sin(2 * Math.PI * f * i / SR) * 6000 * env);
        }
        tr.write(s, 0, n);
    }
}
