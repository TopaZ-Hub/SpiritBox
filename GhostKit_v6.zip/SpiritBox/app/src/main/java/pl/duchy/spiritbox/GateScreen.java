package pl.duchy.spiritbox;

import android.Manifest;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/**
 * Bramka: telefon patrzy na przejście (drzwi, korytarz, schody). Na obrazie jest linia –
 * gdy coś ją przetnie, włącza się alarm dla drużyny i zapisuje się zdjęcie w dzienniku.
 */
final class GateScreen extends Screen implements TextureView.SurfaceTextureListener {

    private static final float[] SENS = {28f, 18f, 11f};
    private static final String[] SENS_NAMES = {"NISKA", "ŚREDNIA", "WYSOKA"};

    private final TextureView tex;
    private final Line line;
    private final Button armBtn, orientBtn, sensBtn;
    private final TextView status;
    private final CamDevice dev;
    private SurfaceTexture surface;
    private CamDevice.Lens lens;
    private ToneGenerator tone;
    private volatile boolean armed = false;
    private volatile long armAt = 0, lastTrigger = 0;
    private volatile int sens = 1;
    private int count = 0;
    private int[] prev;

    GateScreen(MainActivity a) {
        super(a);
        dev = new CamDevice(a);
        try { tone = new ToneGenerator(AudioManager.STREAM_ALARM, 90); } catch (RuntimeException ignored) { }
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        sv.addView(root);
        addView(sv);

        FrameLayout box = new FrameLayout(a);
        tex = new TextureView(a);
        tex.setSurfaceTextureListener(this);
        line = new Line(a);
        box.addView(tex, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        box.addView(line, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        root.addView(box);

        LinearLayout panel = Ui.col(a);
        panel.setPadding(dp(12), dp(12), dp(12), dp(20));
        root.addView(panel);
        status = Ui.head(a, "", 14, Ui.TEXT);
        status.setPadding(0, 0, 0, dp(8));
        panel.addView(status);
        LinearLayout r = Ui.row(a);
        armBtn = Ui.btn(a, "");
        armBtn.setOnClickListener(v -> {
            armed = !armed;
            armAt = System.currentTimeMillis() + 3000;
            prev = null;
            refresh();
        });
        orientBtn = Ui.btn(a, "");
        orientBtn.setOnClickListener(v -> { line.vertical = !line.vertical; prev = null; line.invalidate(); refresh(); });
        sensBtn = Ui.btn(a, "");
        sensBtn.setOnClickListener(v -> { sens = (sens + 1) % 3; refresh(); });
        Ui.addWeighted(r, armBtn);
        Ui.addWeighted(r, orientBtn);
        Ui.addWeighted(r, sensBtn);
        panel.addView(r);
        panel.addView(Ui.text(a, "Ustaw telefon nieruchomo, tak by widział przejście. Przesuń linię palcem w miejsce, " +
                "przez które ktoś musiałby przejść, i uzbrój bramkę. Każde przecięcie: alarm u całej drużyny + zdjęcie " +
                "w dzienniku. Telefon możesz zostawić podłączony do ładowarki.", 12, Ui.DIM, false));
        refresh();
    }

    private void refresh() {
        armBtn.setText(armed ? "■ ROZBRÓJ" : "▶ UZBRÓJ");
        Ui.active(armBtn, armed);
        orientBtn.setText(line.vertical ? "LINIA: PION" : "LINIA: POZIOM");
        sensBtn.setText("CZUŁOŚĆ: " + SENS_NAMES[sens]);
    }

    @Override
    String title() {
        return "Bramka";
    }

    @Override
    void onShow() {
        act.withPermission(Manifest.permission.CAMERA, this::openCam);
    }

    @Override
    void onHide() {
        dev.close();
    }

    @Override
    void tick() {
        long now = System.currentTimeMillis();
        String s;
        if (!armed) s = "○ ROZBROJONA · PRZEJŚĆ: " + count;
        else if (now < armAt) s = "◌ UZBRAJANIE…";
        else s = "● CZUWA · PRZEJŚĆ: " + count;
        if (!s.contentEquals(status.getText())) status.setText(s);
        line.hot = now - lastTrigger < 2000;
        line.armed = armed && now >= armAt;
        line.invalidate();
    }

    private void openCam() {
        if (surface == null) return;
        List<CamDevice.Lens> ls = CamDevice.lenses(act);
        if (ls.isEmpty()) return;
        lens = ls.get(0);
        dev.wantFrames = true;
        dev.frameIntervalMs = 90;
        dev.open(lens, surface, 640, this::onFrame);
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
        surface = st;
        if (act.has(Manifest.permission.CAMERA)) openCam();
    }

    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        surface = null;
        dev.close();
        return true;
    }

    @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }

    /** Próbki jasności wzdłuż linii (przeliczone z ekranu na układ sensora). */
    private void onFrame(byte[] d, int w, int h) {
        if (lens == null) return;
        int n = 120;
        int[] cur = new int[n];
        float pos = line.pos;
        for (int i = 0; i < n; i++) {
            float t = (i + 0.5f) / n;
            int sum = 0;
            for (int k = -1; k <= 1; k++) {
                float u = line.vertical ? pos + k * 0.006f : t, v = line.vertical ? t : pos + k * 0.006f;
                if (lens.front) u = 1 - u;
                float sx, sy;
                switch (lens.orientation) {
                    case 90: sx = v; sy = 1 - u; break;
                    case 270: sx = 1 - v; sy = u; break;
                    case 180: sx = 1 - u; sy = 1 - v; break;
                    default: sx = u; sy = v;
                }
                int x = Math.max(0, Math.min(w - 1, (int) (sx * w))), y = Math.max(0, Math.min(h - 1, (int) (sy * h)));
                sum += d[y * w + x] & 255;
            }
            cur[i] = sum / 3;
        }
        int[] p = prev;
        prev = cur;
        long now = System.currentTimeMillis();
        if (p == null || !armed || now < armAt) return;
        // ile próbek mocno się zmieniło (odporne na powolne zmiany światła)
        int changed = 0;
        long total = 0;
        for (int i = 0; i < n; i++) {
            int dd = Math.abs(cur[i] - p[i]);
            total += dd;
            if (dd > SENS[sens]) changed++;
        }
        float mean = total / (float) n;
        if (changed > n * 0.08f && mean < 120 && now - lastTrigger > 3000) {
            lastTrigger = now;
            core.main.post(this::trigger);
        }
    }

    private void trigger() {
        count++;
        if (tone != null) tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 600);
        core.vibrate(300);
        core.alert("Bramka (" + core.myName + "): coś przecięło linię");
        try {
            Bitmap b = tex.getBitmap();
            if (b != null) {
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.JPEG, 85, bo);
                core.book.addBytes("photo", "Bramka: przejście #" + count + " · " + Ui.stamp(System.currentTimeMillis())
                        + " (" + core.myName + ")", bo.toByteArray(), "jpg");
            }
        } catch (Exception ignored) { }
    }

    /** Linia bramki (przesuwana palcem). */
    final class Line extends View {
        volatile float pos = 0.5f;
        volatile boolean vertical = true, hot, armed;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Line(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w);
            setMeasuredDimension(W, W * 4 / 3);
        }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), H = getHeight(), u = W / 100f;
            int col = hot ? 0xFFFF2A2A : armed ? Ui.ACCENT : 0xAAFFFFFF;
            p.setColor((col & 0x00FFFFFF) | 0x44000000);
            p.setStrokeWidth(4 * u);
            if (vertical) c.drawLine(pos * W, 0, pos * W, H, p);
            else c.drawLine(0, pos * H, W, pos * H, p);
            p.setColor(col);
            p.setStrokeWidth(0.8f * u);
            if (vertical) c.drawLine(pos * W, 0, pos * W, H, p);
            else c.drawLine(0, pos * H, W, pos * H, p);
            p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            p.setTextSize(4 * u);
            p.setShadowLayer(u * 0.6f, 0, 0, 0xFF000000);
            p.setColor(0xFFFFFFFF);
            c.drawText(Ui.stamp(System.currentTimeMillis()), 4 * u, 8 * u, p);
            if (hot) {
                p.setColor(0xFFFF2A2A);
                p.setTextSize(7 * u);
                c.drawText("▲ PRZEJŚCIE", 4 * u, H - 6 * u, p);
            }
            p.clearShadowLayer();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN && getParent() != null)
                getParent().requestDisallowInterceptTouchEvent(true);
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN || e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                pos = Math.max(0.05f, Math.min(0.95f, vertical ? e.getX() / getWidth() : e.getY() / getHeight()));
                prev = null;
                invalidate();
            }
            return true;
        }
    }
}
