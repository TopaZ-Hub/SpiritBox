package pl.duchy.spiritbox;

import android.widget.FrameLayout;

/** Jeden "ekran" (narzędzie) wewnątrz głównej aktywności. */
abstract class Screen extends FrameLayout {
    final MainActivity act;
    final Core core;

    Screen(MainActivity a) {
        super(a);
        act = a;
        core = Core.get(a);
        setBackgroundColor(Ui.BG);
    }

    abstract String title();

    /** Ekran pojawił się (lub aplikacja wróciła na pierwszy plan). Może być wołane wielokrotnie. */
    void onShow() { }

    /** Ekran znika (lub aplikacja idzie w tło). Może być wołane wielokrotnie. */
    void onHide() { }

    /** Wywoływane ~15 razy na sekundę, gdy ekran jest widoczny. */
    void tick() { }

    int dp(float v) {
        return Ui.dp(getContext(), v);
    }
}
