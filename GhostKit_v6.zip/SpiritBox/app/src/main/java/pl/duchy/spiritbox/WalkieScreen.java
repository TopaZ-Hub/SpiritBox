package pl.duchy.spiritbox;

import android.Manifest;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/** Krótkofalówka, SOS i położenie drużyny. */
final class WalkieScreen extends Screen {

    private final BigButton talk, sos;
    private final TextView state;
    private final LinearLayout list;
    private final Button gpsBtn;
    private long sosDown = 0;
    private String listSig = "";

    WalkieScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(16), dp(8), dp(16), dp(28));
        sv.addView(root);
        addView(sv);

        state = Ui.head(a, "", 14, Ui.TEXT);
        state.setGravity(Gravity.CENTER);
        state.setPadding(0, 0, 0, dp(12));
        root.addView(state);

        talk = new BigButton(a, "PRZYTRZYMAJ\nI MÓW", Ui.ACCENT);
        talk.setOnTouchListener((v, e) -> {
            int ac = e.getActionMasked();
            if (ac == MotionEvent.ACTION_DOWN) {
                if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
                if (!act.has(Manifest.permission.RECORD_AUDIO)) {
                    act.withPermission(Manifest.permission.RECORD_AUDIO, () -> core.toast("Teraz przytrzymaj, by mówić"));
                    return true;
                }
                core.ptt.down();
                talk.pressed = true;
            } else if (ac == MotionEvent.ACTION_UP || ac == MotionEvent.ACTION_CANCEL) {
                core.ptt.up();
                talk.pressed = false;
            }
            talk.invalidate();
            return true;
        });
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220));
        root.addView(talk, tl);

        sos = new BigButton(a, "SOS\n(przytrzymaj 2 s)", Ui.RED);
        sos.setOnTouchListener((v, e) -> {
            int ac = e.getActionMasked();
            if (ac == MotionEvent.ACTION_DOWN) {
                if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
                sosDown = System.currentTimeMillis();
                sos.pressed = true;
            } else if (ac == MotionEvent.ACTION_UP || ac == MotionEvent.ACTION_CANCEL) {
                sosDown = 0;
                sos.pressed = false;
                sos.progress = 0;
            }
            sos.invalidate();
            return true;
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(110));
        sl.topMargin = dp(16);
        root.addView(sos, sl);

        root.addView(Ui.section(a, "lokalizacja"));
        gpsBtn = Ui.btn(a, "");
        gpsBtn.setOnClickListener(v -> toggleGps());
        root.addView(gpsBtn, Ui.matchWrap(a, 2));
        root.addView(Ui.text(a, "Lokalizacja jest wysyłana drużynie tylko, gdy ją włączysz. " +
                "SOS zawsze dołącza twoje położenie, jeśli GPS jest włączony.", 12, Ui.DIM, false));

        root.addView(Ui.section(a, "drużyna"));
        list = Ui.col(a);
        root.addView(list);
        refreshGps();
    }

    private void toggleGps() {
        boolean on = !core.prefs.getBoolean("gps_share", false);
        if (on) {
            act.withPermission(Manifest.permission.ACCESS_FINE_LOCATION, () -> {
                core.prefs.edit().putBoolean("gps_share", true).apply();
                core.geo.start();
                refreshGps();
            });
        } else {
            core.prefs.edit().putBoolean("gps_share", false).apply();
            core.geo.stop();
            refreshGps();
        }
    }

    private void refreshGps() {
        boolean on = core.prefs.getBoolean("gps_share", false);
        gpsBtn.setText(on ? "UDOSTĘPNIAM LOKALIZACJĘ: WŁ" : "UDOSTĘPNIAM LOKALIZACJĘ: WYŁ");
        Ui.active(gpsBtn, on);
    }

    @Override
    String title() {
        return "Krótkofalówka";
    }

    @Override
    void tick() {
        long now = System.currentTimeMillis();
        if (sosDown > 0) {
            sos.progress = Math.min(1f, (now - sosDown) / 2000f);
            sos.invalidate();
            if (now - sosDown >= 2000) {
                sosDown = 0;
                sos.pressed = false;
                sos.progress = 0;
                core.sos();
            }
        }
        String sp = core.ptt.speaking();
        String st;
        if (!core.net.isConnected()) st = "○ BRAK DRUŻYNY – POŁĄCZ TELEFONY";
        else if (core.ptt.isTalking()) st = "● NADAJESZ";
        else if (sp != null) st = "◉ MÓWI: " + sp.toUpperCase(Locale.getDefault());
        else st = "KANAŁ DRUŻYNY · " + (core.members.size() + 1) + " OS.";
        if (!st.contentEquals(state.getText())) {
            state.setText(st);
            state.setTextColor(sp != null || core.ptt.isTalking() ? Ui.ACCENT : Ui.TEXT);
        }
        if (now % 1000 < 70) rebuildList();
    }

    private void rebuildList() {
        StringBuilder sig = new StringBuilder();
        for (Core.Member m : core.members.values()) sig.append(m.id).append(m.lat).append(m.lon);
        sig.append(core.geo.lat).append(core.geo.lon);
        if (sig.toString().equals(listSig)) return;
        listSig = sig.toString();
        list.removeAllViews();
        if (core.members.isEmpty()) list.addView(Ui.text(act, "Nikogo poza tobą.", 13, Ui.DIM, false));
        for (Core.Member m : core.members.values()) {
            LinearLayout row = Ui.row(act);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(6), 0, dp(6));
            String info;
            boolean loc = !Double.isNaN(m.lat);
            if (!loc) info = "lokalizacja wyłączona";
            else if (core.geo.has()) {
                float[] d = Geo.distance(core.geo.lat, core.geo.lon, m.lat, m.lon);
                info = String.format(Locale.US, "%.0f m · kierunek %s", d[0], dir(d[1]));
            } else info = "lokalizacja dostępna";
            LinearLayout t = Ui.col(act);
            t.addView(Ui.head(act, m.name.toUpperCase(Locale.getDefault()), 14, Ui.TEXT));
            t.addView(Ui.text(act, info, 12, Ui.DIM, false));
            row.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            if (loc) {
                Button map = Ui.btn(act, "MAPA");
                final double la = m.lat, lo = m.lon;
                final String nm = m.name;
                map.setOnClickListener(v -> act.openMap(la, lo, nm));
                row.addView(map);
            }
            list.addView(row);
        }
    }

    private static String dir(float bearing) {
        String[] n = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        int i = Math.round(((bearing % 360) + 360) % 360 / 45f) % 8;
        return n[i];
    }

    static final class BigButton extends View {
        final String label;
        final int color;
        boolean pressed;
        float progress;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        BigButton(android.content.Context c, String label, int color) {
            super(c);
            this.label = label;
            this.color = color;
        }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), H = getHeight(), r = Math.min(W, H) / 2f - 6;
            float cx = W / 2f, cy = H / 2f;
            p.setShader(new RadialGradient(cx, cy - r * 0.3f, r * 1.3f,
                    pressed ? color : (color & 0x00FFFFFF) | 0x55000000, 0xFF0E0F12, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(4);
            p.setColor(color);
            c.drawCircle(cx, cy, r, p);
            if (progress > 0) {
                p.setStrokeWidth(10);
                c.drawArc(new android.graphics.RectF(cx - r + 8, cy - r + 8, cx + r - 8, cy + r - 8), -90, 360 * progress, false, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(pressed ? 0xFFFFFFFF : Ui.TEXT);
            p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            p.setTextAlign(Paint.Align.CENTER);
            String[] lines = label.split("\n");
            p.setTextSize(r * 0.2f);
            float y = cy - (lines.length - 1) * r * 0.13f;
            for (int i = 0; i < lines.length; i++) {
                p.setTextSize(i == 0 ? r * 0.2f : r * 0.11f);
                c.drawText(lines[i], cx, y + i * r * 0.26f + r * 0.06f, p);
            }
        }
    }
}
