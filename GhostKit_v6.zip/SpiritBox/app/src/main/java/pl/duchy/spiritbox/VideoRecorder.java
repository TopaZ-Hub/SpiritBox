package pl.duchy.spiritbox;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.Surface;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Nagrywa klatki (Bitmap) + dźwięk (PCM 16 kHz mono) do pliku MP4 (H.264 + AAC) sprzętowymi koderami.
 * Znaczniki czasu: obraz i dźwięk w tym samym zegarze (System.nanoTime).
 */
final class VideoRecorder {

    static final int AUDIO_RATE = 16000;

    interface Done { void onDone(boolean ok); }

    final File file;
    private final int vw, vh;
    private boolean audio;
    private final HandlerThread th = new HandlerThread("video-rec");
    private final Handler h;
    private final AtomicInteger pending = new AtomicInteger();
    private final MediaCodec.BufferInfo vInfo = new MediaCodec.BufferInfo();
    private final MediaCodec.BufferInfo aInfo = new MediaCodec.BufferInfo();
    private MediaCodec vCodec, aCodec;
    private MediaMuxer mux;
    private Surface surface;
    private MediaFormat vFmt, aFmt;
    private long vFmtAt = 0;
    private int vTrack = -1, aTrack = -1;
    private boolean muxing = false;
    private volatile boolean failed = false;
    private int frames = 0;
    private long lastAPts = -1;

    VideoRecorder(File f, int w, int h, boolean withAudio) {
        file = f;
        vw = w;
        vh = h;
        audio = withAudio;
        th.start();
        this.h = new Handler(th.getLooper());
        this.h.post(this::init);
    }

    private void init() {
        try {
            MediaFormat fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, vw, vh);
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 3_000_000);
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE, 15);
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            vCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            vCodec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            surface = vCodec.createInputSurface();
            vCodec.start();
            mux = new MediaMuxer(file.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        } catch (Exception e) {
            failed = true;
            return;
        }
        if (audio) {
            try {
                MediaFormat af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, AUDIO_RATE, 1);
                af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
                af.setInteger(MediaFormat.KEY_BIT_RATE, 64000);
                af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
                aCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
                aCodec.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                aCodec.start();
            } catch (Exception e) {
                audio = false;
                aCodec = null;
            }
        }
    }

    void addFrame(Bitmap b) {
        if (failed || pending.get() > 3) return;
        pending.incrementAndGet();
        h.post(() -> {
            pending.decrementAndGet();
            if (failed || surface == null) return;
            try {
                Canvas c = surface.lockHardwareCanvas();
                c.drawColor(Color.BLACK);
                c.drawBitmap(b, null, new Rect(0, 0, vw, vh), null);
                surface.unlockCanvasAndPost(c);
                frames++;
                drain(vCodec, vInfo, true, false);
            } catch (Exception e) {
                failed = true;
            }
        });
    }

    /** PCM 16 kHz mono; ptsUs w zegarze System.nanoTime()/1000 (początek fragmentu). */
    void addAudio(short[] pcm, int n, long ptsUs) {
        if (failed || !audio) return;
        final short[] copy = new short[n];
        System.arraycopy(pcm, 0, copy, 0, n);
        h.post(() -> {
            if (failed || !audio || aCodec == null) return;
            try {
                int off = 0;
                long pts = ptsUs;
                while (off < copy.length) {
                    int idx = aCodec.dequeueInputBuffer(5000);
                    if (idx < 0) break;
                    ByteBuffer ib = aCodec.getInputBuffer(idx);
                    if (ib == null) break;
                    ib.clear();
                    int count = Math.min(copy.length - off, ib.remaining() / 2);
                    ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(copy, off, count);
                    if (pts <= lastAPts) pts = lastAPts + 1;
                    lastAPts = pts;
                    aCodec.queueInputBuffer(idx, 0, count * 2, pts, 0);
                    off += count;
                    pts += count * 1_000_000L / AUDIO_RATE;
                }
                drain(aCodec, aInfo, false, false);
            } catch (Exception e) {
                audio = false;
            }
        });
    }

    void stop(Done done) {
        h.post(() -> {
            boolean ok = false;
            try {
                if (vCodec != null && !failed) {
                    vCodec.signalEndOfInputStream();
                    drain(vCodec, vInfo, true, true);
                }
                if (aCodec != null && audio) {
                    int idx = aCodec.dequeueInputBuffer(10000);
                    if (idx >= 0) aCodec.queueInputBuffer(idx, 0, 0, lastAPts + 1, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    drain(aCodec, aInfo, false, true);
                }
            } catch (Exception e) {
                failed = true;
            }
            release(vCodec);
            release(aCodec);
            if (surface != null) surface.release();
            try {
                if (muxing) {
                    mux.stop();
                    ok = !failed && frames > 0;
                }
            } catch (Exception e) {
                ok = false;
            }
            try { if (mux != null) mux.release(); } catch (Exception ignored) { }
            final boolean result = ok;
            new Handler(Looper.getMainLooper()).post(() -> done.onDone(result));
            th.quitSafely();
        });
    }

    private static void release(MediaCodec c) {
        if (c == null) return;
        try { c.stop(); } catch (Exception ignored) { }
        try { c.release(); } catch (Exception ignored) { }
    }

    /** Muxer startuje, gdy znamy format obrazu i dźwięku (albo po 1,5 s bez dźwięku – wtedy samo wideo). */
    private void maybeStartMux() {
        if (muxing || vFmt == null) return;
        boolean audioReady = !audio || aFmt != null;
        if (!audioReady && System.currentTimeMillis() - vFmtAt > 1500) {
            audio = false;
            audioReady = true;
        }
        if (!audioReady) return;
        vTrack = mux.addTrack(vFmt);
        if (audio && aFmt != null) aTrack = mux.addTrack(aFmt);
        mux.start();
        muxing = true;
    }

    private void drain(MediaCodec codec, MediaCodec.BufferInfo info, boolean video, boolean end) {
        int tries = 0;
        while (true) {
            int idx = codec.dequeueOutputBuffer(info, end ? 10000 : 0);
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end || ++tries > 100) break;
            } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (video) {
                    vFmt = codec.getOutputFormat();
                    vFmtAt = System.currentTimeMillis();
                } else {
                    aFmt = codec.getOutputFormat();
                }
                maybeStartMux();
            } else if (idx >= 0) {
                maybeStartMux();
                ByteBuffer bb = codec.getOutputBuffer(idx);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                int track = video ? vTrack : aTrack;
                if (info.size > 0 && muxing && track >= 0 && bb != null) {
                    bb.position(info.offset);
                    bb.limit(info.offset + info.size);
                    mux.writeSampleData(track, bb, info);
                }
                codec.releaseOutputBuffer(idx, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
    }
}
