package pl.duchy.spiritbox;

import android.content.Context;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import java.util.ArrayList;
import java.util.List;

/** Wspólne otwieranie mikrofonu – z obsługą wybranego mikrofonu zewnętrznego (USB / przewodowy / Bluetooth). */
final class AudioIn {

    static volatile int preferredId = -1;
    private static Context app;

    static void init(Context c, int id) {
        app = c.getApplicationContext();
        preferredId = id;
    }

    static AudioRecord open(int source, int rate) {
        int minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        int size = Math.max(minBuf, rate);
        AudioRecord r = null;
        try {
            r = new AudioRecord(source, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size);
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                r.release();
                r = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, size);
            }
            AudioDeviceInfo d = preferred();
            if (d != null) r.setPreferredDevice(d);
        } catch (Exception ignored) { }
        return r;
    }

    static AudioDeviceInfo preferred() {
        if (preferredId < 0 || app == null) return null;
        for (AudioDeviceInfo d : inputs(app)) if (d.getId() == preferredId) return d;
        return null;
    }

    static List<AudioDeviceInfo> inputs(Context c) {
        List<AudioDeviceInfo> out = new ArrayList<>();
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return out;
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_INPUTS)) {
            if (d.getType() == AudioDeviceInfo.TYPE_TELEPHONY) continue;
            out.add(d);
        }
        return out;
    }

    static String name(AudioDeviceInfo d) {
        String t;
        switch (d.getType()) {
            case AudioDeviceInfo.TYPE_BUILTIN_MIC: t = "Wbudowany mikrofon"; break;
            case AudioDeviceInfo.TYPE_WIRED_HEADSET: t = "Mikrofon przewodowy (jack)"; break;
            case AudioDeviceInfo.TYPE_USB_DEVICE:
            case AudioDeviceInfo.TYPE_USB_HEADSET:
            case AudioDeviceInfo.TYPE_USB_ACCESSORY: t = "Mikrofon USB"; break;
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: t = "Mikrofon Bluetooth"; break;
            default: t = "Wejście audio";
        }
        CharSequence pn = d.getProductName();
        return t + (pn != null && pn.length() > 0 ? " · " + pn : "") + " (#" + d.getId() + ")";
    }

    /** Czy podłączone są słuchawki (żeby nie było sprzężenia). */
    static boolean headphones(Context c) {
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return false;
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            int t = d.getType();
            if (t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == AudioDeviceInfo.TYPE_WIRED_HEADSET
                    || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_USB_HEADSET) return true;
        }
        return false;
    }
}
