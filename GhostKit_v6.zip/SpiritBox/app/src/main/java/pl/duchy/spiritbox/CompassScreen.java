package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/**
 * Kompas magnetyczny. Gdy w pobliżu pojawi się źródło pola magnetycznego (magnes, prąd, metal),
 * igła realnie się odchyla, a czerwona strzałka pokazuje kierunek zakłócenia i jego siłę.
 */
final class CompassScreen extends Screen {

    private final Dial dial;
    private final TextView readout;
    private float shown = 0f, needleVel = 0f;
    private long lastEvent = 0;

    CompassScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(14), dp(4), dp(14), dp(28));
        sv.addView(root);
        addView(sv);
        dial = new Dial(a);
        root.addView(dial);
        readout = Ui.head(a, "", 15, Ui.TEXT);
        readout.setGravity(Gravity.CENTER);
        readout.setPadding(0, dp(10), 0, dp(10));
        root.addView(readout);
        Button cal = Ui.btn(a, "KALIBRUJ TŁO");
        cal.setOnClickListener(v -> {
            core.sensors.calibrate();
            core.toast("Tło magnetyczne zapamiętane");
        });
        root.addView(cal, Ui.matchWrap(a, 2));
        root.addView(Ui.text(a, "Połóż telefon płasko i skalibruj tło z dala od metalu. Igła wskazuje północ magnetyczną; " +
                "gdy w pobliżu pojawi się dodatkowe pole, igła drga i odchyla się, a czerwona strzałka pokazuje, " +
                "z której strony przyszło zakłócenie. Jeśli kompas wariuje, zakreśl telefonem ósemkę w powietrzu.",
                12, Ui.DIM, false));
    }

    @Override
    String title() {
        return "Kompas";
    }

    @Override
    void tick() {
        Sensors s = core.sensors;
        float h = s.heading();
        if (!Float.isNaN(h)) {
            // igła z bezwładnością (sprężyna + tłumienie), jak w prawdziwym kompasie
            float target = -h;
            float diff = ((target - shown + 540f) % 360f) - 180f;
            needleVel += diff * 0.08f;
            needleVel *= 0.78f;
            shown += needleVel;
        }
        float dx = s.mx - s.bx, dy = s.my - s.by, dz = s.mz - s.bz;
        float mag = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (Float.isNaN(mag)) mag = 0;
        dial.rotation = shown;
        dial.anomaly = mag;
        // kierunek zakłócenia w płaszczyźnie ekranu (x w prawo, y w górę)
        dial.anomalyAngle = (float) Math.toDegrees(Math.atan2(dx, dy));
        dial.invalidate();
        long now = System.currentTimeMillis();
        if (mag > 25 && now - lastEvent > 15000) {
            lastEvent = now;
            core.alert(String.format(Locale.US, "Kompas: silne zakłócenie pola (%.0f µT)", mag));
        }
        String t = Float.isNaN(h) ? "BRAK MAGNETOMETRU" :
                String.format(Locale.US, "%03.0f°  %s   ·   ZAKŁÓCENIE %.1f µT", h, dir(h), mag);
        if (!t.contentEquals(readout.getText())) readout.setText(t);
    }

    private static String dir(float b) {
        String[] n = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        return n[Math.round(((b % 360) + 360) % 360 / 45f) % 8];
    }

    static final class Dial extends View {
        float rotation, anomaly, anomalyAngle;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        Dial(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w);
            setMeasuredDimension(W, W);
        }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), u = W / 100f, cx = W / 2f, cy = W / 2f;
            float R = 46 * u;
            Mat.shadowCircle(c, cx, cy, R, u);
            // mosiężna obudowa
            p.setShader(new SweepGradient(cx, cy, new int[]{0xFF8A6A2A, 0xFFE8CC7A, 0xFF7A5A20, 0xFFD8B860, 0xFF8A6A2A}, null));
            c.drawCircle(cx, cy, R, p);
            p.setShader(null);
            p.setColor(0xFF101113);
            c.drawCircle(cx, cy, R - 4 * u, p);
            // tarcza
            p.setShader(new RadialGradient(cx, cy - 10 * u, R, 0xFFF2EEE2, 0xFFCFC8B4, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, R - 5.5f * u, p);
            p.setShader(null);

            c.save();
            c.rotate(rotation, cx, cy);
            p.setColor(0xFF1A1A1A);
            for (int d = 0; d < 360; d += 5) {
                float len = d % 30 == 0 ? 4 * u : d % 10 == 0 ? 2.6f * u : 1.6f * u;
                p.setStrokeWidth(d % 30 == 0 ? 0.6f * u : 0.3f * u);
                double a = Math.toRadians(d - 90);
                float r1 = R - 6 * u, r2 = r1 - len;
                c.drawLine(cx + (float) Math.cos(a) * r1, cy + (float) Math.sin(a) * r1,
                        cx + (float) Math.cos(a) * r2, cy + (float) Math.sin(a) * r2, p);
            }
            p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            p.setTextAlign(Paint.Align.CENTER);
            String[] card = {"N", "E", "S", "W"};
            for (int i = 0; i < 4; i++) {
                double a = Math.toRadians(i * 90 - 90);
                float rr = R - 16 * u;
                p.setTextSize(7 * u);
                p.setColor(i == 0 ? 0xFFB01E1E : 0xFF1A1A1A);
                c.drawText(card[i], cx + (float) Math.cos(a) * rr, cy + (float) Math.sin(a) * rr + 2.5f * u, p);
            }
            p.setTextSize(3 * u);
            p.setColor(0xFF444444);
            for (int d = 30; d < 360; d += 30) {
                if (d % 90 == 0) continue;
                double a = Math.toRadians(d - 90);
                float rr = R - 15 * u;
                c.drawText(String.valueOf(d), cx + (float) Math.cos(a) * rr, cy + (float) Math.sin(a) * rr + u, p);
            }
            // igła (zawsze N–S tarczy)
            path.reset();
            path.moveTo(cx, cy - (R - 20 * u));
            path.lineTo(cx + 3 * u, cy);
            path.lineTo(cx - 3 * u, cy);
            path.close();
            p.setColor(0xFFC0281E);
            c.drawPath(path, p);
            path.reset();
            path.moveTo(cx, cy + (R - 20 * u));
            path.lineTo(cx + 3 * u, cy);
            path.lineTo(cx - 3 * u, cy);
            path.close();
            p.setColor(0xFFE8E8E8);
            c.drawPath(path, p);
            c.restore();

            // strzałka zakłócenia (w układzie telefonu)
            if (anomaly > 1.5f) {
                float len = Math.min(R - 12 * u, 6 * u + anomaly * 0.8f * u);
                c.save();
                c.rotate(anomalyAngle, cx, cy);
                p.setColor(0xCCFF2A2A);
                p.setStrokeWidth(1.4f * u);
                c.drawLine(cx, cy, cx, cy - len, p);
                path.reset();
                path.moveTo(cx, cy - len - 3 * u);
                path.lineTo(cx + 2.5f * u, cy - len + 1 * u);
                path.lineTo(cx - 2.5f * u, cy - len + 1 * u);
                path.close();
                c.drawPath(path, p);
                c.restore();
            }
            p.setShader(new RadialGradient(cx - u, cy - u, 3 * u, 0xFFF0DCA0, 0xFF6A5020, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, 2.4f * u, p);
            p.setShader(null);
            // szkło
            Mat.glossCircle(c, cx, cy, R - 5.5f * u);
        }
    }
}
