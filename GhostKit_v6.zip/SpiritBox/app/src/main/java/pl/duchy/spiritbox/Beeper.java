package pl.duchy.spiritbox;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

/**
 * Brzęczyk piezo jak w mierniku EMF: krótkie "pip" coraz szybsze i wyższe z poziomem,
 * a na najwyższym poziomie ciągły, falujący pisk.
 */
final class Beeper {
    private static final int SR = 22050;
    private volatile int level = 0;
    private volatile boolean running = false;
    private Thread thread;

    void setLevel(int l) {
        level = l;
    }

    synchronized void start() {
        if (running) return;
        running = true;
        thread = new Thread(this::loop, "emf-beeper");
        thread.start();
    }

    synchronized void stop() {
        running = false;
        if (thread != null) {
            try { thread.join(300); } catch (InterruptedException ignored) { }
            thread = null;
        }
    }

    private void loop() {
        int minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack t;
        try {
            t = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(minBuf, 2048))
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
        } catch (Exception e) {
            running = false;
            return;
        }
        t.play();
        short[] buf = new short[441]; // 20 ms
        double ph = 0, lp = 0;
        long sample = 0, nextPip = 0;
        int pipLeft = 0;
        while (running) {
            int lvl = level;
            for (int i = 0; i < buf.length; i++, sample++) {
                double out = 0;
                if (lvl >= 5) {
                    // ciągły pisk z lekkim "falowaniem"
                    double f = 3600 + 250 * Math.sin(2 * Math.PI * 7 * sample / SR);
                    ph += f / SR;
                    out = (ph % 1.0) < 0.5 ? 1 : -1;
                } else if (lvl > 0) {
                    if (sample >= nextPip) {
                        pipLeft = SR * 35 / 1000;
                        int interval = new int[]{0, 700, 420, 230, 120}[lvl];
                        nextPip = sample + SR * interval / 1000;
                    }
                    if (pipLeft > 0) {
                        double f = 2700 + lvl * 220;
                        ph += f / SR;
                        double env = Math.min(1.0, pipLeft / 60.0) * Math.min(1.0, (SR * 35 / 1000 - pipLeft + 1) / 40.0);
                        out = ((ph % 1.0) < 0.5 ? 1 : -1) * env;
                        pipLeft--;
                    }
                } else {
                    nextPip = sample;
                }
                lp += (out - lp) * 0.35; // zaokrąglenie prostokąta jak w membranie piezo
                buf[i] = (short) (lp * 9000);
            }
            t.write(buf, 0, buf.length);
        }
        try { t.stop(); } catch (Exception ignored) { }
        t.release();
    }
}
