package pl.duchy.spiritbox;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.BatteryManager;

/** Wszystkie czujniki telefonu w jednym miejscu. */
final class Sensors implements SensorEventListener {

    private final Context ctx;
    private final SensorManager sm;
    private final SweepEngine engine;
    final Sensor mag, acc, prox, temp, press;

    // EMF (magnetometr)
    volatile float emfTotal = 0f, emfBaseline = -1f, emfDelta = 0f;

    // ruch
    private float gx, gy, gz;
    private boolean gInit = false;
    private volatile float joltMax = 0f;
    private final long[] shakes = new long[6];
    private int shakeIdx = 0;
    private volatile boolean shaken = false;
    // surowe wektory do kompasu
    volatile float mx, my, mz, ax, ay, az;
    volatile float bx = Float.NaN, by, bz;
    volatile float proxValue = -1f;
    volatile int proxChanges = 0;

    // środowisko
    volatile float ambientTemp = Float.NaN, pressure = Float.NaN;
    private float batteryTemp = Float.NaN;
    private long lastBattery = 0;
    volatile int battery = 100;

    private int users = 0;

    Sensors(Context c, SweepEngine engine) {
        ctx = c;
        this.engine = engine;
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        mag = sm != null ? sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) : null;
        acc = sm != null ? sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) : null;
        prox = sm != null ? sm.getDefaultSensor(Sensor.TYPE_PROXIMITY) : null;
        temp = sm != null ? sm.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE) : null;
        press = sm != null ? sm.getDefaultSensor(Sensor.TYPE_PRESSURE) : null;
    }

    void start() {
        if (sm == null || users++ > 0) return;
        if (mag != null) sm.registerListener(this, mag, SensorManager.SENSOR_DELAY_GAME);
        if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME);
        if (prox != null) sm.registerListener(this, prox, SensorManager.SENSOR_DELAY_NORMAL);
        if (temp != null) sm.registerListener(this, temp, SensorManager.SENSOR_DELAY_NORMAL);
        if (press != null) sm.registerListener(this, press, SensorManager.SENSOR_DELAY_NORMAL);
    }

    void stop() {
        if (sm == null || users == 0) return;
        if (--users == 0) sm.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float[] v = e.values;
        switch (e.sensor.getType()) {
            case Sensor.TYPE_MAGNETIC_FIELD: {
                float m = (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
                emfTotal = m;
                mx = v[0]; my = v[1]; mz = v[2];
                if (Float.isNaN(bx)) { bx = mx; by = my; bz = mz; }
                else { bx += (mx - bx) * 0.002f; by += (my - by) * 0.002f; bz += (mz - bz) * 0.002f; }
                if (emfBaseline < 0) emfBaseline = m;
                else emfBaseline += (m - emfBaseline) * 0.002f;
                float d = Math.abs(m - emfBaseline);
                emfDelta += (d - emfDelta) * 0.25f;
                engine.addEntropy(m);
                break;
            }
            case Sensor.TYPE_ACCELEROMETER: {
                if (!gInit) { gx = v[0]; gy = v[1]; gz = v[2]; gInit = true; }
                gx += (v[0] - gx) * 0.1f;
                gy += (v[1] - gy) * 0.1f;
                gz += (v[2] - gz) * 0.1f;
                float lx = v[0] - gx, ly = v[1] - gy, lz = v[2] - gz;
                float j = (float) Math.sqrt(lx * lx + ly * ly + lz * lz);
                if (j > joltMax) joltMax = j;
                ax = gx; ay = gy; az = gz;
                long now = System.currentTimeMillis();
                if (j > 22f && now - shakes[(shakeIdx + 5) % 6] > 120) {
                    shakes[shakeIdx] = now;
                    shakeIdx = (shakeIdx + 1) % 6;
                    int n = 0;
                    for (long t : shakes) if (now - t < 1800) n++;
                    if (n >= 5) {
                        shaken = true;
                        java.util.Arrays.fill(shakes, 0);
                    }
                }
                break;
            }
            case Sensor.TYPE_PROXIMITY:
                if (proxValue >= 0 && v[0] != proxValue) proxChanges++;
                proxValue = v[0];
                break;
            case Sensor.TYPE_AMBIENT_TEMPERATURE:
                ambientTemp = v[0];
                break;
            case Sensor.TYPE_PRESSURE:
                pressure = v[0];
                break;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor s, int a) { }

    void calibrate() {
        emfBaseline = emfTotal;
        emfDelta = 0f;
        bx = mx; by = my; bz = mz;
    }

    /** Czy telefonem mocno potrząśnięto kilka razy (SOS). */
    boolean takeShake() {
        boolean s = shaken;
        shaken = false;
        return s;
    }

    /** Azymut (0 = północ magnetyczna) w stopniach, albo NaN. */
    float heading() {
        float[] R = new float[9], I = new float[9], o = new float[3];
        if (!SensorManager.getRotationMatrix(R, I, new float[]{ax, ay, az}, new float[]{mx, my, mz})) return Float.NaN;
        SensorManager.getOrientation(R, o);
        float deg = (float) Math.toDegrees(o[0]);
        return (deg + 360f) % 360f;
    }

    /** Największe szarpnięcie od ostatniego wywołania (m/s²). */
    float takeJolt() {
        float j = joltMax;
        joltMax = 0f;
        return j;
    }

    static int level(float value, float[] thresholds) {
        int l = 0;
        for (float t : thresholds) if (value >= t) l++;
        return l;
    }

    boolean hasAmbientTemp() {
        return temp != null && !Float.isNaN(ambientTemp);
    }

    /** Temperatura otoczenia, a jeśli telefon nie ma takiego czujnika – temperatura baterii. */
    float temperature() {
        if (hasAmbientTemp()) return ambientTemp;
        refreshBattery();
        return batteryTemp;
    }

    String tempSource() {
        return hasAmbientTemp() ? "czujnik temperatury otoczenia" : "czujnik baterii telefonu";
    }

    void refreshBattery() {
        long now = System.currentTimeMillis();
        if (now - lastBattery < 4000) return;
        lastBattery = now;
        try {
            Intent i = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null) return;
            int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            if (t != Integer.MIN_VALUE) batteryTemp = t / 10f;
            int lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (lvl >= 0 && sc > 0) battery = lvl * 100 / sc;
        } catch (Exception ignored) { }
    }
}
