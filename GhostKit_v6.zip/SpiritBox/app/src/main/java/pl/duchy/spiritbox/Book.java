package pl.duchy.spiritbox;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Wspólny dziennik drużyny: notatki, zdarzenia, głosy ze Spirit Boxa, zdjęcia i nagrania.
 * Każdy telefon ma kopię; wpisy rozchodzą się przez hosta, nowi członkowie dostają całość po dołączeniu.
 */
final class Book {

    static final class Entry {
        String id, author, kind, text, file;
        long ts;

        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id);
                o.put("author", author);
                o.put("kind", kind);
                o.put("text", text);
                o.put("ts", ts);
                if (file != null) o.put("file", file);
            } catch (JSONException ignored) { }
            return o;
        }

        static Entry from(JSONObject o) {
            Entry e = new Entry();
            e.id = o.optString("id");
            e.author = o.optString("author");
            e.kind = o.optString("kind");
            e.text = o.optString("text");
            e.ts = o.optLong("ts");
            e.file = o.has("file") ? o.optString("file") : null;
            return e;
        }
    }

    private final Core core;
    final File dir;
    final List<Entry> entries = new ArrayList<>();
    Runnable onChange;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    Book(Context c, Core core) {
        this.core = core;
        dir = new File(c.getFilesDir(), "book");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        load();
    }

    File fileOf(Entry e) {
        return e.file == null ? null : new File(dir, e.file);
    }

    // ================= dodawanie =================

    void addText(String kind, String text) {
        add(newEntry(kind, text, null));
    }

    void addBytes(String kind, String text, byte[] data, String ext) {
        Entry e = newEntry(kind, text, ext);
        try {
            writeFile(new File(dir, e.file), data);
        } catch (IOException ex) {
            e.file = null;
        }
        add(e);
    }

    /** Przenosi plik (np. nagranie wideo) do dziennika. */
    void addFile(String kind, String text, File src, String ext) {
        Entry e = newEntry(kind, text, ext);
        File dst = new File(dir, e.file);
        if (!src.renameTo(dst)) {
            try { copy(src, dst); } catch (IOException ex) { e.file = null; }
            //noinspection ResultOfMethodCallIgnored
            src.delete();
        }
        add(e);
    }

    private Entry newEntry(String kind, String text, String ext) {
        Entry e = new Entry();
        e.id = UUID.randomUUID().toString();
        e.ts = System.currentTimeMillis();
        e.author = core.myName;
        e.kind = kind;
        e.text = text;
        e.file = ext == null ? null : e.id + "." + ext;
        return e;
    }

    private void add(Entry e) {
        entries.add(e);
        save();
        changed();
        broadcast(e);
    }

    private void broadcast(Entry e) {
        if (!core.net.isConnected()) return;
        io.execute(() -> core.net.send(toMsg(e)));
    }

    private Net.Msg toMsg(Entry e) {
        JSONObject o = Net.Msg.obj("book_add");
        try { o.put("entry", e.toJson()); } catch (JSONException ignored) { }
        byte[] data = null;
        File f = fileOf(e);
        if (f != null && f.exists() && f.length() < 90_000_000) {
            try { data = readFile(f); } catch (IOException ignored) { }
        }
        return new Net.Msg(o, data);
    }

    /** Wpis przyszedł z sieci. */
    void receive(Net.Msg m) {
        JSONObject jo = m.j.optJSONObject("entry");
        if (jo == null) return;
        Entry e = Entry.from(jo);
        if (has(e.id)) return;
        byte[] data = m.bin;
        io.execute(() -> {
            if (e.file != null) {
                if (data == null) e.file = null;
                else {
                    try { writeFile(new File(dir, e.file), data); } catch (IOException ex) { e.file = null; }
                }
            }
            core.main.post(() -> {
                if (has(e.id)) return;
                entries.add(e);
                Collections.sort(entries, (a, b) -> Long.compare(a.ts, b.ts));
                save();
                changed();
            });
        });
    }

    private boolean has(String id) {
        for (Entry x : entries) if (x.id.equals(id)) return true;
        return false;
    }

    /** Host: wysyła cały dziennik nowemu członkowi. */
    void syncTo(String peerId) {
        final List<Entry> snap = new ArrayList<>(entries);
        io.execute(() -> {
            for (Entry e : snap) core.net.sendTo(peerId, toMsg(e));
        });
    }

    // ================= czyszczenie =================

    void clear(boolean broadcast) {
        for (Entry e : entries) {
            File f = fileOf(e);
            //noinspection ResultOfMethodCallIgnored
            if (f != null) f.delete();
        }
        entries.clear();
        save();
        changed();
        if (broadcast && core.net.isConnected()) {
            JSONObject o = Net.Msg.obj("book_clear");
            try { o.put("name", core.myName); } catch (JSONException ignored) { }
            core.net.send(new Net.Msg(o, null));
        }
    }

    private void changed() {
        if (onChange != null) core.main.post(onChange);
    }

    // ================= zapis na dysk =================

    private void load() {
        File f = new File(dir, "book.json");
        if (!f.exists()) return;
        try {
            JSONObject o = new JSONObject(new String(readFile(f), StandardCharsets.UTF_8));
            JSONArray a = o.optJSONArray("entries");
            if (a != null) for (int i = 0; i < a.length(); i++) entries.add(Entry.from(a.getJSONObject(i)));
        } catch (Exception ignored) { }
    }

    private void save() {
        JSONObject o = new JSONObject();
        try {
            JSONArray a = new JSONArray();
            for (Entry e : entries) a.put(e.toJson());
            o.put("entries", a);
        } catch (JSONException ignored) { }
        final byte[] data = o.toString().getBytes(StandardCharsets.UTF_8);
        io.execute(() -> {
            try { writeFile(new File(dir, "book.json"), data); } catch (IOException ignored) { }
        });
    }

    static byte[] readFile(File f) throws IOException {
        byte[] b = new byte[(int) f.length()];
        try (InputStream in = new FileInputStream(f)) {
            int off = 0, r;
            while (off < b.length && (r = in.read(b, off, b.length - off)) > 0) off += r;
        }
        return b;
    }

    static void writeFile(File f, byte[] data) throws IOException {
        try (OutputStream out = new FileOutputStream(f)) {
            out.write(data);
        }
    }

    static void copy(File src, File dst) throws IOException {
        try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[65536];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
        }
    }
}
