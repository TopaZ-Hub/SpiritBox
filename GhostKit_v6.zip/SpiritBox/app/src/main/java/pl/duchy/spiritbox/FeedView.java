package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

import java.util.Random;

/**
 * Obraz z kamery z nakładką: REC, prawdziwa data i godzina, tryb, zoom, ruch.
 * W trybie "overlayOnly" rysuje samą nakładkę (pod spodem jest podgląd na żywo z kamery).
 */
final class FeedView extends View {

    volatile Bitmap frame;
    volatile int rot = 90;
    volatile boolean mirror, nv, flash, rec, mic, motionOn = true, overlayOnly = false;
    volatile long ts, motionUntil;
    volatile String label = "", zoomText = "";
    /** Sylwetka: 33 punkty (x,y 0..1 w kadrze pionowym), NaN = brak. */
    volatile float[] pose;
    volatile boolean poseOn = false;
    /** Wysokość / szerokość widoku (3:4 pion = 4/3, 16:9 poziom = 9/16). */
    volatile float aspect = 4f / 3f;

    private final Random rnd = new Random();
    private final ColorMatrixColorFilter nvFilter;
    private Bitmap noise;

    FeedView(Context c) {
        super(c);
        ColorMatrix cm = new ColorMatrix(new float[]{
                0.08f, 0.16f, 0.03f, 0, 0,
                0.45f, 0.95f, 0.18f, 0, 10,
                0.10f, 0.20f, 0.04f, 0, 0,
                0, 0, 0, 1, 0});
        nvFilter = new ColorMatrixColorFilter(cm);
    }

    @Override
    protected void onMeasure(int w, int h) {
        int W = MeasureSpec.getSize(w);
        setMeasuredDimension(W, Math.round(W * aspect));
    }

    void setFrame(Bitmap b, long t) {
        frame = b;
        ts = t;
        postInvalidate();
    }

    /** Klatka z nakładką do zdjęcia / nagrania. */
    Bitmap compose(Bitmap src, int w, int h) {
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        render(new Canvas(out), w, h, src, false);
        return out;
    }

    @Override
    protected void onDraw(Canvas c) {
        render(c, getWidth(), getHeight(), frame, overlayOnly);
        if (overlayOnly || frame == null || rec || System.currentTimeMillis() < motionUntil) postInvalidateDelayed(250);
    }

    // wołane z dwóch wątków (ekran i nagrywanie) – wszystko lokalnie
    private void render(Canvas c, int W, int H, Bitmap b, boolean onlyOverlay) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        Paint img = new Paint(Paint.FILTER_BITMAP_FLAG);
        float u = W / 100f;
        if (!onlyOverlay) {
            c.drawColor(Color.BLACK);
            if (b != null) {
                Matrix m = new Matrix();
                int bw = b.getWidth(), bh = b.getHeight();
                boolean swap = rot % 180 != 0;
                float rw = swap ? bh : bw, rh = swap ? bw : bh;
                float scale = Math.max(W / rw, H / rh);
                m.postTranslate(-bw / 2f, -bh / 2f);
                m.postRotate(rot);
                if (mirror) m.postScale(-1, 1);
                m.postScale(scale, scale);
                m.postTranslate(W / 2f, H / 2f);
                img.setColorFilter(nv ? nvFilter : null);
                c.drawBitmap(b, m, img);
            } else {
                drawNoise(c, W, H, img);
                p.setColor(Color.WHITE);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTypeface(Typeface.MONOSPACE);
                p.setTextSize(5 * u);
                c.drawText("BRAK SYGNAŁU", W / 2f, H / 2f, p);
            }
        }
        if (nv) {
            p.setShader(new RadialGradient(W / 2f, H / 2f, Math.max(W, H) * 0.75f, 0x00000000, 0xAA000000, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, W, H, p);
            p.setShader(null);
        }

        float[] ps = pose;
        if (ps != null) drawPose(c, W, H, ps, u);

        // narożniki i krzyżyk
        p.setColor(0xDDFFFFFF);
        p.setStrokeWidth(0.5f * u);
        float m0 = 4 * u, L = 7 * u;
        c.drawLine(m0, m0, m0 + L, m0, p); c.drawLine(m0, m0, m0, m0 + L, p);
        c.drawLine(W - m0, m0, W - m0 - L, m0, p); c.drawLine(W - m0, m0, W - m0, m0 + L, p);
        c.drawLine(m0, H - m0, m0 + L, H - m0, p); c.drawLine(m0, H - m0, m0, H - m0 - L, p);
        c.drawLine(W - m0, H - m0, W - m0 - L, H - m0, p); c.drawLine(W - m0, H - m0, W - m0, H - m0 - L, p);
        c.drawLine(W / 2f - 3 * u, H / 2f, W / 2f + 3 * u, H / 2f, p);
        c.drawLine(W / 2f, H / 2f - 3 * u, W / 2f, H / 2f + 3 * u, p);

        p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        p.setTextSize(4.2f * u);
        p.setShadowLayer(u * 0.6f, 0, 0, Color.BLACK);
        long now = System.currentTimeMillis();
        p.setTextAlign(Paint.Align.LEFT);
        if (rec) {
            p.setColor(0xFFFF3030);
            if ((now / 500) % 2 == 0) c.drawCircle(9 * u, 9.5f * u, 1.6f * u, p);
            c.drawText("REC", 12 * u, 11 * u, p);
        } else {
            p.setColor(0xFFFFFFFF);
            c.drawText(nv ? "NV" : "LIVE", 8 * u, 11 * u, p);
        }
        p.setColor(Color.WHITE);
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText(Ui.stamp(ts > 0 && !onlyOverlay ? ts : now), W - 8 * u, 11 * u, p);

        p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(3.6f * u);
        float y = H - 7.5f * u;
        c.drawText(label, 8 * u, y, p);
        String flags = (nv ? "NV  " : "") + (flash ? "LAMPA  " : "") + (mic ? "MIC  " : "")
                + (zoomText.isEmpty() ? "" : zoomText + "  ") + (motionOn ? "RUCH  " : "") + (poseOn ? "SYLWETKI" : "");
        c.drawText(flags, 8 * u, y - 5 * u, p);

        if (now < motionUntil) {
            p.setColor(0xFFFF2020);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(6 * u);
            c.drawText("▲ RUCH", W / 2f, 24 * u, p);
        }
    }

    private void drawPose(Canvas c, int W, int H, float[] ps, float u) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStrokeCap(Paint.Cap.ROUND);
        int col = 0xFF4DFF88;
        for (int pass = 0; pass < 2; pass++) {
            p.setStrokeWidth(pass == 0 ? 2.4f * u : 0.9f * u);
            p.setColor(pass == 0 ? 0x5530FF70 : col);
            for (int[] b : PoseTracker.BONES) {
                float x1 = ps[b[0] * 2], y1 = ps[b[0] * 2 + 1], x2 = ps[b[1] * 2], y2 = ps[b[1] * 2 + 1];
                if (Float.isNaN(x1) || Float.isNaN(x2)) continue;
                c.drawLine(x1 * W, y1 * H, x2 * W, y2 * H, p);
            }
        }
        p.setColor(col);
        for (int i = 0; i < 33; i++) {
            float x = ps[i * 2], y = ps[i * 2 + 1];
            if (Float.isNaN(x) || (i > 0 && i < 11) || i > 28) continue;
            c.drawCircle(x * W, y * H, 1.1f * u, p);
        }
        float nx = ps[0], ny = ps[1], lx = ps[22], rx = ps[24];
        if (!Float.isNaN(nx) && !Float.isNaN(lx) && !Float.isNaN(rx)) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.9f * u);
            c.drawCircle(nx * W, ny * H, Math.abs(lx - rx) * W * 0.32f + 2 * u, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.MONOSPACE);
        p.setTextSize(3.4f * u);
        p.setColor(col);
        c.drawText("◆ SYLWETKA", 8 * u, 18 * u, p);
    }

    private void drawNoise(Canvas c, int W, int H, Paint img) {
        if (noise == null) noise = Bitmap.createBitmap(80, 106, Bitmap.Config.ARGB_8888);
        int[] px = new int[80 * 106];
        for (int i = 0; i < px.length; i++) {
            int g = rnd.nextInt(140);
            px[i] = 0xFF000000 | (g << 16) | (g << 8) | g;
        }
        noise.setPixels(px, 0, 80, 0, 0, 80, 106);
        c.drawBitmap(noise, null, new android.graphics.Rect(0, 0, W, H), img);
    }
}
