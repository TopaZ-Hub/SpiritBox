package pl.duchy.spiritbox;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Zapis mono 16-bit PCM do pliku WAV. */
final class WavWriter {
    private final RandomAccessFile raf;
    private final File file;
    private final int sampleRate;
    private long dataBytes = 0;
    private byte[] scratch = new byte[0];

    WavWriter(File file, int sampleRate) throws IOException {
        this.file = file;
        this.sampleRate = sampleRate;
        raf = new RandomAccessFile(file, "rw");
        raf.setLength(0);
        raf.write(header(0));
    }

    File getFile() {
        return file;
    }

    void write(short[] samples, int count) throws IOException {
        if (scratch.length < count * 2) scratch = new byte[count * 2];
        ByteBuffer bb = ByteBuffer.wrap(scratch).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < count; i++) bb.putShort(samples[i]);
        raf.write(scratch, 0, count * 2);
        dataBytes += count * 2L;
    }

    void close() throws IOException {
        raf.seek(0);
        raf.write(header(dataBytes));
        raf.close();
    }

    /** Całe nagranie jako bajty pliku WAV. */
    static byte[] encode(short[] samples, int sampleRate) {
        ByteBuffer b = ByteBuffer.allocate(44 + samples.length * 2).order(ByteOrder.LITTLE_ENDIAN);
        b.put(headerBytes(samples.length * 2L, sampleRate));
        for (short s : samples) b.putShort(s);
        return b.array();
    }

    private byte[] header(long dataLen) {
        return headerBytes(dataLen, sampleRate);
    }

    private static byte[] headerBytes(long dataLen, int sampleRate) {
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put(new byte[]{'R', 'I', 'F', 'F'});
        b.putInt((int) (36 + dataLen));
        b.put(new byte[]{'W', 'A', 'V', 'E'});
        b.put(new byte[]{'f', 'm', 't', ' '});
        b.putInt(16);
        b.putShort((short) 1);          // PCM
        b.putShort((short) 1);          // mono
        b.putInt(sampleRate);
        b.putInt(sampleRate * 2);       // byte rate
        b.putShort((short) 2);          // block align
        b.putShort((short) 16);         // bits
        b.put(new byte[]{'d', 'a', 't', 'a'});
        b.putInt((int) dataLen);
        return b.array();
    }
}
