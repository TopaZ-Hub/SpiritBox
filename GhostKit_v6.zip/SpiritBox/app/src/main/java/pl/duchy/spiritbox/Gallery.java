package pl.duchy.spiritbox;

import android.content.ContentValues;
import android.graphics.Bitmap;
import java.io.ByteArrayOutputStream;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Zapis kopii zdjęć i nagrań do galerii telefonu (Android 10+). */
final class Gallery {

    static boolean saveImage(Context c, byte[] jpeg, String name) {
        if (Build.VERSION.SDK_INT < 29) return false;
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GhostKit");
            Uri uri = c.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return false;
            try (OutputStream os = c.getContentResolver().openOutputStream(uri)) {
                if (os == null) return false;
                os.write(jpeg);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean saveVideo(Context c, File f, String name) {
        if (Build.VERSION.SDK_INT < 29) return false;
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/GhostKit");
            Uri uri = c.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return false;
            try (OutputStream os = c.getContentResolver().openOutputStream(uri);
                 InputStream is = new FileInputStream(f)) {
                if (os == null) return false;
                byte[] buf = new byte[65536];
                int r;
                while ((r = is.read(buf)) > 0) os.write(buf, 0, r);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Zdjęcie aktualnej klatki z nakładką: galeria + dziennik drużyny. */
    static void photo(Core core, Context c, FeedView feed, String text) {
        Bitmap src = feed.frame;
        if (src == null) {
            core.toast("Brak obrazu");
            return;
        }
        boolean swap = feed.rot % 180 != 0;
        int w = swap ? 720 : 960, h = swap ? 960 : 720;
        photoFromBitmap(core, c, feed, src, w, h, text);
    }

    /** Zdjęcie z podanej klatki (np. przetworzonej w tle) z nakładką. */
    static void photoFromBitmap(Core core, Context c, FeedView feed, Bitmap src, int w, int h, String text) {
        Bitmap out = feed.compose(src, w, h);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        out.compress(Bitmap.CompressFormat.JPEG, 90, bo);
        byte[] j = bo.toByteArray();
        boolean g = saveImage(c, j, "GhostCam_" + Ui.fileStamp() + ".jpg");
        core.book.addBytes("photo", text, j, "jpg");
        core.toast(g ? "Zapisano w galerii (GhostKit) i dzienniku" : "Zapisano w dzienniku");
    }

    /** Koniec nagrania: galeria + dziennik drużyny. */
    static void finishVideo(Core core, Context c, File f, boolean ok, String text) {
        if (!ok) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            core.toast("Nagrywanie nie powiodło się");
            return;
        }
        boolean g = saveVideo(c, f, f.getName());
        core.book.addFile("video", text, f, "mp4");
        core.toast(g ? "Zapisano w galerii (GhostKit) i dzienniku" : "Zapisano w dzienniku");
    }
}
