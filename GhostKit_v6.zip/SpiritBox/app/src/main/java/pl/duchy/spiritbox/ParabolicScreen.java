package pl.duchy.spiritbox;

import android.Manifest;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.Locale;

/**
 * Mikrofon kierunkowy: mocne wzmocnienie, filtry i bramka szumów, odsłuch na żywo w słuchawkach.
 * Działa z wbudowanym mikrofonem albo z podłączonym zewnętrznym (ustawienia).
 */
final class ParabolicScreen extends Screen {

    private static final int SR = 44100;
    private static final float[] GAINS = {2, 5, 10, 20, 40};
    private static final String[] FILTERS = {"PEŁNE", "GŁOS", "KROKI"};

    private final Dish dish;
    private final Button runBtn, recBtn;
    private final TextView[] gainChips = new TextView[5], filterChips = new TextView[3];
    private final TextView warn;
    private volatile boolean running = false;
    private volatile int gainIdx = 2, filter = 1;
    private volatile float level = 0;
    private Thread thread;
    private volatile WavWriter wav;
    private File wavFile;

    ParabolicScreen(MainActivity a) {
        super(a);
        ScrollView sv = new ScrollView(a);
        LinearLayout root = Ui.col(a);
        root.setPadding(dp(14), dp(4), dp(14), dp(28));
        sv.addView(root);
        addView(sv);

        dish = new Dish(a);
        root.addView(dish);

        warn = Ui.head(a, "", 11, Ui.RED);
        warn.setGravity(Gravity.CENTER);
        warn.setPadding(0, dp(6), 0, dp(6));
        root.addView(warn);

        LinearLayout r1 = Ui.row(a);
        runBtn = Ui.btn(a, "");
        runBtn.setOnClickListener(v -> { if (running) stop(); else act.withPermission(Manifest.permission.RECORD_AUDIO, this::start); });
        recBtn = Ui.btn(a, "");
        recBtn.setOnClickListener(v -> toggleRec());
        Ui.addWeighted(r1, runBtn);
        Ui.addWeighted(r1, recBtn);
        root.addView(r1);

        root.addView(Ui.section(a, "wzmocnienie"));
        LinearLayout g = Ui.row(a);
        for (int i = 0; i < 5; i++) {
            final int k = i;
            gainChips[i] = Ui.head(a, "×" + (int) GAINS[i], 12, Ui.TEXT);
            gainChips[i].setGravity(Gravity.CENTER);
            gainChips[i].setOnClickListener(v -> { gainIdx = k; refresh(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(36), 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            g.addView(gainChips[i], lp);
        }
        root.addView(g);

        root.addView(Ui.section(a, "filtr"));
        LinearLayout f = Ui.row(a);
        for (int i = 0; i < 3; i++) {
            final int k = i;
            filterChips[i] = Ui.head(a, FILTERS[i], 12, Ui.TEXT);
            filterChips[i].setGravity(Gravity.CENTER);
            filterChips[i].setOnClickListener(v -> { filter = k; refresh(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(36), 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            f.addView(filterChips[i], lp);
        }
        root.addView(f);

        TextView info = Ui.text(a, "Skieruj górę telefonu (mikrofon) w stronę dźwięku i słuchaj w słuchawkach. " +
                "GŁOS – pasmo mowy (300–3400 Hz), KROKI – niskie dźwięki (stuki, kroki), PEŁNE – całe pasmo. " +
                "Lepszy efekt da zewnętrzny mikrofon (USB / jack / kierunkowy) – wybierz go w Ustawieniach. " +
                "Nagrania trafiają do dziennika.", 12, Ui.DIM, false);
        info.setPadding(0, dp(14), 0, 0);
        root.addView(info);
        refresh();
    }

    private void chip(TextView t, boolean on) {
        t.setTextColor(on ? Ui.BG : Ui.TEXT);
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setCornerRadius(dp(8));
        gd.setColor(on ? Ui.ACCENT : Ui.CARD2);
        gd.setStroke(dp(1), Ui.STROKE);
        t.setBackground(gd);
    }

    private void refresh() {
        runBtn.setText(running ? "■  STOP" : "▶  SŁUCHAJ");
        Ui.active(runBtn, running);
        recBtn.setText(wav != null ? "■  ZAPISZ NAGRANIE" : "●  NAGRYWAJ");
        Ui.active(recBtn, wav != null);
        for (int i = 0; i < 5; i++) chip(gainChips[i], i == gainIdx);
        for (int i = 0; i < 3; i++) chip(filterChips[i], i == filter);
        boolean hp = AudioIn.headphones(act);
        warn.setText(hp ? "" : "PODŁĄCZ SŁUCHAWKI – BEZ NICH GŁOŚNIK WRÓCI DO MIKROFONU (PISK)");
        warn.setVisibility(hp ? View.GONE : View.VISIBLE);
    }

    @Override
    String title() {
        return "Mikrofon kierunkowy";
    }

    @Override
    void onHide() {
        if (wav != null) toggleRec();
        stop();
    }

    @Override
    void tick() {
        dish.level = level;
        dish.on = running;
        dish.invalidate();
        if (System.currentTimeMillis() % 2000 < 70) refresh();
    }

    private void start() {
        if (running) return;
        running = true;
        thread = new Thread(this::loop, "parabolic");
        thread.start();
        refresh();
    }

    private void stop() {
        running = false;
        if (thread != null) {
            try { thread.join(500); } catch (InterruptedException ignored) { }
            thread = null;
        }
        level = 0;
        refresh();
    }

    private void loop() {
        int source = Build.VERSION.SDK_INT >= 24 ? MediaRecorder.AudioSource.UNPROCESSED : MediaRecorder.AudioSource.MIC;
        AudioRecord rec = AudioIn.open(source, SR);
        AudioTrack out = null;
        try {
            if (rec == null || rec.getState() != AudioRecord.STATE_INITIALIZED) {
                core.main.post(() -> core.toast("Nie można otworzyć mikrofonu"));
                return;
            }
            int minOut = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            out = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(minOut)
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
            rec.startRecording();
            out.play();
            Biquad hp = new Biquad(), lp = new Biquad(), hp2 = new Biquad();
            int lastFilter = -1;
            short[] in = new short[512], o = new short[512];
            float env = 0;
            while (running) {
                int n = rec.read(in, 0, in.length);
                if (n <= 0) continue;
                int f = filter;
                if (f != lastFilter) {
                    lastFilter = f;
                    if (f == 1) { hp.highpass(300, 0.707f, SR); hp2.highpass(300, 0.707f, SR); lp.lowpass(3400, 0.707f, SR); }
                    else if (f == 2) { hp.highpass(40, 0.707f, SR); hp2.highpass(40, 0.707f, SR); lp.lowpass(600, 0.707f, SR); }
                    else { hp.highpass(80, 0.707f, SR); hp2.highpass(80, 0.707f, SR); lp.lowpass(12000, 0.707f, SR); }
                }
                float g = GAINS[gainIdx];
                double sum = 0;
                for (int i = 0; i < n; i++) {
                    float x = in[i] / 32768f;
                    x = lp.process(hp2.process(hp.process(x)));
                    float a = Math.abs(x);
                    env += (a - env) * (a > env ? 0.05f : 0.0008f);
                    // bramka szumów: cichy szum tła ściszany, wyraźne dźwięki przechodzą w całości
                    float gate = env < 0.0015f ? 0.35f : 1f;
                    float y = (float) Math.tanh(x * g * gate);
                    sum += y * y;
                    o[i] = (short) (y * 30000);
                }
                level = (float) Math.sqrt(sum / n);
                out.write(o, 0, n);
                WavWriter w = wav;
                if (w != null) {
                    try { w.write(o, n); } catch (Exception ignored) { }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (rec != null) {
                try { rec.stop(); } catch (Exception ignored) { }
                rec.release();
            }
            if (out != null) {
                try { out.stop(); } catch (Exception ignored) { }
                out.release();
            }
            running = false;
            core.main.post(this::refresh);
        }
    }

    private void toggleRec() {
        if (wav != null) {
            WavWriter w = wav;
            wav = null;
            try { w.close(); } catch (Exception ignored) { }
            core.book.addFile("audio", "Mikrofon kierunkowy (" + core.myName + ")", wavFile, "wav");
            core.toast("Nagranie zapisane w dzienniku");
        } else {
            if (!running) {
                core.toast("Najpierw włącz SŁUCHAJ");
                return;
            }
            try {
                wavFile = new File(act.getCacheDir(), "para_" + Ui.fileStamp() + ".wav");
                wav = new WavWriter(wavFile, SR);
            } catch (Exception e) {
                core.toast("Nie można nagrywać");
            }
        }
        refresh();
    }

    // ================= rysunek: czasza paraboliczna =================

    static final class Dish extends View {
        boolean on;
        float level;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        Dish(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w);
            setMeasuredDimension(W, (int) (W * 0.95f));
        }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), u = W / 100f;
            float cx = 50 * u, cy = 40 * u, r = 36 * u;
            Mat.shadowCircle(c, cx, cy, r, u);
            // czasza
            p.setShader(new RadialGradient(cx - 10 * u, cy - 12 * u, r * 1.4f,
                    new int[]{0xFFE8EAEE, 0xFFA9AEB6, 0xFF5E636B}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            for (int i = 1; i <= 5; i++) {
                p.setStrokeWidth(0.4f * u);
                p.setColor(i % 2 == 0 ? 0x33000000 : 0x22FFFFFF);
                c.drawCircle(cx, cy, r * i / 5.5f, p);
            }
            p.setStrokeWidth(1.6f * u);
            p.setColor(0xFF3A3D42);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.FILL);
            Mat.glossCircle(c, cx, cy, r);
            // ramię i mikrofon
            p.setColor(0xFF22252A);
            c.drawRect(cx - 0.8f * u, cy - 2 * u, cx + 0.8f * u, cy + 12 * u, p);
            p.setShader(new RadialGradient(cx - u, cy - u, 5 * u, 0xFF5A5E66, 0xFF101114, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, 4.5f * u, p);
            p.setShader(null);
            p.setColor(0x55FFFFFF);
            for (int i = -2; i <= 2; i++) c.drawLine(cx + i * 1.4f * u, cy - 3 * u, cx + i * 1.4f * u, cy + 3 * u, p);
            // uchwyt pistoletowy
            path.reset();
            path.moveTo(cx - 6 * u, cy + r - 2 * u);
            path.lineTo(cx + 6 * u, cy + r - 2 * u);
            path.lineTo(cx + 9 * u, cy + r + 22 * u);
            path.quadTo(cx + 9 * u, cy + r + 26 * u, cx + 5 * u, cy + r + 26 * u);
            path.lineTo(cx - 3 * u, cy + r + 26 * u);
            path.quadTo(cx - 6 * u, cy + r + 26 * u, cx - 6 * u, cy + r + 22 * u);
            path.close();
            p.setShader(new LinearGradient(cx - 6 * u, 0, cx + 9 * u, 0, 0xFF16181B, 0xFF33363C, Shader.TileMode.CLAMP));
            c.drawPath(path, p);
            p.setShader(null);
            Mat.grain(c, path, u);
            // wskaźnik poziomu (LED)
            float bx = 84 * u, by0 = 18 * u, bh = 48 * u;
            p.setColor(0xFF0B0C0E);
            c.drawRoundRect(new RectF(bx - 3 * u, by0 - 2 * u, bx + 5 * u, by0 + bh + 2 * u), u, u, p);
            int segs = 16;
            int lit = on ? Math.min(segs, (int) (Math.sqrt(level) * segs * 1.3f)) : 0;
            for (int i = 0; i < segs; i++) {
                float y = by0 + bh - (i + 1) * bh / segs;
                int col = i < 10 ? 0xFF3DDC97 : i < 13 ? 0xFFFFD23A : 0xFFFF3B30;
                p.setColor(i < lit ? col : (col & 0x00FFFFFF) | 0x26000000);
                c.drawRect(bx - 1.5f * u, y + 0.4f * u, bx + 3.5f * u, y + bh / segs - 0.4f * u, p);
            }
            p.setColor(Ui.DIM);
            p.setTypeface(Typeface.MONOSPACE);
            p.setTextSize(3 * u);
            p.setTextAlign(Paint.Align.CENTER);
            double db = level > 1e-5 ? 20 * Math.log10(level) : -90;
            c.drawText(on ? String.format(Locale.US, "%.0f dB", db) : "OFF", bx + u, by0 + bh + 7 * u, p);
        }
    }
}
