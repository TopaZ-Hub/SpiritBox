package pl.duchy.spiritbox;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Styl "sprzętu terenowego": grafitowe tło, ostre karty z cienką ramką,
 * nagłówki pisane krojem maszynowym i jeden kolor akcentu wybierany w ustawieniach.
 */
final class Ui {
    static final int BG = 0xFF0B0C0E;
    static final int CARD = 0xFF131417;
    static final int CARD2 = 0xFF1B1D21;
    static final int STROKE = 0xFF2A2D33;
    static final int TEXT = 0xFFECEAE4;
    static final int DIM = 0xFF8C8A84;
    static final int RED = 0xFFFF4D4D;
    static final int GREEN = 0xFF52E08A;

    static final int[] ACCENTS = {0xFFFF7A1A, 0xFF52E08A, 0xFF35C9E8, 0xFFB08CFF, 0xFFFF4D6A, 0xFFE8D24A, 0xFFE8E6DF};
    static final String[] ACCENT_NAMES = {"Pomarańcz", "Zieleń", "Turkus", "Fiolet", "Czerwień", "Żółć", "Kość"};
    static int ACCENT = ACCENTS[0];

    static final Typeface HEAD = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);
    static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    static final Typeface BLACK = Typeface.create("sans-serif-black", Typeface.NORMAL);

    static void load(SharedPreferences p) {
        ACCENT = p.getInt("accent", ACCENTS[0]);
    }

    /** Kolor akcentu z daną przezroczystością (0..255). */
    static int accent(int alpha) {
        return (ACCENT & 0x00FFFFFF) | (alpha << 24);
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(MEDIUM);
        return t;
    }

    static TextView head(Context c, String s, float sp, int color) {
        TextView t = text(c, s, sp, color, false);
        t.setTypeface(HEAD);
        t.setLetterSpacing(0.06f);
        return t;
    }

    static Button btn(Context c, String s) {
        return btn(c, s, CARD2, TEXT);
    }

    static Button btn(Context c, String s, int bg, int fg) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(13);
        b.setTypeface(HEAD);
        b.setLetterSpacing(0.04f);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c, 48));
        b.setPadding(dp(c, 10), dp(c, 6), dp(c, 10), dp(c, 6));
        b.setStateListAnimator(null);
        color(b, bg);
        return b;
    }

    static void color(View b, int bg) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(b.getContext(), 8));
        g.setStroke(dp(b.getContext(), 1), STROKE);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(accent(0x44)), g, null));
    }

    /** Przycisk "włączony" – obrys i tekst w kolorze akcentu. */
    static void active(Button b, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? accent(0x26) : CARD2);
        g.setCornerRadius(dp(b.getContext(), 8));
        g.setStroke(dp(b.getContext(), on ? 2 : 1), on ? ACCENT : STROKE);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(accent(0x44)), g, null));
        b.setTextColor(on ? ACCENT : TEXT);
    }

    static void card(View v) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(v.getContext(), 10));
        g.setStroke(dp(v.getContext(), 1), STROKE);
        v.setBackground(new RippleDrawable(ColorStateList.valueOf(accent(0x33)), g, null));
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static void addWeighted(LinearLayout row, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        int m = dp(row.getContext(), 4);
        lp.setMargins(m, m, m, m);
        row.addView(v, lp);
    }

    static LinearLayout.LayoutParams matchWrap(Context c, int marginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        int m = dp(c, marginDp);
        lp.setMargins(m, m, m, m);
        return lp;
    }

    static TextView section(Context c, String s) {
        TextView t = head(c, "// " + s.toUpperCase(Locale.getDefault()), 11, DIM);
        t.setLetterSpacing(0.14f);
        t.setPadding(dp(c, 4), dp(c, 20), 0, dp(c, 8));
        return t;
    }

    static String stamp(long ts) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date(ts));
    }

    static String time(long ts) {
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(ts));
    }

    static String fileStamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }
}
