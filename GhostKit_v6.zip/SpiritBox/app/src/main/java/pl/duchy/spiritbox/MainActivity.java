package pl.duchy.spiritbox;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

/** Jedna aktywność, w której przełączamy "ekrany" narzędzi. */
public class MainActivity extends Activity {

    static final int REQ_PICK_AUDIO = 900;

    private Core core;
    private FrameLayout content;
    private TextView titleView, backView, teamView;
    private Controls.Round pttView;
    private android.media.ToneGenerator siren;
    private android.app.AlertDialog sosDialog, shakeDialog;
    private Screen current;
    private final Map<String, Screen> screens = new HashMap<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean resumed = false;

    private final Map<Integer, Runnable> permCallbacks = new HashMap<>();
    private int nextReq = 100;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (current != null) current.tick();
            updateTeam();
            h.postDelayed(this, 66);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        core = Core.get(this);
        Ui.load(core.prefs);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        LinearLayout root = Ui.col(this);
        root.setBackgroundColor(Ui.BG);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(ins.getSystemWindowInsetLeft(), ins.getSystemWindowInsetTop(),
                    ins.getSystemWindowInsetRight(), ins.getSystemWindowInsetBottom());
            return ins.consumeSystemWindowInsets();
        });

        LinearLayout bar = Ui.row(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 6));
        backView = Ui.text(this, "‹", 26, Ui.ACCENT, true);
        backView.setGravity(Gravity.CENTER);
        backView.setPadding(0, 0, 0, Ui.dp(this, 3));
        Ui.color(backView, Ui.CARD2);
        backView.setOnClickListener(v -> open("menu"));
        titleView = Ui.head(this, "", 17, Ui.TEXT);
        titleView.setLetterSpacing(0.08f);
        titleView.setPadding(Ui.dp(this, 12), 0, 0, 0);
        teamView = Ui.text(this, "", 12, Ui.DIM, true);
        teamView.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 12), Ui.dp(this, 7));
        Ui.color(teamView, Ui.CARD2);
        teamView.setOnClickListener(v -> open("team"));
        bar.addView(backView, new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42)));
        bar.addView(titleView, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(teamView);
        // krótkofalówka: przytrzymaj, by mówić (dostępna na każdym ekranie)
        pttView = new Controls.Round(this, "mic");
        pttView.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == android.view.MotionEvent.ACTION_DOWN) {
                if (!has(android.Manifest.permission.RECORD_AUDIO)) {
                    withPermission(android.Manifest.permission.RECORD_AUDIO, () -> core.toast("Teraz przytrzymaj, by mówić"));
                    return true;
                }
                core.ptt.down();
                pttView.set(true);
            } else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) {
                core.ptt.up();
                pttView.set(false);
            }
            return true;
        });
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42));
        plp.leftMargin = Ui.dp(this, 8);
        bar.addView(pttView, plp);
        root.addView(bar);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        open("menu");
    }

    private Screen create(String key) {
        switch (key) {
            case "box": return new SpiritBoxScreen(this);
            case "emf": return new EmfScreen(this);
            case "thermo": return new ThermoScreen(this);
            case "cam": return new CamScreen(this);
            case "view": return new ViewerScreen(this);
            case "motion": return new MotionScreen(this);
            case "music": return new MusicScreen(this);
            case "book": return new BookScreen(this);
            case "team": return new TeamScreen(this);
            case "settings": return new SettingsScreen(this);
            case "walkie": return new WalkieScreen(this);
            case "para": return new ParabolicScreen(this);
            case "compass": return new CompassScreen(this);
            case "gate": return new GateScreen(this);
            case "ext": return new ExtCamScreen(this);
            default: return new MenuScreen(this);
        }
    }

    void open(String key) {
        Screen s = screens.get(key);
        if (s == null) {
            s = create(key);
            screens.put(key, s);
        }
        if (current == s) return;
        if (current != null && resumed) current.onHide();
        content.removeAllViews();
        content.addView(s, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        current = s;
        core.tool = key;
        titleView.setText(s.title().toUpperCase());
        boolean menu = key.equals("menu");
        backView.setVisibility(menu ? android.view.View.GONE : android.view.View.VISIBLE);
        teamView.setVisibility(menu ? android.view.View.GONE : android.view.View.VISIBLE);
        if (resumed) s.onShow();
    }

    /** Buduje ekrany od nowa (np. po zmianie koloru motywu). */
    void rebuild(String key) {
        if (current != null && resumed) current.onHide();
        content.removeAllViews();
        screens.clear();
        current = null;
        backView.setTextColor(Ui.ACCENT);
        open(key);
    }

    private void updateTeam() {
        Net n = core.net;
        String sp = core.ptt.speaking();
        pttView.setVisibility(n.isConnected() ? android.view.View.VISIBLE : android.view.View.GONE);
        if (core.sensors.takeShake() && core.prefs.getBoolean("shake_sos", false)) shakeSos();
        String t;
        if (n.role == Net.HOST) t = "● host · " + (core.members.size() + 1);
        else if (n.connecting) t = "łączenie…";
        else if (n.isConnected()) t = "● " + (core.members.size() + 1) + " os.";
        else t = "solo";
        if (sp != null) t = "◉ " + sp.toUpperCase() + " MÓWI";
        if (!t.contentEquals(teamView.getText())) {
            teamView.setText(t);
            teamView.setTextColor(n.isConnected() ? Ui.ACCENT : Ui.DIM);
        }
    }

    // ================= uprawnienia =================

    void withPermission(String perm, Runnable granted) {
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) {
            granted.run();
            return;
        }
        int req = nextReq++;
        permCallbacks.put(req, granted);
        requestPermissions(new String[]{perm}, req);
    }

    boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        Runnable r = permCallbacks.remove(code);
        if (r != null && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) r.run();
        else if (r != null) core.toast("Brak uprawnienia – ta funkcja nie zadziała");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK_AUDIO && res == RESULT_OK && data != null && data.getData() != null) {
            Screen s = screens.get("music");
            if (s instanceof MusicScreen) ((MusicScreen) s).onPicked(data.getData());
        }
    }

    // ================= cykl życia =================

    // ================= SOS =================

    private void onSos(String name, double lat, double lon, boolean self) {
        if (self) {
            core.toast(core.net.isConnected() ? "SOS wysłany do drużyny" : "Brak drużyny – SOS nie został wysłany");
            return;
        }
        try {
            if (siren == null) siren = new android.media.ToneGenerator(AudioManager.STREAM_ALARM, 100);
            siren.startTone(android.media.ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 10000);
        } catch (Exception ignored) { }
        if (sosDialog != null && sosDialog.isShowing()) sosDialog.dismiss();
        boolean loc = !Double.isNaN(lat);
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(this)
                .setTitle("SOS: " + name)
                .setMessage(name + " potrzebuje pomocy!" + (loc ? String.format(java.util.Locale.US,
                        "\n\nLokalizacja: %.5f, %.5f", lat, lon) : "\n\n(brak lokalizacji – GPS wyłączony)"))
                .setNegativeButton("OK", (d, w) -> { if (siren != null) siren.stopTone(); });
        if (loc) b.setPositiveButton("POKAŻ NA MAPIE", (d, w) -> {
            if (siren != null) siren.stopTone();
            openMap(lat, lon, name);
        });
        sosDialog = b.show();
    }

    void openMap(double lat, double lon, String label) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(String.format(java.util.Locale.US,
                    "geo:%.6f,%.6f?q=%.6f,%.6f(%s)", lat, lon, lat, lon, android.net.Uri.encode(label))));
            startActivity(i);
        } catch (Exception e) {
            core.toast("Brak aplikacji map");
        }
    }

    /** Potrząśnięcie: 5 s na anulowanie, potem SOS. */
    void shakeSos() {
        if (shakeDialog != null && shakeDialog.isShowing()) return;
        final Runnable send = () -> {
            if (shakeDialog != null && shakeDialog.isShowing()) {
                shakeDialog.dismiss();
                core.sos();
            }
        };
        shakeDialog = new android.app.AlertDialog.Builder(this)
                .setTitle("Wysyłam SOS za 5 s")
                .setMessage("Wykryto potrząśnięcie telefonem. Drużyna dostanie alarm z twoją lokalizacją.")
                .setPositiveButton("WYŚLIJ TERAZ", (d, w) -> core.sos())
                .setNegativeButton("ANULUJ", (d, w) -> h.removeCallbacks(send))
                .show();
        h.postDelayed(send, 5000);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        core.sosUi = this::onSos;
        core.sensors.start();
        if (current != null) current.onShow();
        h.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        h.removeCallbacks(ticker);
        if (current != null) current.onHide();
        core.sensors.stop();
    }

    @Override
    public void onBackPressed() {
        if (current != null && !"menu".equals(core.tool)) open("menu");
        else super.onBackPressed();
    }
}
