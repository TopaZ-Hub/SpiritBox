package pl.duchy.spiritbox;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;

/** Lokalizacja GPS – tylko gdy użytkownik ją włączy w ustawieniach. */
final class Geo implements LocationListener {
    private final Context ctx;
    private LocationManager lm;
    private boolean running = false;
    volatile double lat = Double.NaN, lon = Double.NaN;
    volatile float accuracy = 0;
    volatile long at = 0;

    Geo(Context c) {
        ctx = c.getApplicationContext();
    }

    boolean has() {
        return !Double.isNaN(lat) && System.currentTimeMillis() - at < 10 * 60_000;
    }

    @SuppressWarnings("MissingPermission")
    void start() {
        if (running) return;
        if (ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return;
        running = true;
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 4000, 2f, this, Looper.getMainLooper());
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 8000, 5f, this, Looper.getMainLooper());
            Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (l == null) l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (l != null) onLocationChanged(l);
        } catch (Exception ignored) { }
    }

    void stop() {
        if (!running) return;
        running = false;
        try { lm.removeUpdates(this); } catch (Exception ignored) { }
    }

    @Override
    public void onLocationChanged(Location l) {
        // lepsza dokładność albo nowszy odczyt
        if (has() && l.getAccuracy() > accuracy * 2 && System.currentTimeMillis() - at < 20000) return;
        lat = l.getLatitude();
        lon = l.getLongitude();
        accuracy = l.getAccuracy();
        at = System.currentTimeMillis();
    }

    @Override public void onStatusChanged(String p, int s, Bundle b) { }
    @Override public void onProviderEnabled(String p) { }
    @Override public void onProviderDisabled(String p) { }

    /** [odległość w m, kierunek w stopniach] z punktu 1 do 2. */
    static float[] distance(double lat1, double lon1, double lat2, double lon2) {
        float[] r = new float[2];
        Location.distanceBetween(lat1, lon1, lat2, lon2, r);
        return r;
    }
}
