package pl.duchy.spiritbox;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;

/**
 * Ciągły nasłuch słów w czasie skanu Spirit Boxa (rozpoznawanie mowy w telefonie).
 * Każde rozpoznane słowo trafia do dziennika razem z nagraniem ostatnich sekund skanu.
 */
final class WordListener implements RecognitionListener {

    interface OnWord { void onWord(String text); }

    private final Context ctx;
    private final Core core;
    private final OnWord onWord;
    private SpeechRecognizer sr;
    private Intent intent;
    private boolean active = false;
    private String last = "";
    private long lastAt = 0;

    WordListener(Context c, Core core, OnWord onWord) {
        ctx = c;
        this.core = core;
        this.onWord = onWord;
    }

    boolean isActive() {
        return active;
    }

    void start() {
        if (active) return;
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            core.toast("Ten telefon nie ma usługi rozpoznawania mowy");
            return;
        }
        active = true;
        sr = SpeechRecognizer.createSpeechRecognizer(ctx);
        sr.setRecognitionListener(this);
        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pl-PL");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        listen();
    }

    void stop() {
        active = false;
        core.main.removeCallbacks(restart);
        if (sr != null) {
            try {
                sr.cancel();
                sr.destroy();
            } catch (Exception ignored) { }
            sr = null;
        }
    }

    private final Runnable restart = this::listen;

    private void listen() {
        if (!active || sr == null) return;
        try {
            sr.startListening(intent);
        } catch (Exception e) {
            core.main.postDelayed(restart, 1000);
        }
    }

    private void again(long delay) {
        core.main.removeCallbacks(restart);
        if (active) core.main.postDelayed(restart, delay);
    }

    @Override
    public void onResults(Bundle b) {
        ArrayList<String> r = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (r != null && !r.isEmpty()) {
            String t = r.get(0).trim();
            long now = System.currentTimeMillis();
            if (!t.isEmpty() && !(t.equalsIgnoreCase(last) && now - lastAt < 15000)) {
                last = t;
                lastAt = now;
                onWord.onWord(t);
            }
        }
        again(150);
    }

    @Override
    public void onError(int error) {
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            stop();
            core.toast("Brak uprawnienia do mikrofonu – nasłuch słów wyłączony");
            return;
        }
        again(error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1200 : 300);
    }

    @Override public void onReadyForSpeech(Bundle b) { }
    @Override public void onBeginningOfSpeech() { }
    @Override public void onRmsChanged(float v) { }
    @Override public void onBufferReceived(byte[] b) { }
    @Override public void onEndOfSpeech() { }
    @Override public void onPartialResults(Bundle b) { }
    @Override public void onEvent(int t, Bundle b) { }
}
