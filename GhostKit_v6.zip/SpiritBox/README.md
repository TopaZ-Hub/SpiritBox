# Ghost Kit (Android 6.0+)

Zestaw łowcy duchów w jednej aplikacji, bez zewnętrznych bibliotek.

## Narzędzia
- **Spirit Box** – skaner (FM/AM), zegar i poziom sygnału, przycisk SAVE zapisuje słowa do dziennika.
- **Miernik EMF** – 5 diod, skala w mG, odczyt z magnetometru.
- **Termometr** – czujnik temperatury otoczenia (jeśli telefon go ma), w przeciwnym razie temperatura baterii.
- **Kamera** – tryby Normalny / Noc / Noktowizja (dłuższe naświetlanie + programowe rozjaśnianie i odszumianie), zoom, latarka, dźwięk, wykrywanie ruchu, zdjęcia i nagrania MP4 z dźwiękiem.
- **Podgląd kamer** – obraz i dźwięk z kamery innego telefonu, zdalny zoom/tryb/latarka/ruch, zdjęcia i nagrania u siebie.
- **Czujnik ruchu** – akcelerometr + czujnik zbliżeniowy, alarm na wszystkich telefonach.
- **Pozytywka** – własna melodia albo wybrany plik audio; rozstraja się przy skoku EMF.
- **Dziennik** – wspólny dla drużyny: lista słów ze Spirit Boxa oraz zdjęcia i nagrania; przycisk czyszczenia.
- **Drużyna** – łączenie telefonów: Wi-Fi, hotspot, Tailscale (internet).

## Budowanie
GitHub Actions: w repozytorium dokładnie jeden plik .zip z projektem + workflow `.github/workflows/build.yml`.
Albo Android Studio: File → Open → Build → Build APK(s).
