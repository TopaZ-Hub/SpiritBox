package pl.duchy.spiritbox;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener, RadioView.Listener {

    private static final int REQ_MIC = 42;
    private static final int[] RATES = {50, 100, 150, 200, 250, 300, 400, 500};
    private static final float[] LEVELS = {1.5f, 4f, 10f, 25f, 50f}; // ΔµT dla 5 słupków

    private final SweepEngine engine = new SweepEngine();
    private RadioView radio;
    private TextView logText;
    private SensorManager sm;
    private Sensor mag;
    private ToneGenerator tone;
    private AudioManager audio;

    private int rateIdx = 2;
    private int fmTenths = 875;   // 87.5 MHz
    private int amKhz = 530;
    private boolean fwd = true, amBand = false, echo = false, beep = true;

    private float baseline = -1f, smoothDelta = 0f, lastTotal = 0f;
    private long lastUi = 0, lastBeep = 0, lastLog = 0, lastBattery = 0;

    private final ArrayDeque<String> log = new ArrayDeque<>();
    private final SimpleDateFormat hms = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xFF000000);
        getWindow().setNavigationBarColor(0xFF000000);

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        mag = sm != null ? sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) : null;
        audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 70); } catch (RuntimeException ignored) { }
        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF000000);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(12), dp(8), dp(16));
        sv.addView(root);

        radio = new RadioView(this);
        radio.setListener(this);
        radio.hasEmf = mag != null;
        radio.sweepMs = RATES[rateIdx];
        radio.freq = fmText();
        root.addView(radio, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView hint = new TextView(this);
        hint.setText("POWER – start/stop skanu · SWEEP RATE – szybkość · AM/FM – rodzaj szumu\n" +
                "EMF CAL – kalibracja (przytrzymaj: pikanie wł./wył.) · BACK LIGHT – podświetlenie\n" +
                "MIC – strzępki dźwięku z otoczenia (używaj słuchawek) · REC – nagrywanie do Muzyka/SpiritBox");
        hint.setTextColor(0xFF8A8A8A);
        hint.setTextSize(11);
        hint.setPadding(dp(8), dp(12), dp(8), dp(8));
        root.addView(hint);

        TextView logTitle = new TextView(this);
        logTitle.setText("DZIENNIK");
        logTitle.setTextColor(0xFFFF6A40);
        logTitle.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        logTitle.setPadding(dp(8), dp(8), dp(8), dp(4));
        root.addView(logTitle);

        logText = new TextView(this);
        logText.setText("Brak zdarzeń.");
        logText.setTextColor(0xFFCC8866);
        logText.setTypeface(Typeface.MONOSPACE);
        logText.setTextSize(12);
        logText.setPadding(dp(8), 0, dp(8), dp(8));
        root.addView(logText);

        TextView info = new TextView(this);
        info.setText("Aplikacja rozrywkowa. Dźwięk to szum i przypadkowe fragmenty otoczenia – mózg " +
                "naturalnie doszukuje się w nich słów. Magnetometr reaguje na magnesy, metal, kable i elektronikę.");
        info.setTextColor(0xFF555555);
        info.setTextSize(10);
        info.setPadding(dp(8), dp(12), dp(8), dp(8));
        root.addView(info);

        setContentView(sv);
        engine.setListener(type -> runOnUiThread(this::advanceFreq));
        readBattery();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ================= przyciski =================

    @Override
    public void onButton(int id, boolean longPress) {
        switch (id) {
            case RadioView.B_POWER:
                togglePower();
                break;
            case RadioView.B_RATE:
                rateIdx = (rateIdx + 1) % RATES.length;
                engine.setSweepMs(RATES[rateIdx]);
                radio.sweepMs = RATES[rateIdx];
                break;
            case RadioView.B_FWD:
                fwd = true;
                radio.fwd = true;
                break;
            case RadioView.B_REV:
                fwd = false;
                radio.fwd = false;
                break;
            case RadioView.B_VOLUP:
            case RadioView.B_VOLDN:
                if (audio != null) {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                            id == RadioView.B_VOLUP ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, 0);
                    radio.volText = String.valueOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC));
                    radio.volUntil = System.currentTimeMillis() + 1500;
                    radio.postInvalidateDelayed(1600);
                }
                break;
            case RadioView.B_BAND:
                amBand = !amBand;
                engine.setAmBand(amBand);
                radio.amBand = amBand;
                radio.freq = amBand ? amText() : fmText();
                break;
            case RadioView.B_LIGHT:
                radio.backlight = (radio.backlight + 1) % 3;
                break;
            case RadioView.B_MIC:
                toggleMic();
                break;
            case RadioView.B_REC:
                toggleRec();
                break;
            case RadioView.B_ECHO:
                echo = !echo;
                engine.setEcho(echo);
                radio.echo = echo;
                break;
            case RadioView.B_CAL:
                if (longPress) {
                    beep = !beep;
                    radio.beep = beep;
                    toast(beep ? "Pikanie EMF włączone" : "Pikanie EMF wyłączone");
                } else {
                    baseline = lastTotal;
                    smoothDelta = 0;
                    toast("Skalibrowano tło EMF");
                }
                break;
        }
        radio.invalidate();
    }

    private void togglePower() {
        if (engine.isRunning()) {
            if (engine.isRecording()) toggleRec();
            engine.stop();
            radio.running = false;
            addLog("Koniec sesji");
        } else {
            engine.setUseMic(radio.mic && hasMic());
            engine.start();
            radio.running = true;
            addLog("Start sesji (" + (amBand ? "AM" : "FM") + ", " + RATES[rateIdx] + " ms)");
        }
    }

    private void toggleMic() {
        if (radio.mic) {
            radio.mic = false;
            engine.setUseMic(false);
            return;
        }
        if (!hasMic()) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        radio.mic = true;
        engine.setUseMic(true);
        toast("Użyj słuchawek – inaczej głośnik wraca do mikrofonu");
    }

    private void advanceFreq() {
        if (amBand) {
            amKhz += fwd ? 10 : -10;
            if (amKhz > 1710) amKhz = 530;
            if (amKhz < 530) amKhz = 1710;
            radio.freq = amText();
        } else {
            fmTenths += fwd ? 1 : -1;
            if (fmTenths > 1080) fmTenths = 875;
            if (fmTenths < 875) fmTenths = 1080;
            radio.freq = fmText();
        }
        radio.invalidate();
    }

    private String fmText() {
        String s = (fmTenths / 10) + "." + (fmTenths % 10);
        return s.length() < 5 ? " " + s : s;
    }

    private String amText() {
        String s = String.valueOf(amKhz);
        return s.length() < 4 ? " " + s : s;
    }

    // ================= nagrywanie =================

    private void toggleRec() {
        if (engine.isRecording()) {
            File f = engine.stopRecording();
            radio.rec = false;
            if (f != null) new Thread(() -> publish(f)).start();
            radio.invalidate();
            return;
        }
        if (!engine.isRunning()) {
            toast("Najpierw włącz POWER");
            return;
        }
        try {
            String name = "SpiritBox_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".wav";
            File dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);
            if (dir == null) dir = getFilesDir();
            engine.startRecording(new File(dir, name));
            radio.rec = true;
            addLog("Nagrywanie…");
        } catch (Exception e) {
            toast("Nie udało się nagrywać: " + e.getMessage());
        }
    }

    private void publish(File f) {
        String where = f.getAbsolutePath();
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Audio.Media.DISPLAY_NAME, f.getName());
                v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/x-wav");
                v.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/SpiritBox");
                Uri uri = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
                if (uri != null) {
                    try (OutputStream os = getContentResolver().openOutputStream(uri);
                         InputStream is = new FileInputStream(f)) {
                        byte[] buf = new byte[65536];
                        int r;
                        while ((r = is.read(buf)) > 0) os.write(buf, 0, r);
                    }
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                    where = "Muzyka/SpiritBox/" + f.getName();
                }
            } catch (Exception ignored) { }
        }
        final String msg = "Zapisano: " + where;
        runOnUiThread(() -> { toast(msg); addLog("Nagranie zapisane"); });
    }

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_MIC) return;
        boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        radio.mic = ok;
        engine.setUseMic(ok);
        radio.invalidate();
        if (!ok) toast("Bez mikrofonu skaner używa tylko szumu");
    }

    // ================= EMF =================

    @Override
    public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1], z = e.values[2];
        float m = (float) Math.sqrt(x * x + y * y + z * z);
        lastTotal = m;
        if (baseline < 0) baseline = m;
        else baseline += (m - baseline) * 0.002f;
        float d = Math.abs(m - baseline);
        smoothDelta += (d - smoothDelta) * 0.25f;
        engine.addEntropy(m);

        int level = 0;
        for (float t : LEVELS) if (smoothDelta >= t) level++;

        long now = System.currentTimeMillis();
        if (level >= 3) {
            if (beep && tone != null && now - lastBeep > 250) {
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 60 + level * 20);
                lastBeep = now;
            }
            if (now - lastLog > 2000) {
                addLog(String.format(Locale.US, "Skok EMF Δ%.1f µT%s @ %s", smoothDelta,
                        engine.isRunning() ? "" : " (skaner wył.)", radio.freq.trim()));
                lastLog = now;
            }
        }
        if (now - lastBattery > 30000) readBattery();

        if (now - lastUi < 60) return;
        lastUi = now;
        radio.emfDelta = smoothDelta;
        radio.emfLevel = level;
        radio.invalidate();
    }

    @Override
    public void onAccuracyChanged(Sensor s, int a) { }

    private void readBattery() {
        lastBattery = System.currentTimeMillis();
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return;
        int lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        if (lvl >= 0 && sc > 0) radio.battery = lvl * 100 / sc;
    }

    private void addLog(String s) {
        log.addFirst(hms.format(new Date()) + "  " + s);
        while (log.size() > 25) log.removeLast();
        StringBuilder sb = new StringBuilder();
        for (String l : log) sb.append(l).append('\n');
        logText.setText(sb.toString().trim());
    }

    // ================= cykl życia =================

    @Override
    protected void onResume() {
        super.onResume();
        if (mag != null) sm.registerListener(this, mag, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sm != null) sm.unregisterListener(this);
    }

    @Override
    protected void onDestroy() {
        if (engine.isRecording()) {
            File f = engine.stopRecording();
            if (f != null) publish(f);
        }
        engine.stop();
        if (tone != null) tone.release();
        super.onDestroy();
    }
}
