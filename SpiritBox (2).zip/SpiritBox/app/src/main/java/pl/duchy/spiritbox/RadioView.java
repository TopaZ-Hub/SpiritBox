package pl.duchy.spiritbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/** Cały "fizyczny" skaner rysowany na Canvasie: obudowa, antena, wyświetlacz LCD, przyciski, głośnik. */
public class RadioView extends View {

    public interface Listener {
        void onButton(int id, boolean longPress);
    }

    public static final int B_RATE = 0, B_FWD = 1, B_VOLUP = 2, B_BAND = 3,
            B_LIGHT = 4, B_REV = 5, B_VOLDN = 6, B_POWER = 7,
            B_MIC = 8, B_REC = 9, B_ECHO = 10, B_CAL = 11;

    private static final String[] LABELS = {
            "SWEEP\nRATE", "SWEEP\nFWD", "VOL +", "AM/FM",
            "BACK\nLIGHT", "SWEEP\nREV", "VOL −", "POWER",
            "MIC", "REC", "ECHO", "EMF CAL\n/BEEP"};

    // ---- stan wyświetlany ----
    public boolean running, mic, rec, echo, beep = true, fwd = true, amBand, hasEmf = true;
    public float emfDelta;
    public int emfLevel;
    public String freq = "87.5";
    public int sweepMs = 150;
    public int battery = 100;
    public int backlight = 0; // 0 czerwony, 1 bursztynowy, 2 wyłączony
    public String volText;
    public long volUntil;

    private Listener listener;
    private final RectF[] btn = new RectF[12];
    private int pressed = -1;
    private boolean longFired;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF tmp = new RectF();

    private static final int[] SEG = new int[128];
    static {
        SEG['0'] = 63; SEG['1'] = 6; SEG['2'] = 91; SEG['3'] = 79; SEG['4'] = 102;
        SEG['5'] = 109; SEG['6'] = 125; SEG['7'] = 7; SEG['8'] = 127; SEG['9'] = 111;
        SEG['-'] = 64; SEG['O'] = 63; SEG['F'] = 113; SEG['A'] = 119; SEG['E'] = 121;
        SEG['L'] = 56; SEG['n'] = 84; SEG['U'] = 62;
    }

    private final Runnable longPress = () -> {
        if (pressed >= 0) {
            longFired = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            if (listener != null) listener.onButton(pressed, true);
        }
    };

    public RadioView(Context c) {
        super(c);
        for (int i = 0; i < btn.length; i++) btn[i] = new RectF();
    }

    public void setListener(Listener l) { listener = l; }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        setMeasuredDimension(w, (int) (w * 1.92f));
    }

    // ================= rysowanie =================

    @Override
    protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight();
        float u = W / 100f;

        float bodyTop = 15 * u, bodyL = 4 * u, bodyR = 96 * u, bodyB = H - 2 * u;

        drawAntenna(c, 81 * u, bodyTop, u);

        // boczne pokrętło i górny przycisk
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF1A1A1A);
        tmp.set(bodyL - 1.8f * u, bodyTop + 38 * u, bodyL + 1 * u, bodyTop + 50 * u);
        c.drawRoundRect(tmp, u, u, p);
        tmp.set(26 * u, bodyTop - 2 * u, 36 * u, bodyTop + 1 * u);
        c.drawRoundRect(tmp, u, u, p);

        // obudowa
        RectF body = new RectF(bodyL, bodyTop, bodyR, bodyB);
        p.setShader(new LinearGradient(bodyL, 0, bodyR, 0,
                new int[]{0xFF0B0B0B, 0xFF232323, 0xFF0B0B0B}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(body, 7 * u, 7 * u, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.5f * u);
        p.setColor(0xFF333333);
        c.drawRoundRect(body, 7 * u, 7 * u, p);
        p.setStyle(Paint.Style.FILL);

        // srebrny panel
        RectF face = new RectF(bodyL + 5 * u, bodyTop + 5 * u, bodyR - 5 * u, bodyTop + 96 * u);
        p.setShader(new LinearGradient(0, face.top, 0, face.bottom,
                new int[]{0xFFE6E6E6, 0xFFC4C4C4, 0xFFAAAAAA}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(face, 2.5f * u, 2.5f * u, p);
        p.setShader(null);

        // napis
        p.setColor(0xFF161616);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(4.8f * u);
        c.drawText("SB-1  SPIRIT BOX", face.centerX(), face.top + 6.4f * u, p);

        // LCD
        RectF bezel = new RectF(face.left + 4 * u, face.top + 9 * u, face.right - 4 * u, face.top + 40 * u);
        p.setColor(0xFF262626);
        c.drawRoundRect(bezel, 1.6f * u, 1.6f * u, p);
        RectF lcd = new RectF(bezel.left + 1.4f * u, bezel.top + 1.4f * u, bezel.right - 1.4f * u, bezel.bottom - 1.4f * u);
        drawLcd(c, lcd, u);

        // dioda POWER
        float ly = bezel.bottom + 4.6f * u;
        float lx = face.centerX() - 9 * u;
        if (running) {
            p.setShader(new RadialGradient(lx, ly, 3.2f * u, 0x88FF9A2A, 0x00FF9A2A, Shader.TileMode.CLAMP));
            c.drawCircle(lx, ly, 3.2f * u, p);
            p.setShader(null);
            p.setColor(0xFFFFA43A);
        } else {
            p.setColor(0xFF7A5530);
        }
        c.drawCircle(lx, ly, 1.1f * u, p);
        p.setColor(0xFF1E1E1E);
        p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(3.3f * u);
        c.drawText("POWER", lx + 2.8f * u, ly + 1.2f * u, p);

        // przyciski
        float gridTop = bezel.bottom + 10 * u;
        float colW = (face.width() - 6 * u) / 4f;
        for (int r = 0; r < 3; r++) {
            for (int col = 0; col < 4; col++) {
                int idx = r * 4 + col;
                float bx = face.left + 3 * u + col * colW + colW * 0.13f;
                float by = gridTop + r * 13.5f * u;
                btn[idx].set(bx, by, bx + colW * 0.74f, by + 5.4f * u);
                drawButton(c, idx, u);
                drawLabel(c, LABELS[idx], btn[idx].centerX(), btn[idx].bottom + 3.3f * u, u);
            }
        }

        // głośnik
        float spTop = face.bottom, spBot = bodyB - 10 * u;
        float cx = W / 2f, cy = (spTop + spBot) / 2f;
        float rad = Math.min(38 * u, (spBot - spTop) / 2f - 2 * u);
        drawSpeaker(c, cx, cy, rad, u);

        // napis na dole
        p.setColor(0xFF8A8A8A);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(4.3f * u);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        c.drawText("PARANORMAL SCANNER", cx, bodyB - 4.2f * u, p);
    }

    private void drawAntenna(Canvas c, float x, float bodyTop, float u) {
        float[] widths = {2.6f, 2.1f, 1.7f, 1.3f};
        float segH = (bodyTop - 3 * u) / widths.length;
        float y = bodyTop;
        for (float w : widths) {
            float hw = w * u / 2f;
            p.setShader(new LinearGradient(x - hw, 0, x + hw, 0,
                    new int[]{0xFF3A3A3A, 0xFFDADADA, 0xFF4A4A4A}, null, Shader.TileMode.CLAMP));
            c.drawRect(x - hw, y - segH, x + hw, y, p);
            y -= segH;
        }
        p.setShader(new RadialGradient(x - 0.5f * u, y - 0.6f * u, 2 * u, 0xFFDDDDDD, 0xFF333333, Shader.TileMode.CLAMP));
        c.drawCircle(x, y - 0.8f * u, 1.7f * u, p);
        p.setShader(null);
    }

    private void drawButton(Canvas c, int idx, float u) {
        RectF b = btn[idx];
        boolean pr = idx == pressed;
        p.setColor(0x66000000);
        tmp.set(b.left, b.top + 0.6f * u, b.right, b.bottom + 0.6f * u);
        c.drawRoundRect(tmp, 1.3f * u, 1.3f * u, p);

        float off = pr ? 0.4f * u : 0f;
        tmp.set(b.left, b.top + off, b.right, b.bottom + off);
        p.setShader(new LinearGradient(0, tmp.top, 0, tmp.bottom,
                pr ? new int[]{0xFF1C1C1C, 0xFF0A0A0A} : new int[]{0xFF4C4C4C, 0xFF141414},
                null, Shader.TileMode.CLAMP));
        c.drawRoundRect(tmp, 1.3f * u, 1.3f * u, p);
        p.setShader(null);

        // żeberka gumy
        p.setColor(0x22FFFFFF);
        p.setStrokeWidth(0.25f * u);
        for (int i = 1; i <= 4; i++) {
            float yy = tmp.top + tmp.height() * i / 5f;
            c.drawLine(tmp.left + 1.2f * u, yy, tmp.right - 1.2f * u, yy, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0xFF000000);
        p.setStrokeWidth(0.3f * u);
        c.drawRoundRect(tmp, 1.3f * u, 1.3f * u, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawLabel(Canvas c, String s, float x, float y, float u) {
        p.setColor(0xFF1C1C1C);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        p.setTextSize(2.7f * u);
        String[] lines = s.split("\n");
        for (int i = 0; i < lines.length; i++) c.drawText(lines[i], x, y + i * 2.9f * u, p);
    }

    private void drawSpeaker(Canvas c, float cx, float cy, float r, float u) {
        p.setColor(0xFF070707);
        c.drawCircle(cx, cy, r + 1.4f * u, p);
        c.save();
        path.reset();
        path.addCircle(cx, cy, r, Path.Direction.CW);
        c.clipPath(path);
        p.setColor(0xFF1A1A1A);
        c.drawCircle(cx, cy, r, p);
        float step = 2.6f * u;
        for (float x = cx - r; x < cx + r; x += step) {
            p.setColor(0xFF040404);
            c.drawRect(x, cy - r, x + step * 0.5f, cy + r, p);
            p.setColor(0xFF2E2E2E);
            c.drawRect(x + step * 0.5f, cy - r, x + step * 0.62f, cy + r, p);
        }
        c.restore();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.8f * u);
        p.setColor(0xFF2A2A2A);
        c.drawCircle(cx, cy, r + 0.8f * u, p);
        p.setStyle(Paint.Style.FILL);
    }

    // ================= LCD =================

    private void drawLcd(Canvas c, RectF r, float u) {
        int top, bot, on;
        if (backlight == 0) { top = 0xFFFF7A50; bot = 0xFFFF3E24; on = 0xFF2A0700; }
        else if (backlight == 1) { top = 0xFFFFCC66; bot = 0xFFFF9A1E; on = 0xFF2A1400; }
        else { top = 0xFF7D8874; bot = 0xFF66715E; on = 0xFF141912; }
        int ghost = (on & 0x00FFFFFF) | 0x1E000000;

        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, top, bot, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, 0.8f * u, 0.8f * u, p);
        p.setShader(null);

        float h = r.height(), w = r.width();
        long now = System.currentTimeMillis();

        // --- rząd 1: EMF ---
        float dh1 = h * 0.30f, y1 = r.top + h * 0.09f;
        String emf;
        if (!hasEmf) emf = "----";
        else if (emfDelta < 100f) emf = String.format(Locale.US, "%4.1f", emfDelta);
        else emf = String.format(Locale.US, "%4.0f", Math.min(emfDelta, 9999f));
        float x = drawSeg(c, emf, r.left + w * 0.05f, y1, dh1, on, ghost);
        p.setColor(on);
        p.setTextAlign(Paint.Align.LEFT);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        p.setTextSize(dh1 * 0.34f);
        c.drawText("µT", x + u, y1 + dh1 * 0.36f, p);
        c.drawText("EMF", x + u, y1 + dh1, p);

        // słupki EMF
        float bx0 = r.left + w * 0.57f, bw = w * 0.032f, bgap = w * 0.014f;
        for (int i = 0; i < 5; i++) {
            float bh = dh1 * (0.3f + 0.175f * i);
            p.setColor(i < emfLevel ? on : ghost);
            float bx = bx0 + i * (bw + bgap);
            c.drawRect(bx, y1 + dh1 - bh, bx + bw, y1 + dh1, p);
        }

        // bateria
        float batW = w * 0.10f, batH = h * 0.10f;
        float batX = r.right - w * 0.05f - batW, batY = r.top + h * 0.09f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.35f * u);
        p.setColor(on);
        tmp.set(batX, batY, batX + batW, batY + batH);
        c.drawRect(tmp, p);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(batX + batW, batY + batH * 0.3f, batX + batW + 0.6f * u, batY + batH * 0.7f, p);
        int bars = Math.max(1, Math.min(4, (battery + 24) / 25));
        float sw = (batW - 0.9f * u) / 4f;
        for (int i = 0; i < 4; i++) {
            p.setColor(i < bars ? on : ghost);
            float sx = batX + 0.45f * u + i * sw;
            c.drawRect(sx + 0.15f * u, batY + 0.5f * u, sx + sw - 0.15f * u, batY + batH - 0.5f * u, p);
        }

        // --- rząd 2: częstotliwość ---
        float dh2 = h * 0.30f, y2 = r.top + h * 0.50f;
        String f = running ? freq : " OFF";
        x = drawSeg(c, f, r.left + w * 0.05f, y2, dh2, on, ghost);
        p.setColor(on);
        p.setTextSize(dh2 * 0.30f);
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText(amBand ? "kHz" : "MHz", x + u, y2 + dh2 * 0.62f, p);

        // pasmo
        p.setTextSize(dh2 * 0.42f);
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText(amBand ? "AM" : "FM", r.right - w * 0.05f, y2 + dh2 * 0.05f, p);

        // ms / głośność
        boolean vol = volText != null && now < volUntil;
        float dh3 = dh2 * 0.58f;
        float msX = r.right - w * 0.29f;
        float xe = drawSeg(c, vol ? pad(volText, 3) : pad(String.valueOf(sweepMs), 3),
                msX, y2 + dh2 - dh3, dh3, on, ghost);
        p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(dh2 * 0.28f);
        p.setColor(on);
        c.drawText(vol ? "VOL" : "ms", xe + 0.4f * u, y2 + dh2, p);

        // --- rząd 3: flagi ---
        float fy = r.bottom - h * 0.05f;
        p.setTextSize(h * 0.085f);
        p.setTextAlign(Paint.Align.LEFT);
        String[] flags = {"MIC", "REC", "ECHO", "BEEP", fwd ? "▶▶" : "◀◀"};
        boolean[] act = {mic, rec && (now / 500) % 2 == 0, echo, beep, running};
        float fx = r.left + w * 0.05f;
        for (int i = 0; i < flags.length; i++) {
            p.setColor(act[i] ? on : ghost);
            c.drawText(flags[i], fx, fy, p);
            fx += p.measureText(flags[i]) + w * 0.06f;
        }
    }

    private static String pad(String s, int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = s.replace(".", "").length(); i < len; i++) sb.append(' ');
        return sb.append(s).toString();
    }

    /** Rysuje tekst jako cyfry 7-segmentowe (z widocznymi "niezapalonymi" segmentami jak na LCD). */
    private float drawSeg(Canvas c, String s, float x, float y, float h, int on, int ghost) {
        float w = h * 0.52f, t = h * 0.12f, gap = h * 0.20f;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '.') {
                p.setColor(on);
                c.drawCircle(x - gap * 0.55f, y + h - t * 0.5f, t * 0.62f, p);
                continue;
            }
            drawDigit(c, x, y, w, h, t, 127, ghost);
            int m = ch < 128 ? SEG[ch] : 0;
            if (m != 0) drawDigit(c, x, y, w, h, t, m, on);
            x += w + gap;
        }
        return x - gap * 0.4f;
    }

    private void drawDigit(Canvas c, float x, float y, float w, float h, float t, int mask, int color) {
        p.setColor(color);
        c.save();
        c.translate(x, y + h);
        c.skew(-0.09f, 0f);
        float top = -h + t / 2, mid = -h / 2, bot = -t / 2, left = t / 2, right = w - t / 2;
        float g = t * 0.18f;
        if ((mask & 1) != 0) hSeg(c, left + g, right - g, top, t);
        if ((mask & 2) != 0) vSeg(c, right, top + g, mid - g, t);
        if ((mask & 4) != 0) vSeg(c, right, mid + g, bot - g, t);
        if ((mask & 8) != 0) hSeg(c, left + g, right - g, bot, t);
        if ((mask & 16) != 0) vSeg(c, left, mid + g, bot - g, t);
        if ((mask & 32) != 0) vSeg(c, left, top + g, mid - g, t);
        if ((mask & 64) != 0) hSeg(c, left + g, right - g, mid, t);
        c.restore();
    }

    private void hSeg(Canvas c, float x1, float x2, float yc, float t) {
        float ht = t / 2;
        path.reset();
        path.moveTo(x1, yc);
        path.lineTo(x1 + ht, yc - ht);
        path.lineTo(x2 - ht, yc - ht);
        path.lineTo(x2, yc);
        path.lineTo(x2 - ht, yc + ht);
        path.lineTo(x1 + ht, yc + ht);
        path.close();
        c.drawPath(path, p);
    }

    private void vSeg(Canvas c, float xc, float y1, float y2, float t) {
        float ht = t / 2;
        path.reset();
        path.moveTo(xc, y1);
        path.lineTo(xc + ht, y1 + ht);
        path.lineTo(xc + ht, y2 - ht);
        path.lineTo(xc, y2);
        path.lineTo(xc - ht, y2 - ht);
        path.lineTo(xc - ht, y1 + ht);
        path.close();
        c.drawPath(path, p);
    }

    // ================= dotyk =================

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float ex = e.getX(), ey = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                pressed = -1;
                for (int i = 0; i < btn.length; i++) {
                    tmp.set(btn[i]);
                    tmp.inset(-1.5f * getWidth() / 100f, -2f * getWidth() / 100f);
                    if (tmp.contains(ex, ey)) { pressed = i; break; }
                }
                if (pressed < 0) return false;
                longFired = false;
                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                postDelayed(longPress, 650);
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                removeCallbacks(longPress);
                if (pressed >= 0 && !longFired && listener != null) listener.onButton(pressed, false);
                pressed = -1;
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(longPress);
                pressed = -1;
                invalidate();
                return true;
        }
        return true;
    }
}
