# Spirit Box (Android)

Skaner w stylu spirit boxa + detektor EMF z magnetometru. Bez bazy słów, bez bibliotek – czyste Android SDK. Działa na Androidzie 6.0+ (Samsung A56 i praktycznie każdy inny telefon).

## Funkcje
- **Skaner** – co 30–500 ms przeskakuje na kolejny „kanał”: szum eteru w losowym paśmie, gwizd nośnej albo (opcjonalnie) strzępek dźwięku z otoczenia z mikrofonu, czasem odwrócony. Losowość dodatkowo mieszana z odczytami magnetometru.
- **Detektor EMF** – odchylenie pola magnetycznego od tła (µT), 5 diod, wykres, pikanie, kalibracja.
- **Dziennik** – godziny skoków EMF i sesji.
- **Nagrywanie sesji** do WAV → `Muzyka/SpiritBox`.

## Jak zrobić APK

### Opcja A – bez komputera (GitHub, z telefonu)
1. Załóż konto na github.com i utwórz nowe repozytorium.
2. „Add file → Upload files” – wrzuć **całą zawartość** rozpakowanego folderu (z folderem `.github`).
3. Zakładka **Actions** → „Zbuduj APK” uruchomi się sama (~3–5 min).
4. Wejdź w zakończony build → na dole **Artifacts → SpiritBox-apk** → pobierz, rozpakuj, zainstaluj `app-debug.apk` (zezwól na instalację z nieznanych źródeł).

> Uwaga: przeglądarka w telefonie czasem nie wrzuca ukrytych folderów (`.github`). Wtedy w repo kliknij „Add file → Create new file”, wpisz nazwę `.github/workflows/build.yml` i wklej treść tego pliku.

### Opcja B – Android Studio (PC)
File → Open → wybierz folder `SpiritBox` → Build → Build APK(s).

## Wskazówki
- Strzępki z mikrofonu – używaj słuchawek (inaczej głośnik wraca do mikrofonu).
- Magnetometr pokazuje realne pole magnetyczne: magnesy, metal, kable, ładowarki dają duże skoki. Kalibruj z dala od nich.
